import pandas as pd
import ppn_gen_aut as pga

def test_completer_avec_wikidata(monkeypatch):
    source = pd.DataFrame({"ppn":["123","456"],"NomComplet":[None,"Déjà là"]})
    wd = pd.DataFrame({
        "ppn":["123","456"],
        "NomComplet_wikidata":["Alice","Bob"],
        "Occupations_wikidata":["Écrivain","Artiste"],
        "bnf_id_wikidata":["b1","b2"],
        "gnd_id_wikidata":["g1","g2"],
    })
    monkeypatch.setattr(pga,"recuperer_wikidata",lambda df: wd)
    out = pga.completer_avec_wikidata(source)
    assert out.loc[0,"NomComplet"] == "Alice"
    assert out.loc[1,"NomComplet"] == "Déjà là"
    assert not any(c.endswith("_wikidata") for c in out.columns)
