import lieupublibnf as m

def test_construire_bif_contains():
    assert m.construire_bif_contains(["Genève","L'Histoire"]) == "'Genève' OR 'L Histoire'"

def test_valeur_binding():
    assert m.valeur_binding({"x":{"value":"abc"}},"x") == "abc"
    assert m.valeur_binding({},"x") is None

def test_dedoublonner_lignes():
    lignes = [{"ppn":"1","isbn":"a"},{"ppn":"1","isbn":"a"},{"ppn":"2","isbn":"a"}]
    assert len(m.dedoublonner_lignes(lignes,["ppn","isbn"])) == 2
