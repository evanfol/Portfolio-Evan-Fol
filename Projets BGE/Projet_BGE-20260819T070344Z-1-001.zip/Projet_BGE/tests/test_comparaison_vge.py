import pandas as pd
import comparaison_vge as vge

def test_trouver_colonne():
    df = pd.DataFrame(columns=[" ISBN_Normalise ","Acquisition"])
    assert vge.trouver_colonne(df,"isbn_normalise") == " ISBN_Normalise "
    assert vge.trouver_colonne(df,"absente") is None

def test_isbn10_valide():
    assert vge.isbn10_valide("2070360024")
    assert not vge.isbn10_valide("2070360025")

def test_isbn13_valide():
    assert vge.isbn13_valide("9782070360024")
    assert not vge.isbn13_valide("9782070360025")

def test_isbn10_vers_13():
    assert vge.isbn10_vers_13("2070360024") == "9782070360024"

def test_normaliser_isbn():
    assert vge.normaliser_isbn("978-2-07-036002-4") == "9782070360024"
    assert vge.normaliser_isbn("2070360024") == "9782070360024"
    assert vge.normaliser_isbn(None) is None

def test_isbn13_vers_10():
    assert vge.isbn13_vers_10("9782070360024") == "2070360024"

def test_formes_recherche_isbn():
    assert vge.formes_recherche_isbn("9782070360024") == {"9782070360024","2070360024"}
    assert vge.formes_recherche_isbn("abc") == set()

def test_normaliser_colonne_isbn():
    df = pd.DataFrame({"isbn":["2070360024","x"]})
    out = vge.normaliser_colonne_isbn(df,"isbn")
    assert out.iloc[0] == "9782070360024"
    assert pd.isna(out.iloc[1])

def test_construire_isbn_par_ligne():
    df = pd.DataFrame({"isbn_normalise":["9782070360024",None],"isbn":["9780306406157","2070360024"]})
    out = vge.construire_isbn_par_ligne(df)
    assert out.iloc[0] == "9782070360024"
    assert out.iloc[1] == "9782070360024"

def test_recuperer_isbn_interdits_vide(monkeypatch):
    monkeypatch.setattr(vge,"charger_historique_acquisition_non",lambda: pd.DataFrame())
    assert vge.recuperer_isbn_interdits() == set()

def test_filtrer_isbn_effectif_interdit(monkeypatch):
    monkeypatch.setattr(vge,"recuperer_isbn_interdits",lambda: {"9782070360024"})
    df = pd.DataFrame({"isbn_normalise":["9782070360024","9780306406157"]})
    out, serie = vge.filtrer_isbn_effectif_interdit(df)
    assert len(out) == 1
    assert out.iloc[0]["isbn_normalise"] == "9780306406157"
