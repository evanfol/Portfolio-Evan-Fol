import lieupublidnb as m

def test_normaliser_texte():
    assert m.normaliser_texte(" Genève ") == "geneve"
    assert m.normaliser_texte("ŒUVRE") == "oeuvre"
    assert m.normaliser_texte(None) == ""

def test_extraire_idn_dnb():
    assert m.extraire_idn_dnb("https://d-nb.info/123456789") == "123456789"
    assert m.extraire_idn_dnb(None) is None
