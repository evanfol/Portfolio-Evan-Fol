import xml.etree.ElementTree as ET
import pytest
import sudoc

@pytest.mark.parametrize("entree,attendu", [
    ("027089215","027089215"),
    ("27089215","027089215"),
    ("027089215.0","027089215"),
    ("abc",None),(None,None),
])
def test_normaliser_ppn(entree, attendu):
    assert sudoc.normaliser_ppn(entree) == attendu

def test_nettoyer_texte():
    assert sudoc.nettoyer_texte("Paris :") == "Paris"
    assert sudoc.nettoyer_texte(" Test ") == "Test"

def test_extraire_annee():
    assert sudoc.extraire_annee(["sans date","Paris 1999"]) == 1999
    assert sudoc.extraire_annee([]) is None

def test_isbn():
    assert sudoc.isbn10_valide("2070360024")
    assert sudoc.isbn13_valide("9782070360024")
    assert sudoc.normaliser_isbn("2070360024") == "9782070360024"

def test_xml_helpers():
    record = ET.fromstring('<record><controlfield tag="001">123456789</controlfield><datafield tag="200"><subfield code="a">Titre</subfield><subfield code="a">Autre</subfield></datafield></record>')
    champ = next(e for e in record if e.tag == "datafield")
    assert sudoc.controlfield(record,"001") == "123456789"
    assert sudoc.sous_champs(champ,"a") == ["Titre","Autre"]
    assert sudoc.sous_champ(champ,"a") == "Titre"
