import pytest
import idref

@pytest.mark.parametrize("entree,attendu", [
    ("027089215","027089215"),
    ("27089215","027089215"),
    ("027089215.0","027089215"),
    ("",None),(None,None),
])
def test_normaliser_ppn(entree, attendu):
    assert idref.normaliser_ppn(entree) == attendu

def test_nettoyer_texte():
    assert idref.nettoyer_texte("Paris :") == "Paris"
    assert idref.nettoyer_texte(" Test ") == "Test"

def test_extraire_annee():
    assert idref.extraire_annee(["texte","1999"]) == 1999
    assert idref.extraire_annee([]) is None

def test_isbn():
    assert idref.isbn10_valide("2070360024")
    assert idref.isbn13_valide("9782070360024")
    assert idref.normaliser_isbn("2070360024") == "9782070360024"
