import pandas as pd
import pytest
import pipeline

def test_dedoublonner_none():
    assert pipeline.dedoublonner_ppn_isbn(None) is None

def test_dedoublonner_type_invalide():
    with pytest.raises(TypeError):
        pipeline.dedoublonner_ppn_isbn([])

def test_dedoublonner_dataframe_vide():
    df = pd.DataFrame(columns=["ppn","isbn_normalise"])
    assert pipeline.dedoublonner_ppn_isbn(df).empty

def test_dedoublonner_colonne_manquante():
    with pytest.raises(ValueError):
        pipeline.dedoublonner_ppn_isbn(pd.DataFrame({"ppn":["1"]}))

def test_dedoublonner_priorite_nz():
    df = pd.DataFrame({
        "ppn":["123","123"],
        "isbn_normalise":["9782070360024"]*2,
        "Source":["SUDOC","NZ"],
        "titre":["Sudoc","Swisscovery"],
    })
    out = pipeline.dedoublonner_ppn_isbn(df)
    assert len(out) == 1
    assert out.loc[0,"Source"] == "NZ"

def test_dedoublonner_conserve_sans_ppn():
    df = pd.DataFrame({"ppn":[None,None],"isbn_normalise":["9782070360024"]*2})
    assert len(pipeline.dedoublonner_ppn_isbn(df)) == 2

def test_sauvegarder_dataframe(monkeypatch, tmp_path):
    monkeypatch.setattr(pipeline, "DOSSIER_OUTPUT", str(tmp_path))
    pipeline.sauvegarder_dataframe(pd.DataFrame({"x":[1]}), "test.csv")
    assert (tmp_path/"test.csv").is_file()
