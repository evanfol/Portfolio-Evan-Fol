import pandas as pd
import pytest
import naissance_deces as nd

@pytest.mark.parametrize("entree,attendu", [
    ("027089215","027089215"),
    ("027089215.0","027089215"),
    ("",None),(None,None),("nan",None),
])
def test_normaliser_ppn(entree, attendu):
    assert nd.normaliser_ppn(entree) == attendu

@pytest.mark.parametrize("entree,attendu", [
    ("1878-09-24","1878"),("1952","1952"),("",None),(None,None),
])
def test_extraire_annee(entree, attendu):
    assert nd.extraire_annee(entree) == attendu

def test_ajouter_dates_colonne_absente():
    with pytest.raises(ValueError):
        nd.ajouter_dates_auteurs(pd.DataFrame({"x":[1]}))

def test_ajouter_dates_aucun_ppn():
    out = nd.ajouter_dates_auteurs(pd.DataFrame({"ppn":[None,""]}), afficher_progression=False)
    assert out["date_naissance"].isna().all()
    assert out["date_deces"].isna().all()

def test_ajouter_dates_mock(monkeypatch):
    def faux(ppns, session, timeout=30, max_retries=3):
        return pd.DataFrame({"ppn":ppns,"date_naissance":["1900"]*len(ppns),"date_deces":["1980"]*len(ppns)})
    monkeypatch.setattr(nd,"recuperer_dates_lot",faux)
    out = nd.ajouter_dates_auteurs(pd.DataFrame({"ppn":["027089215","027089215"]}), afficher_progression=False)
    assert out["date_naissance"].tolist() == ["1900","1900"]
