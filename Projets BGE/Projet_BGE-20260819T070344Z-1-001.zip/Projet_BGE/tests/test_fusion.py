import pandas as pd
import pytest
from fusion import preparer_dataframe, fusionner_sources

def test_preparer_none():
    assert preparer_dataframe(None) is None

def test_preparer_type_invalide():
    with pytest.raises(TypeError):
        preparer_dataframe([1,2])

def test_preparer_vide():
    assert preparer_dataframe(pd.DataFrame()) is None

def test_preparer_renomme_colonnes():
    df = pd.DataFrame({"ISBN_normalise":[" 9782070360024 "], "source":[" x "]})
    out = preparer_dataframe(df)
    assert out.loc[0,"isbn_normalise"] == "9782070360024"
    assert out.loc[0,"Source"] == "x"

def test_preparer_source_et_type():
    df = pd.DataFrame({"ppn":[" 027089215 "], "annee":["2020"]})
    out = preparer_dataframe(df, source="BNF", type_recherche="Auteur")
    assert out.loc[0,"Source"] == "BNF"
    assert out.loc[0,"TypeRecherche"] == "Auteur"
    assert out.loc[0,"ppn"] == "027089215"
    assert str(out["annee"].dtype) == "Int64"

def test_fusion_aucune_source():
    out = fusionner_sources({})
    assert out.empty

def test_fusion_source_auteur():
    df = pd.DataFrame({"ppn":["1"], "isbn_normalise":["9782070360024"]})
    out = fusionner_sources({"network":df})
    assert out.loc[0,"Source"] == "NZ"
    assert out.loc[0,"TypeRecherche"] == "Auteur"

def test_fusion_genevensia():
    df = pd.DataFrame({"ppn":["1"], "isbn_normalise":["9782070360024"]})
    out = fusionner_sources({}, {"idref":df})
    assert out.loc[0,"Source"] == "IDREF"
    assert out.loc[0,"TypeRecherche"] == "Genevensia"

def test_fusion_conserve_auteur_et_genevensia():
    df = pd.DataFrame({"ppn":["1"], "isbn_normalise":["9782070360024"]})
    out = fusionner_sources({"bnf":df}, {"bnf":df})
    assert len(out) == 2
    assert set(out["TypeRecherche"]) == {"Auteur","Genevensia"}

def test_fusion_supprime_doublons_stricts():
    df = pd.DataFrame({"ppn":["1","1"], "isbn_normalise":["9782070360024"]*2})
    assert len(fusionner_sources({"network":df})) == 1
