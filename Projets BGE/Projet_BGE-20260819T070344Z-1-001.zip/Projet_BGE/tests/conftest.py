import sys
from pathlib import Path

# Dossier où se trouve conftest.py
DOSSIER_TESTS = Path(__file__).resolve().parent

# Projet_BGE/
PROJET = DOSSIER_TESTS.parent

# Projet_BGE/modules/
MODULES = PROJET / "modules"

for chemin in (MODULES, PROJET):
    chemin = str(chemin)

    if chemin not in sys.path:
        sys.path.insert(0, chemin)
