import pandas as pd
import sources

def test_lancer_sources(monkeypatch):
    df = pd.DataFrame({"ppn":["1"],"gnd_id":["g1"]})
    faux = pd.DataFrame({"x":[1]})
    monkeypatch.setattr(sources,"ajouter_isbn_network_ultra",lambda *a,**k:faux)
    monkeypatch.setattr(sources,"ajouter_isbn_sudoc_ultra",lambda *a,**k:faux)
    monkeypatch.setattr(sources,"ajouter_isbn_dnb_ultra",lambda *a,**k:faux)
    resultats, erreurs = sources.lancer_sources(df)
    assert set(resultats) == {"network","sudoc","dnb"}
    assert erreurs == {}
