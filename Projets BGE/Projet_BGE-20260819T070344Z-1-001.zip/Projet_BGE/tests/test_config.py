from pathlib import Path
import config

def test_chemins_config():
    assert isinstance(config.DOSSIER_MODULES, Path)
    assert isinstance(config.DOSSIER_PROJET, Path)
    assert config.DOSSIER_LISTES.name == "Liste"
    assert config.DOSSIER_OUTPUT.name == "output"
    assert config.FICHIER_COMMUNES.name == "liste commune geneve.txt"
    assert config.FICHIER_TITRES.name == "liste titre.txt"
