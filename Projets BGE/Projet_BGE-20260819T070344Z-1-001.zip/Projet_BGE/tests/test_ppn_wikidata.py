import pandas as pd
import ppn_wikidata as pw

def test_resultat_vers_dataframe():
    r = {"head":{"vars":["ppn","nom"]},"results":{"bindings":[{"ppn":{"value":"123"},"nom":{"value":"Alice"}},{"ppn":{"value":"456"}}]}}
    df = pw.resultat_vers_dataframe(r)
    assert df["ppn"].tolist() == ["123","456"]
    assert df.loc[0,"nom"] == "Alice"
    assert df.loc[1,"nom"] is None

def test_regrouper_raisons():
    prop = next(iter(pw.RAISONS))
    raison = pw.RAISONS[prop]
    df = pd.DataFrame({"item":["Q1","Q1"],"ppn":["123","123"],"p":[prop,prop]})
    out = pw.regrouper_raisons(df)
    assert len(out) == 1
    assert out.loc[0,"Raisons"] == raison
