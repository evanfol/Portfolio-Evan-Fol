import sys
import projet_bge_main as main

def test_lire_arguments_defaut(monkeypatch):
    monkeypatch.setattr(sys,"argv",["projet_bge_main.py"])
    assert main.lire_arguments().test is None

def test_lire_arguments_test(monkeypatch):
    monkeypatch.setattr(sys,"argv",["projet_bge_main.py","--test","5"])
    assert main.lire_arguments().test == 5
