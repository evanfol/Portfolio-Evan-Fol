import lieupubliidref as m

def test_extraire_ppn_uri():
    assert m.extraire_ppn_uri("https://www.idref.fr/027089215") == "027089215"
    assert m.extraire_ppn_uri("https://www.sudoc.fr/12345678X") == "12345678X"
    assert m.extraire_ppn_uri(None) is None

def test_extraire_annee():
    assert m.extraire_annee("né en 1987") == 1987
    assert m.extraire_annee("sans date") is None
