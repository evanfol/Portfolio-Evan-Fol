import pytest
import bnf

@pytest.mark.parametrize("entree,attendu", [
    ("cb123456789","123456789"),
    ("123456789.0","123456789"),
    (" 123-456 ","123456"),
    ("",None),(None,None),
])
def test_normaliser_bnf_id(entree, attendu):
    assert bnf.normaliser_bnf_id(entree) == attendu

def test_nettoyer_texte():
    assert bnf.nettoyer_texte("  Bonjour  ") == "Bonjour"
    assert bnf.nettoyer_texte("") is None

def test_extraire_annee():
    assert bnf.extraire_annee("Paris, 1987") == 1987
    assert bnf.extraire_annee("sans date") is None

def test_isbn():
    assert bnf.isbn10_valide("2070360024")
    assert bnf.isbn13_valide("9782070360024")
    assert bnf.isbn10_vers_13("2070360024") == "9782070360024"
    assert bnf.normaliser_isbn("978-2-07-036002-4") == "9782070360024"

def test_extraire_ark_bnf():
    assert bnf.extraire_ark_bnf("https://data.bnf.fr/ark:/12148/cb123456789") == "cb123456789"
