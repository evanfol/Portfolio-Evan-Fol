
import pandas as pd

from fusion import fusionner_sources
from pipeline import dedoublonner_ppn_isbn
from nettoyage import nettoyage


# ============================================================
# OUTILS DE TEST
# ============================================================

def executer_chaine_locale(
    resultats_auteurs,
    resultats_genevensia,
    dossier_output
):
    """
    Reproduit la partie locale principale du pipeline :

    1. fusion des sources
    2. dédoublonnage PPN + ISBN
    3. nettoyage final

    Aucun appel réseau n'est effectué.
    """

    df_fusion = fusionner_sources(
        resultats=resultats_auteurs,
        resultats_lieu=resultats_genevensia
    )

    df_dedoublonne = dedoublonner_ppn_isbn(
        df_fusion
    )

    df_final = nettoyage(
        df_dedoublonne,
        dossier_output
    )

    return {
        "fusion": df_fusion,
        "dedoublonne": df_dedoublonne,
        "final": df_final
    }


# ============================================================
# 1. CHAINE SIMPLE NETWORK -> FINAL
# ============================================================

def test_integration_network_vers_resultat_final(tmp_path):

    df_network = pd.DataFrame({
        "ppn": ["027089215"],
        "isbn_normalise": ["9782070360024"],
        "titre": ["Titre test"],
        "annee": ["2020"],
        "nomAuteur": ["Auteur Test"],
        "lieuPublication": ["Paris"],
        "editeur": ["Éditeur Test"],
        "sujet": ["Sujet Test"],
        "raisons": ["auteur"]
    })

    resultats = executer_chaine_locale(
        resultats_auteurs={
            "network": df_network
        },
        resultats_genevensia={},
        dossier_output=tmp_path
    )

    final = resultats["final"]

    assert len(final) == 1

    ligne = final.iloc[0]

    assert ligne["ppn"] == "027089215"
    assert ligne["isbn_normalise"] == "9782070360024"
    assert ligne["titre"] == "Titre test"
    assert ligne["annee"] == 2020
    assert ligne["Source"] == "NZ"
    assert ligne["Ensemble"] == "Auteur"


# ============================================================
# 2. PLUSIEURS SOURCES AUTEURS
# ============================================================

def test_integration_plusieurs_sources_auteurs(tmp_path):

    df_network = pd.DataFrame({
        "ppn": ["111111111"],
        "isbn_normalise": ["9782070360024"],
        "titre": ["Livre NZ"],
        "annee": [2020]
    })

    df_sudoc = pd.DataFrame({
        "ppn": ["222222222"],
        "isbn_normalise": ["9780306406157"],
        "titre": ["Livre SUDOC"],
        "annee": [2021]
    })

    df_bnf = pd.DataFrame({
        "ppn": ["333333333"],
        "isbn_normalise": ["9781861972712"],
        "titre": ["Livre BNF"],
        "annee": [2022]
    })

    resultats = executer_chaine_locale(
        resultats_auteurs={
            "network": df_network,
            "sudoc": df_sudoc,
            "bnf": df_bnf
        },
        resultats_genevensia={},
        dossier_output=tmp_path
    )

    final = resultats["final"]

    assert len(final) == 3

    assert set(final["Source"]) == {
        "NZ",
        "SUDOC",
        "BNF"
    }

    assert set(final["Ensemble"]) == {
        "Auteur"
    }


# ============================================================
# 3. GENEVENSIA -> DEPOT LEGAL
# ============================================================

def test_integration_genevensia_depot_legal(tmp_path):

    df_bnf = pd.DataFrame({
        "ppn": ["123456789"],
        "isbn_normalise": ["9782070360024"],
        "titre": ["Livre genevois"],
        "raisons": ["lieu_publication"]
    })

    resultats = executer_chaine_locale(
        resultats_auteurs={},
        resultats_genevensia={
            "bnf": df_bnf
        },
        dossier_output=tmp_path
    )

    final = resultats["final"]

    assert len(final) == 1

    ligne = final.iloc[0]

    assert ligne["Source"] == "BNF"
    assert ligne["Ensemble"] == "Dépôt légal"

    assert "TypeRecherche" not in final.columns


# ============================================================
# 4. GENEVENSIA SANS LIEU PUBLICATION
# ============================================================

def test_integration_genevensia_classique(tmp_path):

    df_idref = pd.DataFrame({
        "ppn": ["123456789"],
        "isbn_normalise": ["9782070360024"],
        "titre": ["Livre genevois"],
        "raisons": ["titre"]
    })

    resultats = executer_chaine_locale(
        resultats_auteurs={},
        resultats_genevensia={
            "idref": df_idref
        },
        dossier_output=tmp_path
    )

    final = resultats["final"]

    assert len(final) == 1

    assert final.iloc[0]["Source"] == "IDREF"
    assert final.iloc[0]["Ensemble"] == "Genevensia"


# ============================================================
# 5. MEME ISBN : AUTEUR + GENEVENSIA
# ============================================================

def test_integration_conserve_auteur_et_genevensia(tmp_path):

    df_auteur = pd.DataFrame({
        "ppn": ["111111111"],
        "isbn_normalise": ["9782070360024"],
        "titre": ["Même livre"],
        "raisons": ["auteur"]
    })

    df_genevensia = pd.DataFrame({
        "ppn": ["222222222"],
        "isbn_normalise": ["9782070360024"],
        "titre": ["Même livre"],
        "raisons": ["titre"]
    })

    resultats = executer_chaine_locale(
        resultats_auteurs={
            "bnf": df_auteur
        },
        resultats_genevensia={
            "bnf": df_genevensia
        },
        dossier_output=tmp_path
    )

    final = resultats["final"]

    assert len(final) == 2

    assert set(final["Ensemble"]) == {
        "Auteur",
        "Genevensia"
    }


# ============================================================
# 6. PRIORITE NZ SUR DOUBLON PPN + ISBN
# ============================================================

def test_integration_priorite_nz(tmp_path):

    df_network = pd.DataFrame({
        "ppn": ["027089215"],
        "isbn_normalise": ["9782070360024"],
        "titre": ["Titre NZ"]
    })

    df_sudoc = pd.DataFrame({
        "ppn": ["027089215"],
        "isbn_normalise": ["9782070360024"],
        "titre": ["Titre SUDOC"]
    })

    resultats = executer_chaine_locale(
        resultats_auteurs={
            "network": df_network,
            "sudoc": df_sudoc
        },
        resultats_genevensia={},
        dossier_output=tmp_path
    )

    dedoublonne = resultats["dedoublonne"]

    assert len(dedoublonne) == 1

    assert dedoublonne.iloc[0]["Source"] == "NZ"
    assert dedoublonne.iloc[0]["titre"] == "Titre NZ"


# ============================================================
# 7. PPN ABSENT : LIGNES CONSERVEES
# ============================================================

def test_integration_ppn_absent_conserve_doublons(tmp_path):

    df = pd.DataFrame({
        "ppn": [None, None],
        "isbn_normalise": [
            "9782070360024",
            "9782070360024"
        ],
        "titre": [
            "Livre A",
            "Livre B"
        ]
    })

    resultats = executer_chaine_locale(
        resultats_auteurs={
            "sudoc": df
        },
        resultats_genevensia={},
        dossier_output=tmp_path
    )

    final = resultats["final"]

    assert len(final) == 2


# ============================================================
# 8. FUSION DES RAISONS
# ============================================================

def test_integration_fusion_raisons(tmp_path):

    df = pd.DataFrame({
        "ppn": ["123456789"],
        "isbn_normalise": ["9782070360024"],
        "raisons": ["titre | sujet"],
        "Raisons.1": [
            "sujet | lieu_publication"
        ]
    })

    resultats = executer_chaine_locale(
        resultats_auteurs={
            "bnf": df
        },
        resultats_genevensia={},
        dossier_output=tmp_path
    )

    final = resultats["final"]

    assert final.iloc[0]["raisons"] == (
        "titre | sujet | lieu_publication"
    )

    assert "Raisons.1" not in final.columns


# ============================================================
# 9. FALLBACK NOMCOMPLET -> NOMAUTEUR
# ============================================================

def test_integration_nom_auteur_fallback(tmp_path):

    df = pd.DataFrame({
        "ppn": [
            "111111111",
            "222222222"
        ],
        "isbn_normalise": [
            "9782070360024",
            "9780306406157"
        ],
        "nomAuteur": [
            "",
            "Auteur existant"
        ],
        "NomComplet": [
            "Nom Wikidata",
            "Nom à ne pas utiliser"
        ]
    })

    resultats = executer_chaine_locale(
        resultats_auteurs={
            "network": df
        },
        resultats_genevensia={},
        dossier_output=tmp_path
    )

    final = resultats["final"]

    assert final.loc[
        final["ppn"] == "111111111",
        "nomAuteur"
    ].iloc[0] == "Nom Wikidata"

    assert final.loc[
        final["ppn"] == "222222222",
        "nomAuteur"
    ].iloc[0] == "Auteur existant"

    assert "NomComplet" not in final.columns


# ============================================================
# 10. TYPES FINAUX
# ============================================================

def test_integration_types_finaux(tmp_path):

    df = pd.DataFrame({
        "ppn": [
            "027089215.0"
        ],
        "isbn_normalise": [
            "9782070360024.0"
        ],
        "annee": [
            "2020"
        ]
    })

    resultats = executer_chaine_locale(
        resultats_auteurs={
            "network": df
        },
        resultats_genevensia={},
        dossier_output=tmp_path
    )

    final = resultats["final"]

    assert final.iloc[0]["ppn"] == "027089215"
    assert final.iloc[0]["isbn_normalise"] == "9782070360024"
    assert final.iloc[0]["annee"] == 2020

    assert str(final["annee"].dtype) == "Int64"


# ============================================================
# 11. CREATION DU FICHIER FINAL
# ============================================================

def test_integration_resultat_final_csv(tmp_path):

    df = pd.DataFrame({
        "ppn": ["027089215"],
        "isbn_normalise": [
            "9782070360024"
        ],
        "titre": ["Livre test"]
    })

    resultats = executer_chaine_locale(
        resultats_auteurs={
            "network": df
        },
        resultats_genevensia={},
        dossier_output=tmp_path
    )

    chemin = (
        tmp_path
        / "resultat_final.csv"
    )

    assert chemin.exists()

    relu = pd.read_csv(
        chemin,
        dtype="string"
    )

    assert len(relu) == 1
    assert (
        relu.iloc[0]["isbn_normalise"]
        == "9782070360024"
    )


# ============================================================
# 12. ORDRE DES COLONNES IMPORTANTES
# ============================================================

def test_integration_ordre_colonnes(tmp_path):

    df = pd.DataFrame({
        "editeur": ["Éditeur"],
        "titre": ["Livre"],
        "isbn_normalise": [
            "9782070360024"
        ],
        "ppn": ["027089215"],
        "annee": [2020],
        "nomAuteur": ["Auteur"]
    })

    resultats = executer_chaine_locale(
        resultats_auteurs={
            "network": df
        },
        resultats_genevensia={},
        dossier_output=tmp_path
    )

    final = resultats["final"]

    attendues = [
        "ppn",
        "isbn_normalise",
        "titre",
        "annee",
        "nomAuteur",
    ]

    positions = [
        final.columns.get_loc(colonne)
        for colonne in attendues
    ]

    assert positions == sorted(positions)
