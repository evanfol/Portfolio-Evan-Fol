import pytest
import dnb

@pytest.mark.parametrize("entree,attendu", [
    ("https://d-nb.info/gnd/171556755","171556755"),
    ("(DE-588)171556755","171556755"),
    ("GND:171556755","171556755"),
    ("",None),(None,None),
])
def test_normaliser_gnd(entree, attendu):
    assert dnb.normaliser_gnd(entree) == attendu

def test_nettoyer_texte():
    assert dnb.nettoyer_texte("  Test ") == "Test"
    assert dnb.nettoyer_texte("") is None

def test_extraire_annee():
    assert dnb.extraire_annee("erschienen 2020") == 2020
    assert dnb.extraire_annee("sans date") is None

def test_isbn():
    assert dnb.isbn10_valide("2070360024")
    assert dnb.isbn13_valide("9782070360024")
    assert dnb.normaliser_isbn("978-2-07-036002-4") == "9782070360024"

def test_parser_numerique_marcxml():
    xml = b'''<collection xmlns="http://www.loc.gov/MARC21/slim">
    <record><controlfield tag="001">123</controlfield><datafield tag="338"><subfield code="b">cr</subfield></datafield></record>
    <record><controlfield tag="001">456</controlfield><datafield tag="338"><subfield code="b">nc</subfield></datafield></record>
    </collection>'''
    assert dnb.parser_numerique_marcxml(xml, ["123","456"]) == {"123":True,"456":False}
