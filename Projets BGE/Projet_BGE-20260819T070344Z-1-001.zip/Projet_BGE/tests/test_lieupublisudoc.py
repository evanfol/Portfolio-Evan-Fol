import lieupublisudoc as m

def test_construire_regex_termes_vide():
    assert m.construire_regex_termes([]) is None

def test_construire_regex_termes():
    regex = m.construire_regex_termes(["geneve"])
    assert regex.search("geneve") is not None
    assert regex.search("xgenevex") is None

def test_normaliser_isbn():
    assert m.normaliser_isbn("978-2-07-036002-4") == "9782070360024"
    assert m.normaliser_isbn("2070360024") == "9782070360024"
    assert m.normaliser_isbn("abc") is None
