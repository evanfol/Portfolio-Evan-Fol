import threading
import xml.etree.ElementTree as ET
import pandas as pd
import pytest

from utils import (
    charger_liste, creer_lots, concat_unique, valeur, normaliser_isbn,
    normaliser_texte, normaliser_ppn, creer_session_http,
    obtenir_session_thread, echapper_requete, nom_local_xml,
)

def test_charger_liste(tmp_path):
    f = tmp_path / "liste.txt"
    f.write_text(' "Genève",\nLausanne\n\n', encoding="utf-8")
    assert charger_liste(f) == ["Genève", "Lausanne"]

def test_charger_liste_dedoublonne(tmp_path):
    f = tmp_path / "liste.txt"
    f.write_text("Genève\nLausanne\nGenève\n", encoding="utf-8")
    assert charger_liste(f, dedoublonner=True) == ["Genève", "Lausanne"]

def test_charger_liste_fichier_absent(tmp_path):
    with pytest.raises(FileNotFoundError):
        charger_liste(tmp_path / "absent.txt")

def test_charger_liste_vide(tmp_path):
    f = tmp_path / "vide.txt"
    f.write_text("\n\n", encoding="utf-8")
    with pytest.raises(ValueError):
        charger_liste(f)

def test_creer_lots():
    assert list(creer_lots([1,2,3,4,5], 2)) == [[1,2],[3,4],[5]]

def test_creer_lots_taille_exacte():
    assert list(creer_lots([1,2,3,4], 2)) == [[1,2],[3,4]]

def test_creer_lots_liste_vide():
    assert list(creer_lots([], 2)) == []

def test_concat_unique():
    assert concat_unique(["Genève","Lausanne","Genève",None,""]) == "Genève | Lausanne"

def test_concat_unique_liste_vide():
    assert concat_unique([]) == ""

def test_concat_unique_sans_tri():
    assert concat_unique(["Genève","Lausanne","Genève","Berne"], trier=False) == "Genève | Lausanne | Berne"

def test_valeur_existante():
    assert valeur({"x":{"value":"abc"}}, "x") == "abc"

def test_valeur_absente():
    assert valeur({}, "x") is None

@pytest.mark.parametrize("entree,attendu", [
    ("9782070360024","9782070360024"),
    ("978-2-07-036002-4","9782070360024"),
    ("978 2 07 036002 4","9782070360024"),
    ("2070360024","9782070360024"),
    ("9782070360025",None),
    ("2070360025",None),
    ("123456",None),
    (None,None),
])
def test_normaliser_isbn(entree, attendu):
    assert normaliser_isbn(entree) == attendu

@pytest.mark.parametrize("entree,attendu", [
    (" Genève ","geneve"),
    ("ŒUVRE","oeuvre"),
    ("encyclopædie","encyclopaedie"),
    ("l’école","l'ecole"),
    (None,""),
])
def test_normaliser_texte(entree, attendu):
    assert normaliser_texte(entree) == attendu

@pytest.mark.parametrize("entree,attendu", [
    ("027089215","027089215"),
    ("PPN 027089215","027089215"),
    ("12345678X","12345678X"),
    ("abc",None),
    (None,None),
])
def test_normaliser_ppn(entree, attendu):
    assert normaliser_ppn(entree) == attendu

def test_creer_session_http_headers():
    s = creer_session_http(2, 0.1, ["GET"], 3, headers={"X-Test":"ok"})
    assert s.headers["X-Test"] == "ok"
    assert "https://" in s.adapters

def test_obtenir_session_thread_reutilise_objet():
    local = threading.local()
    appels = {"n":0}
    def factory():
        appels["n"] += 1
        return object()
    a = obtenir_session_thread(local, factory)
    b = obtenir_session_thread(local, factory)
    assert a is b
    assert appels["n"] == 1

def test_echapper_requete():
    assert echapper_requete('a\\b"c') == 'a\\\\b\\\"c'

def test_nom_local_xml_namespace():
    element = ET.fromstring('<x:record xmlns:x="urn:test"/>')
    assert nom_local_xml(element) == "record"

def test_nom_local_xml_none():
    assert nom_local_xml(None) == ""
