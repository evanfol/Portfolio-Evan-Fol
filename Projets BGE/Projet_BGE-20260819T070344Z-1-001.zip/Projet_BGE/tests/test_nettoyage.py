import pandas as pd
import pytest
from nettoyage import nettoyage

def test_nettoyage_none(tmp_path):
    with pytest.raises(ValueError):
        nettoyage(None, tmp_path)

def test_nettoyage_type_invalide(tmp_path):
    with pytest.raises(TypeError):
        nettoyage([], tmp_path)

def test_nettoyage_supprime_colonnes_inutiles(tmp_path):
    df = pd.DataFrame({"ppn":["1"],"isbn_normalise":["9782070360024"],"bnf_id":["x"],"gnd_id":["y"],"isbn":["z"]})
    out = nettoyage(df, tmp_path)
    assert all(c not in out.columns for c in ["bnf_id","gnd_id","isbn"])

def test_nettoyage_fusionne_raisons(tmp_path):
    df = pd.DataFrame({"ppn":["1"],"isbn_normalise":["9782070360024"],"raisons":["titre | sujet"],"Raisons.1":["sujet | lieu_publication"]})
    out = nettoyage(df, tmp_path)
    assert out.loc[0,"raisons"] == "titre | sujet | lieu_publication"
    assert "Raisons.1" not in out.columns

def test_nettoyage_ensemble(tmp_path):
    df = pd.DataFrame({
        "ppn":["1","2","3"],
        "isbn_normalise":["9782070360024"]*3,
        "TypeRecherche":["Genevensia","Genevensia","Auteur"],
        "raisons":["lieu_publication","titre","titre"],
    })
    out = nettoyage(df, tmp_path)
    assert out["Ensemble"].tolist() == ["Dépôt légal","Genevensia","Auteur"]

def test_nettoyage_nom_auteur_fallback(tmp_path):
    df = pd.DataFrame({
        "ppn":["1","2"],
        "isbn_normalise":["9782070360024"]*2,
        "nomAuteur":["","Auteur existant"],
        "NomComplet":["Nom fallback","Autre nom"],
    })
    out = nettoyage(df, tmp_path)
    assert out.loc[0,"nomAuteur"] == "Nom fallback"
    assert out.loc[1,"nomAuteur"] == "Auteur existant"

def test_nettoyage_annee_int64(tmp_path):
    df = pd.DataFrame({"ppn":["1","2"],"isbn_normalise":["9782070360024"]*2,"annee":["2020","inconnue"]})
    out = nettoyage(df, tmp_path)
    assert str(out["annee"].dtype) == "Int64"
    assert out.loc[0,"annee"] == 2020
    assert pd.isna(out.loc[1,"annee"])

def test_nettoyage_cree_csv(tmp_path):
    df = pd.DataFrame({"ppn":["1"],"isbn_normalise":["9782070360024"]})
    out = nettoyage(df, tmp_path)
    assert "Acquisition" in out.columns
    assert (tmp_path/"resultat_final.csv").is_file()
