"""
Module DNB optimisé.

Pipeline principal :
1. Normalisation des identifiants GND et des ISBN.
2. Recherche SPARQL DNB des documents liés aux autorités GND.
3. Agrégation des métadonnées afin de limiter le volume retourné.
4. Contrôle MARC21 du champ 338$b.
5. Exclusion des ressources en ligne lorsque 338$b = "cr".
6. Dédoublonnage GND + ISBN puis fusion avec le DataFrame source.

Principes de robustesse :
- sessions HTTP réutilisées par thread ;
- traitement SPARQL par lots ;
- fallback récursif lorsqu'un lot échoue ;
- contrôle MARC ciblé uniquement sur les IDN DNB obtenus ;
- un IDN absent d'une réponse SRU n'est jamais considéré
  automatiquement comme physique : il est retenté.
"""

import requests
import pandas as pd
import re
import time
import threading
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
DNB_SPARQL_URL = 'https://sparql.dnb.de/api/dnbgnd'
DNB_SRU_URL = 'https://services.dnb.de/sru/dnb'
DNB_MARC_BATCH_SIZE = 20
DNB_MARC_WORKERS = 6
DNB_BATCH_SIZE = 100
DNB_WORKERS = 4
CONNECT_TIMEOUT = 10
READ_TIMEOUT = 120
MAX_RETRIES = 4
thread_local = threading.local()

# ============================================================
# SESSION HTTP PAR THREAD
# Chaque thread possède sa propre Session requests afin de profiter
# du pooling des connexions tout en évitant le partage concurrent
# d'une même Session.
# ============================================================
def creer_session():
    session = requests.Session()
    retry = Retry(total=MAX_RETRIES, connect=MAX_RETRIES, read=MAX_RETRIES, status=MAX_RETRIES, backoff_factor=0.8, status_forcelist=[429, 500, 502, 503, 504], allowed_methods=['GET', 'POST'], raise_on_status=False)
    adapter = HTTPAdapter(max_retries=retry, pool_connections=DNB_WORKERS + 2, pool_maxsize=DNB_WORKERS + 2)
    session.mount('https://', adapter)
    session.headers.update({'User-Agent': 'Geneve-Bibliographic-Research-DNB/1.0', 'Accept': 'application/sparql-results+json', 'Accept-Encoding': 'gzip, deflate'})
    return session

def obtenir_session():
    if not hasattr(thread_local, 'session'):
        thread_local.session = creer_session()
    return thread_local.session

# ============================================================
# NORMALISATION GND
# Accepte les formes URL, (DE-588)xxxxxxxx et GND:xxxxxxxx.
# ============================================================
def normaliser_gnd(valeur):
    if pd.isna(valeur):
        return None
    valeur = str(valeur).strip()
    if not valeur:
        return None
    match = re.search('d-nb\\.info/gnd/([^/?#]+)', valeur, re.I)
    if match:
        valeur = match.group(1).strip()
    valeur = re.sub('^\\(DE-588\\)', '', valeur, flags=re.I)
    valeur = re.sub('^GND\\s*:\\s*', '', valeur, flags=re.I)
    valeur = valeur.strip()
    return valeur or None
ISBN10_RE = re.compile('\\d{9}[\\dX]')
ISBN13_RE = re.compile('\\d{13}')
ISBN_NETTOYAGE_RE = re.compile('[^0-9X]')

# ============================================================
# ISBN
# Validation ISBN-10 / ISBN-13 et conversion des ISBN-10 valides
# vers ISBN-13 pour obtenir un format homogène.
# ============================================================
def isbn10_valide(isbn):
    if not ISBN10_RE.fullmatch(isbn):
        return False
    total = 0
    for i, c in enumerate(isbn):
        valeur = 10 if c == 'X' else int(c)
        total += (10 - i) * valeur
    return total % 11 == 0

def isbn13_valide(isbn):
    if not ISBN13_RE.fullmatch(isbn):
        return False
    somme = 0
    for i, c in enumerate(isbn[:12]):
        n = int(c)
        somme += n if i % 2 == 0 else n * 3
    cle = (10 - somme % 10) % 10
    return cle == int(isbn[-1])

def isbn10_vers_13(isbn10):
    base = '978' + isbn10[:9]
    somme = 0
    for i, c in enumerate(base):
        n = int(c)
        somme += n if i % 2 == 0 else n * 3
    cle = (10 - somme % 10) % 10
    return base + str(cle)

def normaliser_isbn(valeur):
    if not valeur:
        return None
    isbn = ISBN_NETTOYAGE_RE.sub('', str(valeur).upper().strip())
    if len(isbn) == 13:
        if isbn13_valide(isbn):
            return isbn
        return None
    if len(isbn) == 10:
        if not isbn10_valide(isbn):
            return None
        isbn13 = isbn10_vers_13(isbn)
        if isbn13_valide(isbn13):
            return isbn13
    return None
ANNEE_RE = re.compile('\\b(1[0-9]{3}|20[0-9]{2}|21[0-9]{2})\\b')

# ============================================================
# OUTILS TEXTE / ANNÉE
# ============================================================
def nettoyer_texte(valeur):
    if valeur is None:
        return None
    valeur = str(valeur).strip()
    return valeur or None

def extraire_annee(valeur):
    if not valeur:
        return None
    match = ANNEE_RE.search(str(valeur))
    if not match:
        return None
    return int(match.group(1))
DNB_ID_RE = re.compile('https?://d-nb\\.info/([^/?#]+)', re.I)

# ============================================================
# EXTRACTION DE L'IDN DNB
# Extrait l'identifiant depuis les URI https://d-nb.info/<IDN>.
# ============================================================
def extraire_idn_dnb(uri):
    if not uri:
        return None
    match = DNB_ID_RE.search(uri)
    if not match:
        return None
    return match.group(1).strip()
MARC_NS = 'http://www.loc.gov/MARC21/slim'

# ============================================================
# CONTRÔLE MARC21 338$b
# 338$b = 'cr' signifie ressource en ligne : la notice est exclue.
# Le contrôle est effectué une seule fois par IDN DNB unique.
# ============================================================
def construire_requete_sru_idn(liste_idn):
    """Construit une requête CQL portant sur plusieurs IDN DNB."""
    return ' OR '.join((f'dnb.idn="{idn}"' for idn in liste_idn))

# Parse une réponse MARC21-XML et retourne {idn: bool}.
# Un IDN absent de la réponse reste manquant afin d'être retenté,
# plutôt que d'être considéré à tort comme document physique.
def parser_numerique_marcxml(xml_bytes, idn_attendus):
    """
    Retourne {idn: bool}.

    bool=True uniquement si au moins un 338 $b vaut exactement "cr"
    (comparaison insensible à la casse et aux espaces).
    """
    root = ET.fromstring(xml_bytes)
    resultats = {}
    for record in root.findall(f'.//{{{MARC_NS}}}record'):
        idn = None
        for controlfield in record.findall(f'{{{MARC_NS}}}controlfield'):
            if controlfield.get('tag') == '001':
                idn = (controlfield.text or '').strip()
                break
        if not idn:
            continue
        numerique = False
        for datafield in record.findall(f'{{{MARC_NS}}}datafield'):
            if datafield.get('tag') != '338':
                continue
            for subfield in datafield.findall(f'{{{MARC_NS}}}subfield'):
                if subfield.get('code') != 'b':
                    continue
                valeur = (subfield.text or '').strip().lower()
                if valeur == 'cr':
                    numerique = True
                    break
            if numerique:
                break
        resultats[idn] = numerique
    return {idn: resultats[idn] for idn in idn_attendus if idn in resultats}

def executer_requete_marc_dnb(liste_idn):
    """Interroge le SRU DNB et lit les notices en MARC21-XML."""
    session = obtenir_session()
    response = session.get(DNB_SRU_URL, params={'version': '1.1', 'operation': 'searchRetrieve', 'query': construire_requete_sru_idn(liste_idn), 'recordSchema': 'MARC21-xml', 'maximumRecords': len(liste_idn)}, headers={'Accept': 'application/xml, text/xml;q=0.9, */*;q=0.1'}, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
    response.raise_for_status()
    return parser_numerique_marcxml(response.content, liste_idn)

# Fallback récursif MARC :
# en cas d'erreur ou de notice manquante, le lot est divisé en deux
# jusqu'à isoler l'IDN problématique.
def verifier_lot_marc_robuste(liste_idn):
    """
    Contrôle robuste d'un lot.

    En cas d'erreur le lot est divisé récursivement, exactement comme
    pour la partie SPARQL, afin qu'un seul IDN problématique ne fasse
    pas perdre tout le lot.
    """
    try:
        resultats = executer_requete_marc_dnb(liste_idn)
        manquants = [idn for idn in liste_idn if idn not in resultats]
        if manquants:
            if len(liste_idn) == 1:
                return (resultats, [{'idn_dnb': liste_idn[0], 'erreur': 'Notice MARC absente de la réponse SRU'}])
            milieu = len(liste_idn) // 2
            gauche, erreurs_gauche = verifier_lot_marc_robuste(liste_idn[:milieu])
            droite, erreurs_droite = verifier_lot_marc_robuste(liste_idn[milieu:])
            gauche.update(droite)
            return (gauche, erreurs_gauche + erreurs_droite)
        return (resultats, [])
    except Exception as e:
        if len(liste_idn) <= 1:
            return ({}, [{'idn_dnb': liste_idn[0], 'erreur': f'{type(e).__name__}: {e}'}])
        milieu = len(liste_idn) // 2
        gauche, erreurs_gauche = verifier_lot_marc_robuste(liste_idn[:milieu])
        droite, erreurs_droite = verifier_lot_marc_robuste(liste_idn[milieu:])
        gauche.update(droite)
        return (gauche, erreurs_gauche + erreurs_droite)

# ============================================================
# FILTRE DES RESSOURCES NUMÉRIQUES
# Exclut toutes les lignes dont l'IDN possède un champ 338$b = 'cr'.
# Les lots MARC sont exécutés en parallèle.
# ============================================================
def filtrer_notices_numeriques_dnb(df_dnb, batch_size=DNB_MARC_BATCH_SIZE, max_workers=DNB_MARC_WORKERS):
    """
    Retire toutes les lignes appartenant à une notice dont 338 $b = cr.

    Retourne :
        df_filtre,
        erreurs_marc,
        nb_numeriques,
        duree
    """
    debut = time.perf_counter()
    if df_dnb.empty:
        return (df_dnb, [], 0, 0.0)
    liste_idn = df_dnb['idn_dnb'].dropna().astype(str).drop_duplicates().tolist()
    lots = [liste_idn[i:i + batch_size] for i in range(0, len(liste_idn), batch_size)]
    statut_numerique = {}
    erreurs = []
    print()
    print('=' * 80)
    print('2/3 — CONTRÔLE MARC 338 $b = cr')
    print('=' * 80)
    print(f'IDN uniques        : {len(liste_idn):,}')
    print(f'IDN / requête SRU  : {batch_size}')
    print(f'Requêtes prévues   : {len(lots):,}')
    print(f'Workers             : {max_workers}')
    print('=' * 80)
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(verifier_lot_marc_robuste, lot): numero for numero, lot in enumerate(lots, start=1)}
        termines = 0
        for future in as_completed(futures):
            termines += 1
            numero = futures[future]
            try:
                resultats_lot, erreurs_lot = future.result()
                statut_numerique.update(resultats_lot)
                erreurs.extend(erreurs_lot)
            except Exception as e:
                erreurs.append({'lot': numero, 'erreur': f'{type(e).__name__}: {e}'})
            if termines == 1 or termines == len(lots) or termines % 10 == 0:
                print(f'[{termines:>3}/{len(lots)}] IDN contrôlés : {len(statut_numerique):,} | erreurs : {len(erreurs):,}')
    idn_numeriques = {idn for idn, numerique in statut_numerique.items() if numerique}
    masque_numerique = df_dnb['idn_dnb'].astype(str).isin(idn_numeriques)
    df_filtre = df_dnb.loc[~masque_numerique].copy()
    duree = time.perf_counter() - debut
    print()
    print(f'Notices numériques : {len(idn_numeriques):,}')
    print(f'Lignes exclues      : {int(masque_numerique.sum()):,}')
    print(f'Erreurs MARC        : {len(erreurs):,}')
    print(f'Durée contrôle MARC : {duree:.2f} s')
    return (df_filtre, erreurs, len(idn_numeriques), duree)

# ============================================================
# CONSTRUCTION DE LA REQUÊTE SPARQL DNB
# Les métadonnées sont agrégées directement dans SPARQL avec SAMPLE
# et GROUP_CONCAT afin d'éviter l'explosion titre × lieu × éditeur.
# Les relations dct:creator et relators/aut sont toutes deux utilisées.
# ============================================================
def construire_requete_dnb(liste_gnd):
    values = '\n'.join((f'("{gnd}" <https://d-nb.info/gnd/{gnd}>)' for gnd in liste_gnd))
    query = f"""\n\nPREFIX dc:\n    <http://purl.org/dc/elements/1.1/>\n\nPREFIX dct:\n    <http://purl.org/dc/terms/>\n\nPREFIX bibo:\n    <http://purl.org/ontology/bibo/>\n\nPREFIX rdau:\n    <http://rdaregistry.info/Elements/u/>\n\nPREFIX gndo:\n    <https://d-nb.info/standards/elementset/gnd#>\n\n\nSELECT\n\n    ?gnd\n    ?document\n    ?isbn\n\n    (SAMPLE(?titreValeur)\n        AS ?titre)\n\n    (SAMPLE(?anneeValeur)\n        AS ?annee)\n\n    (SAMPLE(?auteurNomValeur)\n        AS ?nomAuteur)\n\n    (\n        GROUP_CONCAT(\n            DISTINCT STR(?lieuValeur);\n            separator=" - "\n        )\n        AS ?lieuPublication\n    )\n\n    (\n        GROUP_CONCAT(\n            DISTINCT STR(?editeurValeur);\n            separator=" - "\n        )\n        AS ?editeur\n    )\n\n\nWHERE {{\n\n    # ========================================================\n    # GND DEMANDÉS\n    # ========================================================\n\n    VALUES (?gnd ?auteur) {{\n\n        {values}\n\n    }}\n\n\n    # ========================================================\n    # RELATION AUTEUR\n    #\n    # Les tests ont montré :\n    #\n    # dct:creator       = incomplet\n    # relators/aut      = plus complet\n    #\n    # On garde donc les deux.\n    # ========================================================\n\n    {{\n\n        ?document\n            dct:creator\n            ?auteur .\n\n    }}\n\n    UNION\n\n    {{\n\n        ?document\n            <http://id.loc.gov/vocabulary/relators/aut>\n            ?auteur .\n\n    }}\n\n\n    # ========================================================\n    # ISBN\n    #\n    # La DNB utilise :\n    #\n    # bibo:isbn13\n    # bibo:isbn10\n    #\n    # et NON bibo:isbn.\n    # ========================================================\n\n    {{\n\n        ?document\n            bibo:isbn13\n            ?isbn .\n\n    }}\n\n    UNION\n\n    {{\n\n        ?document\n            bibo:isbn10\n            ?isbn .\n\n    }}\n\n\n    # ========================================================\n    # TITRE\n    # ========================================================\n\n    OPTIONAL {{\n\n        ?document\n            dc:title\n            ?titreValeur .\n\n    }}\n\n\n    # ========================================================\n    # ANNÉE\n    # ========================================================\n\n    OPTIONAL {{\n\n        ?document\n            dct:issued\n            ?anneeValeur .\n\n    }}\n\n\n    # ========================================================\n    # LIEU\n    # ========================================================\n\n    OPTIONAL {{\n\n        ?document\n            rdau:P60163\n            ?lieuValeur .\n\n    }}\n\n\n    # ========================================================\n    # EDITEUR\n    # ========================================================\n\n    OPTIONAL {{\n\n        ?document\n            dc:publisher\n            ?editeurValeur .\n\n    }}\n\n\n    # ========================================================\n    # NOM DE L'AUTEUR\n    # ========================================================\n\n    OPTIONAL {{\n\n        ?auteur\n            gndo:preferredNameForThePerson\n            ?auteurNomValeur .\n\n    }}\n\n}}\n\nGROUP BY\n\n    ?gnd\n    ?document\n    ?isbn\n\n"""
    return query

def executer_requete_dnb(liste_gnd):
    session = obtenir_session()
    query = construire_requete_dnb(liste_gnd)
    response = session.post(DNB_SPARQL_URL, data={'query': query}, headers={'Accept': 'application/sparql-results+json'}, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
    response.raise_for_status()
    data = response.json()
    return data.get('results', {}).get('bindings', [])

# Fallback récursif SPARQL :
# lorsqu'un lot échoue, il est divisé jusqu'au GND individuel afin
# de ne pas perdre les autres résultats.
def requete_dnb_robuste(liste_gnd):
    try:
        bindings = executer_requete_dnb(liste_gnd)
        return (bindings, [])
    except Exception as e:
        if len(liste_gnd) <= 1:
            return ([], [{'gnd': liste_gnd[0], 'erreur': f'{type(e).__name__}: {e}'}])
        milieu = len(liste_gnd) // 2
        bindings_gauche, erreurs_gauche = requete_dnb_robuste(liste_gnd[:milieu])
        bindings_droite, erreurs_droite = requete_dnb_robuste(liste_gnd[milieu:])
        return (bindings_gauche + bindings_droite, erreurs_gauche + erreurs_droite)

# ============================================================
# PARSING DES RÉSULTATS SPARQL
# Ne conserve que les documents ayant un IDN DNB et un ISBN valide.
# ============================================================
def parser_bindings_dnb(bindings):
    lignes = []
    append = lignes.append
    for ligne in bindings:
        gnd = ligne.get('gnd', {}).get('value')
        if not gnd:
            continue
        document = ligne.get('document', {}).get('value')
        idn_dnb = extraire_idn_dnb(document)
        if not idn_dnb:
            continue
        isbn_brut = ligne.get('isbn', {}).get('value')
        isbn = normaliser_isbn(isbn_brut)
        if not isbn:
            continue
        titre = nettoyer_texte(ligne.get('titre', {}).get('value'))
        annee = extraire_annee(ligne.get('annee', {}).get('value'))
        nom_auteur = nettoyer_texte(ligne.get('nomAuteur', {}).get('value'))
        lieu = nettoyer_texte(ligne.get('lieuPublication', {}).get('value'))
        if lieu == '':
            lieu = None
        editeur = nettoyer_texte(ligne.get('editeur', {}).get('value'))
        if editeur == '':
            editeur = None
        append({'_gnd_requete': gnd, 'idn_dnb': idn_dnb, 'isbn_normalise': isbn, 'titre': titre, 'annee': annee, 'nomAuteur': nom_auteur, 'lieuPublication': lieu, 'editeur': editeur})
    return lignes

def traiter_lot_dnb(numero_lot, lot):
    debut = time.perf_counter()
    bindings, erreurs = requete_dnb_robuste(lot)
    lignes = parser_bindings_dnb(bindings)
    duree = time.perf_counter() - debut
    return {'numero_lot': numero_lot, 'lignes': lignes, 'erreurs': erreurs, 'duree': duree}

# ============================================================
# RÉCUPÉRATION PARALLÈLE DES LOTS SPARQL DNB
# ============================================================
def recuperer_toutes_notices_dnb(liste_gnd, batch_size=DNB_BATCH_SIZE, max_workers=DNB_WORKERS):
    lots = [liste_gnd[i:i + batch_size] for i in range(0, len(liste_gnd), batch_size)]
    nb_lots = len(lots)
    toutes_lignes = []
    toutes_erreurs = []
    print()
    print('=' * 80)
    print('1/2 — RÉCUPÉRATION SPARQL DNB')
    print('=' * 80)
    print(f'GND uniques       : {len(liste_gnd):,}')
    print(f'GND / requête     : {batch_size}')
    print(f'Requêtes prévues  : {nb_lots:,}')
    print(f'Workers            : {max_workers}')
    print('=' * 80)
    debut = time.perf_counter()
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(traiter_lot_dnb, numero, lot): numero for numero, lot in enumerate(lots, start=1)}
        termines = 0
        for future in as_completed(futures):
            termines += 1
            try:
                resultat = future.result()
                toutes_lignes.extend(resultat['lignes'])
                toutes_erreurs.extend(resultat['erreurs'])
                duree_lot = resultat['duree']
                numero_lot = resultat['numero_lot']
            except Exception as e:
                numero_lot = futures[future]
                duree_lot = 0
                print(f'Erreur inattendue lot {numero_lot}: {type(e).__name__}: {e}')
            print(f'[{termines:>3}/{nb_lots}] lot {numero_lot:>3} | {duree_lot:>6.2f} s | lignes cumulées : {len(toutes_lignes):,} | erreurs : {len(toutes_erreurs):,}')
    duree = time.perf_counter() - debut
    return (toutes_lignes, toutes_erreurs, duree)

# ============================================================
# FONCTION PRINCIPALE DE PRODUCTION
# Enrichit un DataFrame contenant des identifiants GND, filtre les
# ressources numériques, dédoublonne GND + ISBN puis fusionne les
# métadonnées DNB avec les lignes source.
# ============================================================
def ajouter_isbn_dnb_ultra(df, colonne_gnd='gnd_id', dnb_batch_size=DNB_BATCH_SIZE, dnb_workers=DNB_WORKERS):
    debut_total = time.perf_counter()
    if colonne_gnd not in df.columns:
        raise ValueError(f"La colonne '{colonne_gnd}' n'existe pas.")
    # Travail sur une copie afin de préserver le DataFrame d'entrée.
    source = df.copy()
    colonnes_dnb = ['idn_dnb', 'isbn_normalise', 'titre', 'annee', 'nomAuteur', 'lieuPublication', 'editeur']
    source.drop(columns=[col for col in colonnes_dnb if col in source.columns], errors='ignore', inplace=True)
    colonnes_originales = list(source.columns)
    # Colonne technique normalisée utilisée pour les requêtes et le merge.
    source['_gnd_requete'] = source[colonne_gnd].map(normaliser_gnd)
    liste_gnd = source['_gnd_requete'].dropna().drop_duplicates().tolist()
    print()
    print('#' * 80)
    print('DNB — VERSION FINALE OPTIMISÉE')
    print('#' * 80)
    print(f'Lignes source       : {len(source):,}')
    print(f'GND uniques         : {len(liste_gnd):,}')
    print(f'Batch size          : {dnb_batch_size}')
    print(f'Workers             : {dnb_workers}')
    if not liste_gnd:
        print('\nAucun identifiant GND.')
        return pd.DataFrame(columns=colonnes_originales + colonnes_dnb)
    lignes, erreurs, duree_dnb = recuperer_toutes_notices_dnb(liste_gnd, batch_size=dnb_batch_size, max_workers=dnb_workers)
    print()
    print('=' * 80)
    print('3/3 — CONSTRUCTION DU DATAFRAME')
    print('=' * 80)
    debut_dataframe = time.perf_counter()
    if not lignes:
        print('\nAucun ISBN DNB trouvé.')
        resultat = pd.DataFrame(columns=colonnes_originales + colonnes_dnb)
        resultat.attrs['erreurs_dnb'] = erreurs
        return resultat
    df_dnb = pd.DataFrame.from_records(lignes)
    # Filtre avant dédoublonnage : une notice numérique est exclue entièrement.
    df_dnb, erreurs_marc, nb_notices_numeriques, duree_marc = filtrer_notices_numeriques_dnb(df_dnb, batch_size=DNB_MARC_BATCH_SIZE, max_workers=DNB_MARC_WORKERS)
    erreurs.extend(({'type': 'MARC338', **erreur} for erreur in erreurs_marc))
    nb_avant_dedup = len(df_dnb)
    df_dnb.drop_duplicates(subset=['_gnd_requete', 'isbn_normalise'], keep='first', inplace=True)
    nb_apres_dedup = len(df_dnb)
    resultat = source.merge(df_dnb, on='_gnd_requete', how='inner', sort=False, copy=False)
    resultat.drop(columns=['_gnd_requete'], inplace=True)
    resultat = resultat[colonnes_originales + colonnes_dnb]
    resultat[colonne_gnd] = resultat[colonne_gnd].astype('string')
    resultat['idn_dnb'] = resultat['idn_dnb'].astype('string')
    resultat['isbn_normalise'] = resultat['isbn_normalise'].astype('string')
    resultat['annee'] = pd.to_numeric(resultat['annee'], errors='coerce').astype('Int64')
    resultat.reset_index(drop=True, inplace=True)
    resultat.attrs['erreurs_dnb'] = erreurs
    duree_dataframe = time.perf_counter() - debut_dataframe
    duree_totale = time.perf_counter() - debut_total
    nb_gnd_resultats = df_dnb['_gnd_requete'].nunique()
    nb_idn = df_dnb['idn_dnb'].nunique()
    nb_isbn = df_dnb['isbn_normalise'].nunique()
    print()
    print('#' * 80)
    print('TERMINÉ')
    print('#' * 80)
    print()
    print(f'SPARQL DNB          : {duree_dnb:.2f} s')
    print(f'Contrôle MARC 338   : {duree_marc:.2f} s')
    print(f'DataFrame           : {duree_dataframe:.2f} s')
    print(f'DURÉE TOTALE        : {duree_totale:.2f} s ({duree_totale / 60:.2f} min)')
    print()
    print(f'GND recherchés      : {len(liste_gnd):,}')
    print(f'GND avec ISBN       : {nb_gnd_resultats:,}')
    print(f'GND sans ISBN       : {len(liste_gnd) - nb_gnd_resultats:,}')
    print()
    print(f'Notices numériques exclues : {nb_notices_numeriques:,}')
    print(f'IDN DNB uniques     : {nb_idn:,}')
    print(f'ISBN uniques        : {nb_isbn:,}')
    print()
    print(f'Lignes avant dedup  : {nb_avant_dedup:,}')
    print(f'Lignes après dedup  : {nb_apres_dedup:,}')
    print(f'Lignes finales      : {len(resultat):,}')
    print()
    print(f'Erreurs définitives : {len(erreurs):,}')
    print()
    print('Complétude :')
    for colonne in ['titre', 'annee', 'nomAuteur', 'lieuPublication', 'editeur']:
        nb = resultat[colonne].notna().sum()
        print(f'{colonne:<20}: {nb:,}/{len(resultat):,}')
    print('#' * 80)
    return resultat