import requests
import pandas as pd
import re
import threading
import time
import random
import xml.etree.ElementTree as ET

from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.adapters import HTTPAdapter
from config import FICHIER_COMMUNES, FICHIER_TITRES
from utils import (
    charger_liste,
    creer_lots,
    concat_unique,
    normaliser_texte,
    normaliser_isbn,
    creer_session_http,
    obtenir_session_thread,
    nom_local_xml,
    afficher_section,
)

ENDPOINT_URL = "https://data.bnf.fr/sparql"

MAX_WORKERS = 5

# Enrichissement par lots
MAX_WORKERS_ENRICHISSEMENT = 4
TAILLE_LOT_ENRICHISSEMENT = 150

TIMEOUT = 180
MAX_RETRIES = 3

HEADERS = {
    "Accept": "application/sparql-results+json",
    "User-Agent": "Mozilla/5.0"
}

SRU_BNF_URL = "https://catalogue.bnf.fr/api/SRU"

SRU_WORKERS = 20
SRU_MAX_ARKS_PAR_LOT = 50
SRU_CONNECT_TIMEOUT = 10
SRU_READ_TIMEOUT = 45
SRU_RETRIES = 3

PARAMS_SRU_BNF = {
    "version": "1.2",
    "operation": "searchRetrieve",
    "recordSchema": "unimarcXchange",
    "startRecord": 1,}

COLONNES_ENRICHISSEMENT = (
    "titre",
    "annee",
    "lieuPublication",
    "editeur",
    "auteur",
    "nomAuteur",
    "sujet",
    "uri",)

COLONNES_BNF_FINALES = (
    "ppn",
    "isbn_normalise",
    "titre",
    "annee",
    "nomAuteur",
    "lieuPublication",
    "editeur",
    "sujet",
    "raisons",)

RAISONS_BNF = (
    "titre",
    "lieu_publication",
    "sujet",
    "naissance_auteur",
    "deces_auteur",)

LISTE_COMMUNE = charger_liste(FICHIER_COMMUNES)
LISTE_TITRE = charger_liste(FICHIER_TITRES)

thread_local = threading.local()

def creer_session():
    return creer_session_http(
        retries=MAX_RETRIES,
        backoff=1,
        methods=["POST"],
        pool_size=10,
        headers=HEADERS,
        monter_http=False,
        respect_retry_after=False,
    )

def get_session():
    return obtenir_session_thread(thread_local,creer_session)

PREFIXES = """
PREFIX bnf-onto: <http://data.bnf.fr/ontology/bnf-onto/>
PREFIX dcterms: <http://purl.org/dc/terms/>
PREFIX foaf: <http://xmlns.com/foaf/0.1/>
PREFIX lc: <http://id.loc.gov/vocabulary/relators/>
PREFIX rdagroup2elements: <http://rdvocab.info/ElementsGr2/>
PREFIX rdarelationships: <http://rdvocab.info/RDARelationshipsWEMI/>
PREFIX rdvocab: <http://rdvocab.info/Elements/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
PREFIX owl: <http://www.w3.org/2002/07/owl#>
"""

def construire_variantes_bnf(valeurs):
    variantes = set()

    for valeur in valeurs:
        if valeur and (valeur := str(valeur).strip()):
            variantes.update((
                valeur.lower(),
                normaliser_texte(valeur),
            ))

    return sorted(variantes, key=len, reverse=True)

VARIANTES_COMMUNES = construire_variantes_bnf(LISTE_COMMUNE)
VARIANTES_TITRES = construire_variantes_bnf(LISTE_TITRE)

def construire_bif_contains(variantes):
    return " OR ".join(
        f"'{terme}'"
        for variante in variantes
        if (terme := variante.replace("'", " ").strip()))

BIF_COMMUNES = construire_bif_contains(VARIANTES_COMMUNES)
BIF_TITRES = construire_bif_contains(VARIANTES_TITRES)

print(f"{len(LISTE_COMMUNE)} termes lieu/communes")
print(f"{len(LISTE_TITRE)} termes titre/sujet")

def contient_terme(texte, variantes):
    texte = normaliser_texte(texte)

    if not texte:
        return False

    return any(
        (
            re.search(
                rf"(?<![a-z]){re.escape(terme)}(?![a-z])",
                texte
            )
            if len(terme) <= 2
            else terme in texte
        )
        for terme in variantes)

def contient_commune(texte):
    return contient_terme(texte, VARIANTES_COMMUNES)

def contient_terme_titre(texte):
    return contient_terme(texte, VARIANTES_TITRES)

BLOC_ISBN = """
?genevensia ?isbnProperty ?isbn .

VALUES ?isbnProperty {
    bnf-onto:isbn
    bnf-onto:ISBN
}
"""

def requete_sparql(query):
    response = get_session().post(
        ENDPOINT_URL,
        data={
            "query": query,
            "format": "application/sparql-results+json",
        },
        timeout=TIMEOUT,
    )

    response.raise_for_status()

    try:
        return response.json()
    except Exception:
        print(response.text[:1000])
        raise

def valeur_binding(binding, cle):
    return binding.get(cle, {}).get("value")

def bindings_vers_lignes(resultat, raison=None):
    lignes = []

    for binding in resultat.get("results", {}).get("bindings", []):
        ligne = {
            cle: valeur.get("value")
            for cle, valeur in binding.items()
        }

        if raison:
            ligne["raison"] = raison

        lignes.append(ligne)

    return lignes

def dedoublonner_lignes(lignes, cles):
    resultat = []
    vus = set()

    for ligne in lignes:
        cle = tuple(ligne.get(x) for x in cles)

        if cle not in vus:
            vus.add(cle)
            resultat.append(ligne)

    return resultat

def chercher_titre():

    debut = time.time()

    query = PREFIXES + f"""
SELECT DISTINCT
    ?genevensia
    ?isbn
    ?titreRecherche

WHERE {{

    {BLOC_ISBN}

    ?genevensia
        dcterms:title
        ?titreRecherche .

    ?titreRecherche
        bif:contains
        "{BIF_TITRES}" .
}}
"""

    lignes = [
        {
            "genevensia": valeur_binding(x, "genevensia"),
            "isbn": valeur_binding(x, "isbn"),
            "raison": "titre",
        }
        for x in requete_sparql(query)
        .get("results", {})
        .get("bindings", [])
        if contient_terme_titre(
            valeur_binding(x, "titreRecherche")
        )
    ]

    print(
        f"✓ titre : {len(lignes):,} lignes "
        f"({time.time() - debut:.1f}s)"
    )

    return lignes

def chercher_lieu_publication():

    debut = time.time()

    variantes = [
        terme
        for terme in VARIANTES_COMMUNES
        if terme != "gy"
    ]

    recherche = construire_bif_contains(
        variantes
    )

    query_principale = PREFIXES + f"""

SELECT DISTINCT
    ?genevensia
    ?isbn
    ?lieuPublication

WHERE {{

    ?genevensia
        rdvocab:placeOfPublication
        ?lieuPublication ;
        bnf-onto:isbn
        ?isbn .

    ?lieuPublication
        bif:contains
        "{recherche}" .
}}
"""

    lignes = []

    gy_present = "gy" in VARIANTES_COMMUNES

    if gy_present:

        query_gy = PREFIXES + """

SELECT DISTINCT
    ?genevensia
    ?isbn
    ?lieuPublication

WHERE {

    ?genevensia
        rdvocab:placeOfPublication
        ?lieuPublication ;
        bnf-onto:isbn
        ?isbn .

    FILTER(
        REGEX(
            STR(?lieuPublication),
            "(^|[^A-Za-zÀ-ÿ])Gy([^A-Za-zÀ-ÿ]|$)",
            "i"
        )
    )
}
"""

        with ThreadPoolExecutor(
            max_workers=2
        ) as executor:

            future_principale = executor.submit(
                requete_sparql,
                query_principale
            )

            future_gy = executor.submit(
                requete_sparql,
                query_gy
            )

            resultats = [
                future_principale.result(),
                future_gy.result()
            ]

    else:

        resultats = [
            requete_sparql(
                query_principale
            )
        ]

    lignes = [
        {
            "genevensia": valeur_binding(x, "genevensia"),
            "isbn": valeur_binding(x, "isbn"),
            "lieuPublication": valeur_binding(x, "lieuPublication"),
            "raison": "lieu_publication",
        }
        for resultat in resultats
        for x in resultat.get("results", {}).get("bindings", [])
        if contient_commune(
            valeur_binding(x, "lieuPublication")
        )
    ]

    lignes = dedoublonner_lignes(
        lignes,
        ("genevensia", "isbn", "lieuPublication")
    )

    print(
        f"✓ lieu publication : {len(lignes):,} lignes "
        f"({time.time() - debut:.1f}s)"
    )

    return lignes

def chercher_sujet():

    debut = time.time()

    query = PREFIXES + f"""

SELECT DISTINCT
    ?genevensia
    ?isbn
    ?sujet
    ?labelSujet

WHERE {{

    ?genevensia
        dcterms:subject
        ?sujet ;
        bnf-onto:isbn
        ?isbn .

    ?sujet
        skos:prefLabel
        ?labelSujet .

    ?labelSujet
        bif:contains
        "{BIF_TITRES}" .
}}
"""

    resultat = requete_sparql(query)

    lignes = [
        {
            "genevensia": valeur_binding(x, "genevensia"),
            "isbn": valeur_binding(x, "isbn"),
            "sujet": valeur_binding(x, "sujet"),
            "labelSujet": valeur_binding(x, "labelSujet"),
            "raison": "sujet",
        }
        for x in resultat.get("results", {}).get("bindings", [])
        if contient_terme_titre(
            valeur_binding(x, "labelSujet")
        )
    ]

    lignes = dedoublonner_lignes(
        lignes,
        ("genevensia", "isbn", "sujet")
    )

    print(
        f"✓ sujet : {len(lignes):,} lignes "
        f"({time.time() - debut:.1f}s)"
    )

    return lignes

def chercher_lieu_auteur(propriete, raison, libelle):
    debut = time.time()

    query = PREFIXES + f"""
SELECT DISTINCT
    ?genevensia
    ?isbn

WHERE {{

    {BLOC_ISBN}

    ?genevensia
        rdarelationships:expressionManifested
        ?expression .

    ?expression
        lc:aut
        ?auteur .

    ?auteur
        rdagroup2elements:{propriete}
        ?lieu .

    ?lieu
        bif:contains
        "{BIF_COMMUNES}" .
}}
"""

    try:
        resultat = requete_sparql(query)

    except Exception:
        regex = "(" + "|".join(VARIANTES_COMMUNES) + ")"

        query = PREFIXES + f"""
SELECT DISTINCT
    ?genevensia
    ?isbn

WHERE {{

    {BLOC_ISBN}

    ?genevensia
        rdarelationships:expressionManifested
        ?expression .

    ?expression
        lc:aut
        ?auteur .

    ?auteur
        rdagroup2elements:{propriete}
        ?lieu .

    FILTER(
        REGEX(
            LCASE(STR(?lieu)),
            "{regex}"
        )
    )
}}
"""

        resultat = requete_sparql(query)

    lignes = bindings_vers_lignes(resultat, raison)

    print(
        f"✓ {libelle} : {len(lignes):,} lignes "
        f"({time.time() - debut:.1f}s)"
    )

    return lignes

def chercher_naissance():
    return chercher_lieu_auteur(
        "placeOfBirth",
        "naissance_auteur",
        "naissance"
    )

def chercher_deces():
    return chercher_lieu_auteur(
        "placeOfDeath",
        "deces_auteur",
        "décès"
    )

# DETECTION PARALLELE

def detection_parallele():
    fonctions = {
        "titre": chercher_titre,
        "lieu_publication": chercher_lieu_publication,
        "sujet": chercher_sujet,
        "naissance": chercher_naissance,
        "deces": chercher_deces,
    }

    debut = time.time()
    toutes_lignes = []

    afficher_section("LANCEMENT DES RECHERCHES BnF")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(fonction): nom
            for nom, fonction in fonctions.items()
        }

        for future in as_completed(futures):
            nom = futures[future]

            try:
                toutes_lignes.extend(future.result())

            except Exception as erreur:
                print(
                    f"✗ ERREUR {nom} : "
                    f"{type(erreur).__name__} : {erreur}"
                )

    print(
        f"\nDétection terminée en "
        f"{time.time() - debut:.1f}s"
    )

    return toutes_lignes

# FUSION DETECTION

def fusionner_detection(lignes):
    colonnes = [
        "genevensia",
        "isbn_normalise",
        "raisons",
    ]

    if not lignes:
        return pd.DataFrame(columns=colonnes)

    df = pd.DataFrame(lignes)

    df["isbn_normalise"] = df["isbn"].map(
        normaliser_isbn
    )

    df = (
        df[df["isbn_normalise"].notna()]
        .drop_duplicates(
            subset=[
                "genevensia",
                "isbn_normalise",
                "raison",
            ]
        )
    )

    return (
        df.groupby(
            ["genevensia", "isbn_normalise"],
            as_index=False
        )
        .agg(
            raisons=(
                "raison",
                lambda x: " | ".join(
                    sorted(set(x))
                )
            )
        )
    )

# FILTRE UNIMARC 182$c — VERSION OPTIMISÉE PAR LOTS

sru_thread_local = threading.local()

def _normaliser_ark_bnf(ark):
    if ark is None or pd.isna(ark):
        return None

    ark = str(ark).strip()

    if "ark:/12148/" in ark:
        ark = ark.split("ark:/12148/", 1)[1]

    return ark.split("#", 1)[0].strip() or None

def _creer_session_sru():
    """
    Session HTTP dédiée au SRU.

    Les retries sont gérés manuellement afin de contrôler précisément
    les 429, timeouts et subdivisions 400/414.
    """

    session = requests.Session()

    adapter = HTTPAdapter(
        max_retries=0,
        pool_connections=SRU_WORKERS + 2,
        pool_maxsize=SRU_WORKERS + 2,
    )

    session.mount("https://", adapter)
    session.mount("http://", adapter)

    session.headers.update({
        "User-Agent":
            "Geneve-Bibliographic-Research-BNF-SRU/5.0",
        "Accept":
            "application/xml, text/xml;q=0.9, */*;q=0.1",
        "Accept-Encoding":
            "gzip, deflate",
    })

    return session

def _obtenir_session_sru():
    return obtenir_session_thread(sru_thread_local,_creer_session_sru)

def _construire_query_sru_arks(arks):
    """Construit une requête CQL compacte pour plusieurs ARK BnF.

    Forme benchmarkée la plus rapide :
        bib.persistentid any "ark:/12148/cb... ark:/12148/cb..."
    """

    valeurs = " ".join(
        f"ark:/12148/{ark}"
        for ark in arks
    )
    return f'bib.persistentid any "{valeurs}"'

def _construire_params_sru(arks):
    """Paramètres SRU d'un lot d'ARK."""

    return {
        **PARAMS_SRU_BNF,
        "query": _construire_query_sru_arks(arks),
        "maximumRecords": len(arks),}

def _construire_lots_sru(arks):
    """Découpe directement les ARK en lots fixes.

    Le calcul dynamique de longueur d'URL a été supprimé après benchmark :
    avec 50 ARK et ``bib.persistentid any``, il ajoutait un coût Python
    important sans bénéfice fonctionnel.
    """
    return list(creer_lots(arks, SRU_MAX_ARKS_PAR_LOT))

def _noms_enfants(element):
    return {
        nom_local_xml(enfant)
        for enfant in element
    }

def _enfant_xml(element, nom):
    return next(
        (
            enfant
            for enfant in element
            if nom_local_xml(enfant) == nom),None)

def _contient_element_xml(element, noms):
    return any(
        nom_local_xml(x) in noms
        for x in element.iter())

def _media_informatique_182c(record):
    return any(
        (sous.text or "").strip().lower() == "c"
        for champ in record
        if (
            nom_local_xml(champ) == "datafield"
            and champ.attrib.get("tag") == "182"
        )
        for sous in champ
        if (
            nom_local_xml(sous) == "subfield"
            and sous.attrib.get("code") == "c"))

def _parser_notices_sru_182c(xml_content):
    """
    Parse une réponse SRU unimarcXchange.

    Retourne :
        nb_sru
        statut_par_ark
        non_controllables

    True  -> 182$c = c -> média informatique -> exclusion
    False -> absence de 182$c = c ou notice non contrôlable -> conservation
    """

    root = ET.fromstring(xml_content)

    nb_sru = None
    statut_par_ark = {}
    non_controllables = set()

    for element in root.iter():
        if nom_local_xml(element) == "numberOfRecords":
            try:
                nb_sru = int(element.text)
            except (TypeError, ValueError):
                pass

            break

    for record in root.iter():
        if nom_local_xml(record) != "record":
            continue

        noms = _noms_enfants(record)

        if not {
            "recordData",
            "recordIdentifier",
        }.issubset(noms):
            continue

        record_identifier = _enfant_xml(
            record,
            "recordIdentifier"
        )
        record_data = _enfant_xml(
            record,
            "recordData"
        )

        ark = _normaliser_ark_bnf(
            record_identifier.text
            if record_identifier is not None
            else None
        )

        if not ark or record_data is None:
            continue

        if _contient_element_xml(
            record_data,
            {"leader", "controlfield", "datafield"}
        ):
            continue

        if _contient_element_xml(
            record_data,
            {"diagnostic"}
        ):
            statut_par_ark[ark] = False
            non_controllables.add(ark)

    for record in root.iter():
        if nom_local_xml(record) != "record":
            continue

        if not (
            _noms_enfants(record)
            & {"leader", "controlfield", "datafield"}
        ):
            continue

        ark = _normaliser_ark_bnf(
            record.attrib.get("id")
        )

        if ark:
            statut_par_ark[ark] = (
                _media_informatique_182c(record)
            )

    return (
        nb_sru,
        statut_par_ark,
        non_controllables,
    )

def _attente_retry_sru(response, tentative):
    """Respecte Retry-After, sinon applique le backoff exponentiel."""

    if response is not None:
        try:
            return max(
                0.0,
                float(response.headers.get("Retry-After"))
            )
        except (TypeError, ValueError):
            pass

    return (
        2 ** (tentative - 1)
        + random.uniform(0.15, 0.65))

def _fusionner_resultats_sru(gauche, droite):
    statut, erreurs, non_ctrl = gauche
    statut_d, erreurs_d, non_ctrl_d = droite

    statut.update(statut_d)

    return (
        statut,
        erreurs + erreurs_d,
        non_ctrl | non_ctrl_d,)

def _subdiviser_lot_sru(arks, tentatives):
    milieu = len(arks) // 2

    return _fusionner_resultats_sru(
        _executer_lot_sru(
            arks[:milieu],
            tentatives=tentatives
        ),
        _executer_lot_sru(
            arks[milieu:],
            tentatives=tentatives))

def _executer_lot_sru(arks, tentatives=SRU_RETRIES):
    """
    Exécute un lot SRU.

    - 400/414 -> subdivision récursive
    - 429/5xx -> retry/backoff
    - timeout/connexion -> retry/backoff
    - diagnostic sans MARC -> conservation
    - incohérence SRU -> subdivision ou erreur unitaire
    """

    if not arks:
        return {}, [], set()

    session = _obtenir_session_sru()
    params = _construire_params_sru(arks)
    derniere_erreur = None

    for tentative in range(1, tentatives + 1):
        response = None

        try:
            response = session.get(
                SRU_BNF_URL,
                params=params,
                timeout=(
                    SRU_CONNECT_TIMEOUT,
                    SRU_READ_TIMEOUT,
                ),
            )

            if response.status_code in (400, 414):
                if len(arks) > 1:
                    return _subdiviser_lot_sru(
                        arks,
                        tentatives
                    )

                return {}, [{
                    "arks": list(arks),
                    "erreur": f"HTTP_{response.status_code}",
                    "message": "Lot SRU indivisible refusé",
                }], set()

            if (
                response.status_code == 429
                or 500 <= response.status_code <= 599
            ):
                derniere_erreur = requests.exceptions.HTTPError(
                    f"HTTP {response.status_code}"
                )

                if tentative >= tentatives:
                    break

                time.sleep(
                    _attente_retry_sru(
                        response,
                        tentative
                    )
                )
                continue

            response.raise_for_status()

            nb_sru, statut, non_controllables = (
                _parser_notices_sru_182c(
                    response.content
                )
            )

            if (
                nb_sru is not None
                and nb_sru != len(statut)
            ):
                if len(arks) > 1:
                    return _subdiviser_lot_sru(
                        arks,
                        tentatives
                    )

                return statut, [{
                    "arks": list(arks),
                    "erreur": "SRU_INCOHERENT",
                    "message": (
                        f"numberOfRecords={nb_sru}, "
                        f"notices_parsees={len(statut)}"
                    ),
                }], non_controllables

            return statut, [], non_controllables

        except (
            requests.exceptions.Timeout,
            requests.exceptions.ConnectionError,
        ) as erreur:

            derniere_erreur = erreur

            if tentative >= tentatives:
                break

            time.sleep(
                _attente_retry_sru(
                    response,
                    tentative
                )
            )

        except (
            requests.exceptions.RequestException,
            ET.ParseError,
        ) as erreur:

            derniere_erreur = erreur
            break

    return {}, [{
        "arks": list(arks),
        "erreur": (
            type(derniere_erreur).__name__
            if derniere_erreur
            else "ErreurSRU"
        ),
        "message": (
            str(derniere_erreur)[:200]
            if derniere_erreur
            else "Erreur SRU inconnue"
        ),
    }], set()

SRU_RECOVERY1_WORKERS = 6
SRU_RECOVERY1_LOT_SIZE = 25
SRU_RECOVERY1_PAUSE = 2.0

SRU_RECOVERY2_WORKERS = 2
SRU_RECOVERY2_LOT_SIZE = 10
SRU_RECOVERY2_RETRIES = 6
SRU_RECOVERY2_PAUSE = 5.0

DERNIER_DIAGNOSTIC_SRU = {}

def _unique_ordonnee(valeurs):
    return list(dict.fromkeys(valeurs))

def _extraire_arks_erreurs_sru(erreurs):
    """Retourne les ARK uniques réellement contenus dans les erreurs."""

    arks = [
        ark
        for erreur in erreurs
        if isinstance(erreur, dict)
        for valeur in erreur.get("arks", [])
        if (ark := _normaliser_ark_bnf(valeur))
    ]

    return _unique_ordonnee(arks)

def _decouper_lots(arks, taille):
    return list(creer_lots(arks, taille))

def _executer_passe_sru(
    lots,
    workers,
    tentatives,
    titre,
    progression=20,
):
    if not lots:
        return {}, [], set()

    print(
        f"\n{'=' * 80}\n"
        f"{titre}\n"
        f"{'=' * 80}\n"
        f"Lots                 : {len(lots):,}\n"
        f"Workers              : {workers}\n"
        f"Tentatives / lot     : {tentatives}\n"
        f"{'=' * 80}"
    )

    debut = time.perf_counter()
    statut_par_ark = {}
    erreurs = []
    non_controllables = set()

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {
            executor.submit(
                _executer_lot_sru,
                lot,
                tentatives
            ): lot
            for lot in lots
        }

        for termines, future in enumerate(
            as_completed(futures),
            1
        ):
            lot = futures[future]

            try:
                statut, erreurs_lot, non_ctrl = future.result()

                statut_par_ark.update(statut)
                erreurs.extend(erreurs_lot)
                non_controllables.update(non_ctrl)

            except Exception as exc:
                erreurs.append({
                    "arks": list(lot),
                    "erreur": type(exc).__name__,
                    "message": str(exc)[:200],
                })

            if (
                termines % progression == 0
                or termines == len(lots)
            ):
                nb_medias = sum(
                    map(bool, statut_par_ark.values())
                )

                print(
                    f"{termines:>4}/{len(lots)} lots "
                    f"| ARK contrôlés : {len(statut_par_ark):,} "
                    f"| médias info. : {nb_medias:,} "
                    f"| non contrôlables : {len(non_controllables):,} "
                    f"| erreurs : {len(erreurs):,} "
                    f"| {time.perf_counter() - debut:.1f} s"
                )

    return statut_par_ark, erreurs, non_controllables

def _recuperer_erreurs_sru(
    erreurs,
    statut_par_ark,
    *,
    numero,
    pause,
    taille_lot,
    workers,
    tentatives,
    titre,
    progression,
    texte_erreur,
):
    """Relance uniquement les ARK encore réellement en erreur."""

    arks = [
        ark
        for ark in _extraire_arks_erreurs_sru(erreurs)
        if ark not in statut_par_ark
    ]

    if not arks:
        return [], {}, [], set()

    print(
        f"\nRécupération {numero} : "
        f"{len(arks):,} ARK {texte_erreur}. "
        f"Pause {pause:.1f} s..."
    )

    time.sleep(pause)

    statut, nouvelles_erreurs, non_ctrl = (
        _executer_passe_sru(
            lots=_decouper_lots(
                arks,
                taille_lot
            ),
            workers=workers,
            tentatives=tentatives,
            titre=titre,
            progression=progression,
        )
    )

    return (
        arks,
        statut,
        nouvelles_erreurs,
        non_ctrl,
    )

def _arks_non_resolus(arks, statut_par_ark):
    return [
        ark
        for ark in arks
        if ark not in statut_par_ark
    ]

def filtrer_medias_informatiques_bnf(
    df_isbn,
    max_workers=SRU_WORKERS,
):
    """
    Exclut les notices dont le champ UNIMARC contient ``182$c = c``.

    Stratégie finale :

    1. Passe principale ultra-rapide
       - 20 workers
       - 50 ARK / lot
       - GET
       - CQL ``bib.persistentid any``
       - slicing direct

    2. Récupération des VRAIES erreurs uniquement
       - 6 workers
       - 25 ARK / lot

    3. Dernière récupération des erreurs résiduelles uniquement
       - 2 workers
       - 10 ARK / lot
       - 6 tentatives

    Cas spécial :
    si la BnF renvoie un ``recordIdentifier`` mais seulement un diagnostic
    SRU dans ``recordData`` (aucun MARC / aucune zone 182), l'ARK est classé
    ``non_controllable_182`` : l'ISBN est conservé et aucune récupération
    supplémentaire n'est lancée pour lui.
    """

    global DERNIER_DIAGNOSTIC_SRU

    if df_isbn.empty or "ark_bnf" not in df_isbn.columns:
        return df_isbn, 0

    arks_uniques = (
        df_isbn["ark_bnf"]
        .dropna()
        .map(_normaliser_ark_bnf)
        .dropna()
        .drop_duplicates()
        .tolist()
    )

    if not arks_uniques:
        return df_isbn, 0

    lots_principaux = _construire_lots_sru(
        arks_uniques
    )

    print()
    print("=" * 80)
    print("CONTRÔLE UNIMARC 182$c — SRU BNF FINAL")
    print("=" * 80)
    print(f"ARK uniques             : {len(arks_uniques):,}")
    print(f"Lots SRU                : {len(lots_principaux):,}")
    print(f"ARK / lot max           : {SRU_MAX_ARKS_PAR_LOT}")
    print("Construction lots       : slicing direct")
    print("CQL                     : bib.persistentid any")
    print("HTTP                    : GET")
    print(f"Workers SRU             : {max_workers}")
    print("=" * 80)

    debut = time.perf_counter()

    statut_par_ark, erreurs_1, non_ctrl_1 = _executer_passe_sru(
        lots=lots_principaux,
        workers=max_workers,
        tentatives=SRU_RETRIES,
        titre="PASSAGE SRU PRINCIPAL",
        progression=10,
    )

    non_controllables = set(non_ctrl_1)

    (
        arks_recup_1,
        statut_2,
        erreurs_2,
        non_ctrl_2,
    ) = _recuperer_erreurs_sru(
        erreurs_1,
        statut_par_ark,
        numero=1,
        pause=SRU_RECOVERY1_PAUSE,
        taille_lot=SRU_RECOVERY1_LOT_SIZE,
        workers=SRU_RECOVERY1_WORKERS,
        tentatives=SRU_RETRIES,
        titre="RÉCUPÉRATION SRU 1 — 6 WORKERS / 25 ARK",
        progression=20,
        texte_erreur="en vraie erreur",
    )

    statut_par_ark.update(statut_2)
    non_controllables.update(non_ctrl_2)

    (
        arks_recup_2,
        statut_3,
        erreurs_3,
        non_ctrl_3,
    ) = _recuperer_erreurs_sru(
        erreurs_2,
        statut_par_ark,
        numero=2,
        pause=SRU_RECOVERY2_PAUSE,
        taille_lot=SRU_RECOVERY2_LOT_SIZE,
        workers=SRU_RECOVERY2_WORKERS,
        tentatives=SRU_RECOVERY2_RETRIES,
        titre="RÉCUPÉRATION SRU 2 — 2 WORKERS / 10 ARK",
        progression=10,
        texte_erreur="encore en vraie erreur",
    )

    statut_par_ark.update(statut_3)
    non_controllables.update(non_ctrl_3)

    # ERREURS FINALES

    arks_erreurs_finales = _unique_ordonnee(
        _arks_non_resolus(
            _extraire_arks_erreurs_sru(erreurs_3),
            statut_par_ark
        )
    )

    arks_non_resolus = _arks_non_resolus(
        arks_uniques,
        statut_par_ark
    )

    erreurs_finales_set = set(
        arks_erreurs_finales
    )

    arks_absents_sru = [
        ark
        for ark in arks_non_resolus
        if ark not in erreurs_finales_set
    ]

    # FILTRE 182$c

    masque_media = (
        df_isbn["ark_bnf"]
        .map(_normaliser_ark_bnf)
        .map(statut_par_ark)
        .eq(True)
    )

    nb_lignes_exclues = int(
        masque_media.sum()
    )

    nb_arks_exclus = sum(
        map(bool, statut_par_ark.values())
    )

    resultat = (
        df_isbn.loc[~masque_media]
        .copy()
        .reset_index(drop=True)
    )

    duree = time.perf_counter() - debut

    diagnostic = {
        "arks_total": len(arks_uniques),
        "arks_controles_final": len(statut_par_ark),
        "arks_media": nb_arks_exclus,
        "lignes_media_exclues": nb_lignes_exclues,
        "arks_non_controllables_182": len(non_controllables),
        "liste_arks_non_controllables_182": sorted(non_controllables),
        "erreurs_passage_principal": len(erreurs_1),
        "arks_relances_recuperation_1": len(arks_recup_1),
        "erreurs_recuperation_1": len(erreurs_2),
        "arks_relances_recuperation_2": len(arks_recup_2),
        "erreurs_recuperation_2": len(erreurs_3),
        "arks_erreurs_finales": len(arks_erreurs_finales),
        "liste_arks_erreurs_finales": arks_erreurs_finales,
        "arks_absents_sru": len(arks_absents_sru),
        "liste_arks_absents_sru": arks_absents_sru,
        "duree": duree,
    }

    DERNIER_DIAGNOSTIC_SRU = diagnostic

    resultat.attrs.update({
        "erreurs_sru_182c_initiales": erreurs_1,
        "erreurs_sru_182c_recuperation_1": erreurs_2,
        "erreurs_sru_182c_finales": erreurs_3,
        "nb_arks_sru_controles": len(statut_par_ark),
        "nb_arks_sru_inconnus": len(arks_non_resolus),
        "nb_arks_media_informatique": nb_arks_exclus,
        "nb_arks_non_controllables_182": len(non_controllables),
    })

    print(
        f"\n{'=' * 80}\n"
        "BILAN FINAL SRU\n"
        f"{'=' * 80}\n"
        f"ARK total                         : {len(arks_uniques):,}\n"
        f"ARK contrôlés / classés           : {len(statut_par_ark):,}\n"
        f"ARK avec 182$c = c                : {nb_arks_exclus:,}\n"
        f"Lignes ISBN exclues               : {nb_lignes_exclues:,}\n"
        f"Diagnostics sans MARC conservés   : {len(non_controllables):,}\n"
        f"ARK absents du SRU                : {len(arks_absents_sru):,}\n"
        f"VRAIES ERREURS SRU FINALES        : {len(arks_erreurs_finales):,}\n"
        f"Durée contrôle 182$c              : "
        f"{duree:.1f} s ({duree / 60:.2f} min)\n"
        f"Lignes restantes                  : {len(resultat):,}\n"
        f"{'=' * 80}"
    )

    return resultat, nb_lignes_exclues

# ENRICHISSEMENT D'UN LOT

def enrichir_lot(uris):
    values = " ".join(
        f"<{uri}>"
        for uri in uris
    )

    query = PREFIXES + f"""

SELECT DISTINCT
    ?genevensia
    ?titre
    ?annee
    ?lieuPublication
    ?editeur
    ?auteur
    ?nomAuteur
    ?sujet
    ?ppn
    ?uri

WHERE {{

    VALUES ?genevensia {{
        {values}
    }}

    OPTIONAL {{
        ?genevensia
            dcterms:title
            ?titre .
    }}

    OPTIONAL {{
        ?genevensia
            dcterms:date
            ?annee .
    }}

    OPTIONAL {{
        ?genevensia
            rdvocab:placeOfPublication
            ?lieuBrut .

        OPTIONAL {{
            ?lieuBrut
                rdfs:label
                ?lieuLabel1 .
        }}

        OPTIONAL {{
            ?lieuBrut
                skos:prefLabel
                ?lieuLabel2 .
        }}

        BIND(
            COALESCE(
                ?lieuLabel1,
                ?lieuLabel2,
                STR(?lieuBrut)
            )
            AS ?lieuPublication
        )
    }}

    OPTIONAL {{
        ?genevensia
            rdvocab:publishersName
            ?editeur .
    }}

    OPTIONAL {{
        ?genevensia
            rdfs:seeAlso
            ?uri .
    }}

    OPTIONAL {{
        ?genevensia
            dcterms:subject
            ?sujetURI .

        OPTIONAL {{
            ?sujetURI
                skos:prefLabel
                ?sujetLabel1 .
        }}

        OPTIONAL {{
            ?sujetURI
                rdfs:label
                ?sujetLabel2 .
        }}

        BIND(
            COALESCE(
                ?sujetLabel1,
                ?sujetLabel2,
                STR(?sujetURI)
            )
            AS ?sujet
        )
    }}

    OPTIONAL {{
        ?genevensia
            rdarelationships:expressionManifested
            ?expressionAuteur .

        ?expressionAuteur
            lc:aut
            ?auteur .

        OPTIONAL {{
            ?auteur
                foaf:name
                ?nomAuteur .
        }}

        OPTIONAL {{
            ?auteur
                owl:sameAs|rdfs:seeAlso
                ?idrefURI .

            FILTER(
                CONTAINS(
                    LCASE(
                        STR(?idrefURI)
                    ),
                    "idref.fr/"
                )
            )

            BIND(
                REPLACE(
                    STRAFTER(
                        STR(?idrefURI),
                        "idref.fr/"
                    ),
                    "/.*$",
                    ""
                )
                AS ?ppn
            )
        }}
    }}
}}
"""

    return bindings_vers_lignes(
        requete_sparql(query)
    )

# ENRICHISSEMENT PARALLELE

def enrichir_notices(df_detection):
    uris = (
        df_detection["genevensia"]
        .dropna()
        .drop_duplicates()
        .tolist()
    )

    if not uris:
        return pd.DataFrame()

    lots = list(
        creer_lots(
            uris,
            TAILLE_LOT_ENRICHISSEMENT
        )
    )

    print(
        f"\nEnrichissement de {len(uris):,} notices "
        f"en {len(lots):,} lots..."
    )

    debut = time.time()
    toutes_lignes = []

    workers = min(
        MAX_WORKERS_ENRICHISSEMENT,
        len(lots)
    )

    with ThreadPoolExecutor(
        max_workers=workers
    ) as executor:

        futures = {
            executor.submit(
                enrichir_lot,
                lot
            ): numero
            for numero, lot in enumerate(
                lots,
                1
            )
        }

        for termines, future in enumerate(
            as_completed(futures),
            1
        ):
            numero = futures[future]

            try:
                toutes_lignes.extend(
                    future.result()
                )

            except Exception as erreur:
                print(
                    f"\n✗ Erreur lot {numero} : "
                    f"{erreur}"
                )

            print(
                f"\rLots terminés : "
                f"{termines}/{len(lots)}",
                end=""
            )

    print(
        f"\nEnrichissement terminé en "
        f"{time.time() - debut:.1f}s"
    )

    return (
        pd.DataFrame(toutes_lignes)
        if toutes_lignes
        else pd.DataFrame()
    )

# AGREGER L'ENRICHISSEMENT

def agreger_enrichissement(df):
    if df.empty:
        return df

    df = df.copy()

    for colonne in (*COLONNES_ENRICHISSEMENT, "ppn"):
        if colonne not in df.columns:
            df[colonne] = None

    df["ppn"] = (
        df["ppn"]
        .astype("string")
        .str.strip()
        .replace({
            "": pd.NA,
            "None": pd.NA,
            "nan": pd.NA,
            "<NA>": pd.NA,
        })
    )

    return (
        df.groupby(
            ["genevensia", "ppn"],
            as_index=False,
            dropna=False,
        )
        .agg({
            colonne: concat_unique
            for colonne in COLONNES_ENRICHISSEMENT
        })
    )

def _afficher_repartition_raisons(df):
    if df.empty:
        return

    print("\nRépartition des critères :")

    for raison in RAISONS_BNF:
        nombre = (
            df["raisons"]
            .str.contains(
                raison,
                regex=False,
                na=False
            )
            .sum()
        )

        print(f"  {raison:<20} : {nombre:,}")

def recherche_BNF():
    """Lance la recherche Genevensia BnF complète."""

    debut = time.time()

    # 1. DETECTION

    df_detection = fusionner_detection(
        detection_parallele()
    )

    # 2. FILTRE MEDIAS INFORMATIQUES

    df_detection["ark_bnf"] = (
        df_detection["genevensia"]
        .map(_normaliser_ark_bnf)
    )

    df_detection, nb_numeriques_exclus = (
        filtrer_medias_informatiques_bnf(
            df_detection
        )
    )

    df_detection.drop(
        columns="ark_bnf",
        errors="ignore",
        inplace=True
    )

    print(
        f"\n{'=' * 42}\n"
        "APRES DETECTION\n"
        f"{'=' * 42}\n"
        f"Notices uniques : "
        f"{df_detection['genevensia'].nunique():,}\n"
        f"ISBN uniques : "
        f"{df_detection['isbn_normalise'].nunique():,}\n"
        f"Notices numériques exclues : "
        f"{nb_numeriques_exclus:,}"
    )

    _afficher_repartition_raisons(
        df_detection
    )

    # 3. ENRICHISSEMENT

    df_enrichissement = agreger_enrichissement(
        enrichir_notices(
            df_detection
        )
    )

    # 4. MERGE

    df_bnf = (
        df_detection.merge(
            df_enrichissement,
            on="genevensia",
            how="left"
        )
        if not df_enrichissement.empty
        else df_detection.copy()
    )

    # 5. COLONNES + DEDUPLICATION

    colonnes = [
        colonne
        for colonne in COLONNES_BNF_FINALES
        if colonne in df_bnf.columns
    ]

    df_bnf = (
        df_bnf[colonnes]
        .drop_duplicates()
        .reset_index(drop=True)
    )

    # 6. TRI

    colonnes_tri = [
        colonne
        for colonne in (
            "ppn",
            "isbn_normalise",
            "titre",
        )
        if colonne in df_bnf.columns
    ]

    if colonnes_tri:
        df_bnf = (
            df_bnf
            .sort_values(
                colonnes_tri,
                na_position="last"
            )
            .reset_index(drop=True)
        )

    # 7. RESULTATS

    liste_isbn_bnf = (
        df_bnf["isbn_normalise"]
        .dropna()
        .drop_duplicates()
        .tolist()
    )

    duree = time.time() - debut

    print(
        f"\n{'=' * 42}\n"
        "TERMINE\n"
        f"{'=' * 42}\n"
        f"Lignes finales : {len(df_bnf):,}"
    )

    if "ppn" in df_bnf.columns:
        print(
            f"PPN uniques : "
            f"{df_bnf['ppn'].nunique():,}"
        )

    print(
        f"ISBN uniques : {len(liste_isbn_bnf):,}\n"
        f"Durée totale : {duree:.1f} secondes\n"
        f"Soit : {duree / 60:.1f} minutes"
    )

    display(df_bnf)

    return df_bnf