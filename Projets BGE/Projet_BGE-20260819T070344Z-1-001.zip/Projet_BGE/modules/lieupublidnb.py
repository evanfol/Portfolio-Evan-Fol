import pandas as pd
import re
import time
import threading
import unicodedata
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from config import FICHIER_COMMUNES, FICHIER_TITRES
from utils import charger_liste, creer_lots, concat_unique, valeur, normaliser_isbn, afficher_section, SEPARATEUR, creer_session_http, obtenir_session_thread, echapper_requete


SPARQL_URL = 'https://sparql.dnb.de/api/dnbgnd'
WIKIDATA_SPARQL_URL = 'https://query.wikidata.org/sparql'
DNB_SRU_URL = 'https://services.dnb.de/sru/dnb'
SRU_NS = {'srw': 'http://www.loc.gov/zing/srw/', 'marc': 'http://www.loc.gov/MARC21/slim'}
MARC_NS = 'http://www.loc.gov/MARC21/slim'
thread_local_wikidata = threading.local()
DNB_ID_RE = re.compile('d-nb\\.info/([0-9Xx-]+)', re.IGNORECASE)
TIMEOUT = 90
MAX_RETRIES = 4
MAX_WORKERS_SEARCH = 22
MAX_WORKERS_METADATA = 4
MAX_WORKERS_WIKIDATA = 3
MAX_WORKERS_MARC = 26
METADATA_BATCH_SIZE = 2500
MARC_BATCH_SIZE = 100
TITLE_SRU_BATCH_SIZE = 100
TITLE_SRU_WORKERS = 8
SUBJECT_SRU_BATCH_SIZE = 100
SUBJECT_SRU_WORKERS = 6
WIKIDATA_BATCH_SIZE = 500
WIKIDATA_CONNECT_TIMEOUT = 10
WIKIDATA_READ_TIMEOUT = 60
WIKIDATA_FINAL_RETRIES = 2
COMMUNES_GENEVE = charger_liste(FICHIER_COMMUNES)
TERMES_TITRES = charger_liste(FICHIER_TITRES)
thread_local = threading.local()

def creer_session():
    return creer_session_http(retries=MAX_RETRIES, backoff=0.8, methods=['GET', 'POST'], pool_size=20, headers={'Accept': 'application/sparql-results+json', 'User-Agent': 'Geneve-Bibliographic-Research/1.0'})

def get_session():
    return obtenir_session_thread(thread_local, creer_session)

def normaliser_texte(texte):
    if texte is None:
        return ''
    texte = str(texte).strip()
    texte = texte.replace('œ', 'oe').replace('Œ', 'OE').replace('æ', 'ae').replace('Æ', 'AE')
    texte = ''.join((caractere for caractere in unicodedata.normalize('NFD', texte) if unicodedata.category(caractere) != 'Mn'))
    return texte.strip().lower()

def requete_sparql(query, method='POST'):
    session = get_session()
    if method == 'GET':
        response = session.get(SPARQL_URL, params={'query': query}, timeout=TIMEOUT)
    else:
        response = session.post(SPARQL_URL, data={'query': query}, timeout=TIMEOUT)
    response.raise_for_status()
    return response.json().get('results', {}).get('bindings', [])

def rechercher_lieu_isbn13(lieu):
    lieu_sparql = echapper_requete(lieu)
    query = f'\nPREFIX rdau: <http://rdaregistry.info/Elements/u/>\nPREFIX bibo: <http://purl.org/ontology/bibo/>\n\nSELECT\n    ?document\n    ?isbn\n\nWHERE {{\n\n    ?document\n        rdau:P60163\n        "{lieu_sparql}" .\n\n    ?document\n        bibo:isbn13\n        ?isbn .\n}}\n'
    debut = time.perf_counter()
    bindings = requete_sparql(query, method='GET')
    duree = time.perf_counter() - debut
    resultats = []
    for binding in bindings:
        document = valeur(binding, 'document')
        isbn = normaliser_isbn(valeur(binding, 'isbn'))
        if document and isbn:
            resultats.append((document, isbn))
    return {'lieu': lieu, 'type': 'ISBN13', 'resultats': resultats, 'temps': duree}

def rechercher_lieu_isbn10(lieu):
    lieu_sparql = echapper_requete(lieu)
    query = f'\nPREFIX rdau: <http://rdaregistry.info/Elements/u/>\nPREFIX bibo: <http://purl.org/ontology/bibo/>\n\nSELECT\n    ?document\n    ?isbn\n\nWHERE {{\n\n    ?document\n        rdau:P60163\n        "{lieu_sparql}" .\n\n    ?document\n        bibo:isbn10\n        ?isbn .\n}}\n'
    debut = time.perf_counter()
    bindings = requete_sparql(query, method='GET')
    duree = time.perf_counter() - debut
    resultats = []
    for binding in bindings:
        document = valeur(binding, 'document')
        isbn = normaliser_isbn(valeur(binding, 'isbn'))
        if document and isbn:
            resultats.append((document, isbn))
    return {'lieu': lieu, 'type': 'ISBN10', 'resultats': resultats, 'temps': duree}

def rechercher_documents_lieu():
    """Recherche les documents par lieu de publication via SPARQL DNB."""
    afficher_section('DNB - RECHERCHE LIEU')
    print(f'Termes : {len(COMMUNES_GENEVE):,}')
    print(f'Workers : {MAX_WORKERS_SEARCH}')
    print('ISBN : ISBN-10 + ISBN-13 -> sortie ISBN-13\n')
    debut = time.perf_counter()
    documents = {}
    taches = []
    for lieu in COMMUNES_GENEVE:
        taches.append((rechercher_lieu_isbn13, lieu))
        taches.append((rechercher_lieu_isbn10, lieu))
    with ThreadPoolExecutor(max_workers=MAX_WORKERS_SEARCH) as executor:
        futures = {executor.submit(fonction, lieu): (fonction.__name__, lieu) for fonction, lieu in taches}
        for future in as_completed(futures):
            fonction_nom, lieu = futures[future]
            try:
                resultat = future.result()
                lignes = resultat['resultats']
                type_isbn = resultat['type']
                temps = resultat['temps']
                for document, isbn in lignes:
                    documents.setdefault(document, {'isbn': set(), 'raisons': {'lieu_publication'}})
                    documents[document]['isbn'].add(isbn)
                print(f'✓ {lieu:<18} {type_isbn:<8} : {len(lignes):>6,} | {temps:.2f}s')
            except Exception as erreur:
                type_isbn = 'ISBN13' if 'isbn13' in fonction_nom else 'ISBN10'
                print(f'✗ {lieu:<18} {type_isbn:<8} : ERREUR | {type(erreur).__name__}: {erreur}')
    duree = time.perf_counter() - debut
    isbn_uniques = {isbn for infos in documents.values() for isbn in infos['isbn']}
    print(f'\nDocuments lieu uniques : {len(documents):,}')
    print(f'ISBN-13 uniques : {len(isbn_uniques):,}')
    print(f'Temps recherche lieu : {duree:.2f}s')
    return (documents, duree)

def construire_requete_sujets_sru():
    return ' OR '.join((f'SW="{echapper_requete(terme)}"' for terme in TERMES_TITRES))

def obtenir_total_sujets_sru(query_cql):
    session = get_session()
    response = session.get(DNB_SRU_URL, params={'version': '1.1', 'operation': 'searchRetrieve', 'query': query_cql, 'recordSchema': 'MARC21-xml', 'maximumRecords': 1, 'startRecord': 1}, headers={'Accept': 'application/xml, text/xml;q=0.9, */*;q=0.1'}, timeout=TIMEOUT)
    response.raise_for_status()
    root = ET.fromstring(response.content)
    element = root.find('.//srw:numberOfRecords', SRU_NS)
    if element is None or not element.text:
        raise RuntimeError('numberOfRecords introuvable dans la réponse SRU DNB')
    return int(element.text)

def analyser_notice_sujet_sru(record):
    champ_001 = record.find("marc:controlfield[@tag='001']", SRU_NS)
    if champ_001 is None or not champ_001.text:
        return None
    idn = champ_001.text.strip()
    document = f'https://d-nb.info/{idn}'
    isbns = set()
    for sf in record.findall("marc:datafield[@tag='020']/marc:subfield[@code='a']", SRU_NS):
        if sf.text:
            isbn = normaliser_isbn(sf.text)
            if isbn:
                isbns.add(isbn)
    numerique = any(((sf.text or '').strip().lower() == 'cr' for sf in record.findall("marc:datafield[@tag='338']/marc:subfield[@code='b']", SRU_NS)))
    return {'document': document, 'isbn': isbns, 'numerique': numerique}

def recuperer_page_sujets_sru(query_cql, start_record):
    session = get_session()
    response = session.get(DNB_SRU_URL, params={'version': '1.1', 'operation': 'searchRetrieve', 'query': query_cql, 'recordSchema': 'MARC21-xml', 'maximumRecords': SUBJECT_SRU_BATCH_SIZE, 'startRecord': start_record}, headers={'Accept': 'application/xml, text/xml;q=0.9, */*;q=0.1'}, timeout=TIMEOUT)
    response.raise_for_status()
    root = ET.fromstring(response.content)
    return [resultat for record in root.findall('.//marc:record', SRU_NS) if (resultat := analyser_notice_sujet_sru(record))]

def rechercher_documents_sujets_sru():
    afficher_section('DNB - RECHERCHE SUJETS SRU')
    print(f'Termes : {len(TERMES_TITRES):,}')
    print(f'Workers : {SUBJECT_SRU_WORKERS}')
    print(f'Taille page SRU : {SUBJECT_SRU_BATCH_SIZE}\n')
    debut = time.perf_counter()
    query_cql = construire_requete_sujets_sru()
    nombre_total = obtenir_total_sujets_sru(query_cql)
    nombre_pages = (nombre_total + SUBJECT_SRU_BATCH_SIZE - 1) // SUBJECT_SRU_BATCH_SIZE
    print(f'Notices SRU annoncées : {nombre_total:,}')
    print(f'Nombre pages : {nombre_pages:,}\n')
    starts = [1 + i * SUBJECT_SRU_BATCH_SIZE for i in range(nombre_pages)]
    resultats_tous, erreurs = ([], [])
    with ThreadPoolExecutor(max_workers=SUBJECT_SRU_WORKERS) as executor:
        futures = {executor.submit(recuperer_page_sujets_sru, query_cql, start): start for start in starts}
        for terminees, future in enumerate(as_completed(futures), 1):
            start_record = futures[future]
            try:
                resultats_tous.extend(future.result())
            except Exception as erreur:
                erreurs.append({'startRecord': start_record, 'erreur': f'{type(erreur).__name__}: {erreur}'})
            if terminees == nombre_pages or terminees % 5 == 0:
                print(f'Pages terminées : {terminees:,}/{nombre_pages:,} | erreurs : {len(erreurs):,}')
    if erreurs:
        raise RuntimeError(f'{len(erreurs)} page(s) SRU sujet en erreur : {erreurs[:3]}')
    documents, documents_numeriques = ({}, set())
    notices_sans_isbn = 0
    for resultat in resultats_tous:
        document, isbns = (resultat['document'], resultat['isbn'])
        if not isbns:
            notices_sans_isbn += 1
            continue
        documents.setdefault(document, {'isbn': set(), 'raisons': {'sujet'}})
        documents[document]['isbn'].update(isbns)
        if resultat['numerique']:
            documents_numeriques.add(document)
    documents_physiques = {document: infos for document, infos in documents.items() if document not in documents_numeriques}
    isbn_uniques = {isbn for infos in documents_physiques.values() for isbn in infos['isbn']}
    duree = time.perf_counter() - debut
    print(f'Notices reçues : {len(resultats_tous):,}')
    print(f'Notices sans ISBN : {notices_sans_isbn:,}')
    print(f'Documents sujet avec ISBN : {len(documents):,}')
    print(f'Numériques sujet détectés : {len(documents_numeriques):,}')
    print(f'Documents sujet physiques : {len(documents_physiques):,}')
    print(f'ISBN-13 sujet physiques uniques : {len(isbn_uniques):,}')
    print(f'Temps recherche sujet : {duree:.2f}s')
    return (documents_physiques, documents_numeriques, duree, nombre_total)

def construire_requete_titres_sru():
    return ' OR '.join((f'TIT="{echapper_requete(terme)}"' for terme in TERMES_TITRES))

def obtenir_total_titres_sru(query_cql):
    session = get_session()
    response = session.get(DNB_SRU_URL, params={'version': '1.1', 'operation': 'searchRetrieve', 'query': query_cql, 'recordSchema': 'MARC21-xml', 'maximumRecords': 1, 'startRecord': 1}, headers={'Accept': 'application/xml, text/xml;q=0.9, */*;q=0.1'}, timeout=TIMEOUT)
    response.raise_for_status()
    root = ET.fromstring(response.content)
    element = root.find('.//srw:numberOfRecords', SRU_NS)
    if element is None or not element.text:
        raise RuntimeError('numberOfRecords introuvable dans la réponse SRU DNB')
    return int(element.text)

def analyser_notice_titre_sru(record):
    champ_001 = record.find("marc:controlfield[@tag='001']", SRU_NS)
    if champ_001 is None or not champ_001.text:
        return None
    idn = champ_001.text.strip()
    document = f'https://d-nb.info/{idn}'
    isbns = set()
    for sf in record.findall("marc:datafield[@tag='020']/marc:subfield[@code='a']", SRU_NS):
        if not sf.text:
            continue
        isbn = normaliser_isbn(sf.text)
        if isbn:
            isbns.add(isbn)
    numerique = False
    for sf in record.findall("marc:datafield[@tag='338']/marc:subfield[@code='b']", SRU_NS):
        if (sf.text or '').strip().lower() == 'cr':
            numerique = True
            break
    return {'document': document, 'isbn': isbns, 'numerique': numerique}

def recuperer_page_titres_sru(query_cql, start_record):
    session = get_session()
    response = session.get(DNB_SRU_URL, params={'version': '1.1', 'operation': 'searchRetrieve', 'query': query_cql, 'recordSchema': 'MARC21-xml', 'maximumRecords': TITLE_SRU_BATCH_SIZE, 'startRecord': start_record}, headers={'Accept': 'application/xml, text/xml;q=0.9, */*;q=0.1'}, timeout=TIMEOUT)
    response.raise_for_status()
    root = ET.fromstring(response.content)
    resultats = []
    for record in root.findall('.//marc:record', SRU_NS):
        resultat = analyser_notice_titre_sru(record)
        if resultat:
            resultats.append(resultat)
    return resultats

def rechercher_documents_titres_sru():
    """Recherche les titres via SRU DNB et détecte directement 338$b = cr."""
    afficher_section('DNB - RECHERCHE TITRES SRU')
    print(f'Termes : {len(TERMES_TITRES):,}')
    print(f'Workers : {TITLE_SRU_WORKERS}')
    print(f'Taille page SRU : {TITLE_SRU_BATCH_SIZE}\n')
    debut = time.perf_counter()
    query_cql = construire_requete_titres_sru()
    nombre_total = obtenir_total_titres_sru(query_cql)
    nombre_pages = (nombre_total + TITLE_SRU_BATCH_SIZE - 1) // TITLE_SRU_BATCH_SIZE
    starts = [1 + i * TITLE_SRU_BATCH_SIZE for i in range(nombre_pages)]
    resultats_tous = []
    erreurs = []
    with ThreadPoolExecutor(max_workers=TITLE_SRU_WORKERS) as executor:
        futures = {executor.submit(recuperer_page_titres_sru, query_cql, start_record): start_record for start_record in starts}
        terminees = 0
        for future in as_completed(futures):
            start_record = futures[future]
            try:
                resultats_tous.extend(future.result())
            except Exception as erreur:
                erreurs.append({'startRecord': start_record, 'erreur': f'{type(erreur).__name__}: {erreur}'})
            terminees += 1
            if terminees == nombre_pages or terminees % 20 == 0:
                print(f'Pages terminées : {terminees:,}/{nombre_pages:,} | erreurs : {len(erreurs):,}')
    if erreurs:
        raise RuntimeError(f'{len(erreurs)} page(s) SRU titre en erreur : {erreurs[:3]}')
    documents = {}
    documents_numeriques = set()
    for resultat in resultats_tous:
        document = resultat['document']
        isbns = resultat['isbn']
        if not isbns:
            continue
        documents.setdefault(document, {'isbn': set(), 'raisons': {'titre'}})
        documents[document]['isbn'].update(isbns)
        if resultat['numerique']:
            documents_numeriques.add(document)
    duree = time.perf_counter() - debut
    print(f'Notices SRU annoncées : {nombre_total:,}')
    print(f'Documents titre avec ISBN : {len(documents):,}')
    print(f'Numériques titre détectés : {len(documents_numeriques):,}')
    print(f'Temps recherche titre : {duree:.2f}s')
    return (documents, documents_numeriques, duree, nombre_total)

def rechercher_documents_dnb():
    debut_global = time.perf_counter()
    documents_lieu, temps_lieu = rechercher_documents_lieu()
    documents_lieu_format = {document: {'isbn': set(infos['isbn']), 'raisons': {'lieu_publication'}} for document, infos in documents_lieu.items()}
    afficher_section('DNB - TITRES + SUJETS + FILTRE MARC LIEU EN PARALLELE')
    debut_parallele = time.perf_counter()
    with ThreadPoolExecutor(max_workers=3) as executor:
        future_titres = executor.submit(rechercher_documents_titres_sru)
        future_sujets = executor.submit(rechercher_documents_sujets_sru)
        future_marc = executor.submit(filtrer_documents_numeriques, documents_lieu_format, MARC_BATCH_SIZE, MAX_WORKERS_MARC, 'LIEU')
        documents_titres, numeriques_titres, temps_titres, nb_notices_titres = future_titres.result()
        documents_sujets_physiques, numeriques_sujets, temps_sujets, nb_notices_sujets = future_sujets.result()
        documents_lieu_physiques, erreurs_marc, _, temps_marc_lieu = future_marc.result()
    temps_parallele = time.perf_counter() - debut_parallele
    documents_titres_physiques = {document: infos for document, infos in documents_titres.items() if document not in numeriques_titres}
    numeriques_lieu = set(documents_lieu_format) - set(documents_lieu_physiques)

    def fusionner(destination, source):
        for document, infos in source.items():
            cible = destination.setdefault(document, {'isbn': set(), 'raisons': set()})
            cible['isbn'].update(infos.get('isbn', set()))
            cible['raisons'].update(infos.get('raisons', set()))
    documents = {}
    fusionner(documents, documents_lieu_physiques)
    fusionner(documents, documents_titres_physiques)
    fusionner(documents, documents_sujets_physiques)
    documents_numeriques = numeriques_lieu | set(numeriques_titres) | set(numeriques_sujets)
    nb_lieu = sum(('lieu_publication' in x['raisons'] for x in documents.values()))
    nb_titre = sum(('titre' in x['raisons'] for x in documents.values()))
    nb_sujet = sum(('sujet' in x['raisons'] for x in documents.values()))
    nb_lieu_titre = sum(({'lieu_publication', 'titre'}.issubset(x['raisons']) for x in documents.values()))
    nb_lieu_sujet = sum(({'lieu_publication', 'sujet'}.issubset(x['raisons']) for x in documents.values()))
    nb_titre_sujet = sum(({'titre', 'sujet'}.issubset(x['raisons']) for x in documents.values()))
    nb_trois = sum(({'lieu_publication', 'titre', 'sujet'}.issubset(x['raisons']) for x in documents.values()))
    isbn_uniques = {isbn for infos in documents.values() for isbn in infos['isbn']}
    repartition_documents = {}
    for infos in documents.values():
        raison = ' | '.join(sorted(infos['raisons']))
        repartition_documents[raison] = repartition_documents.get(raison, 0) + 1
    duree = time.perf_counter() - debut_global
    afficher_section('DNB - FIN RECHERCHE / FILTRE')
    print(f'Documents lieu initiaux : {len(documents_lieu_format):,}')
    print(f'Documents titre avec ISBN : {len(documents_titres):,}')
    print(f'Documents sujet physiques : {len(documents_sujets_physiques):,}')
    print(f'Numériques lieu exclus : {len(numeriques_lieu):,}')
    print(f'Numériques titre exclus : {len(numeriques_titres):,}')
    print(f'Numériques sujet exclus : {len(numeriques_sujets):,}')
    print(f'Numériques uniques exclus : {len(documents_numeriques):,}')
    print(f'Documents physiques finaux : {len(documents):,}')
    print(f'ISBN-13 uniques : {len(isbn_uniques):,}')
    print(f'Trouvés par lieu : {nb_lieu:,}')
    print(f'Trouvés par titre : {nb_titre:,}')
    print(f'Trouvés par sujet : {nb_sujet:,}')
    print(f'Lieu + titre : {nb_lieu_titre:,}')
    print(f'Lieu + sujet : {nb_lieu_sujet:,}')
    print(f'Titre + sujet : {nb_titre_sujet:,}')
    print(f'Lieu + titre + sujet : {nb_trois:,}')
    print(f'Temps lieu : {temps_lieu:.2f}s')
    print(f'Temps titre : {temps_titres:.2f}s')
    print(f'Temps sujet : {temps_sujets:.2f}s')
    print(f'Temps MARC lieu : {temps_marc_lieu:.2f}s')
    print(f'Temps bloc parallèle : {temps_parallele:.2f}s')
    print(f'Temps recherche + filtre : {duree:.2f}s')
    print('Répartition documents :')
    for raison, nombre in sorted(repartition_documents.items(), key=lambda x: (-x[1], x[0])):
        print(f'  {raison:<42} : {nombre:,}')
    print(SEPARATEUR)
    stats = {'temps_lieu': temps_lieu, 'temps_titres': temps_titres, 'temps_sujets': temps_sujets, 'temps_marc_lieu': temps_marc_lieu, 'temps_bloc_parallele': temps_parallele, 'temps_recherche_filtre': duree, 'nb_notices_titres_sru': nb_notices_titres, 'nb_notices_sujets_sru': nb_notices_sujets, 'nb_documents_lieu': nb_lieu, 'nb_documents_titre': nb_titre, 'nb_documents_sujet': nb_sujet, 'nb_lieu_titre': nb_lieu_titre, 'nb_lieu_sujet': nb_lieu_sujet, 'nb_titre_sujet': nb_titre_sujet, 'nb_lieu_titre_sujet': nb_trois, 'nb_numeriques_lieu': len(numeriques_lieu), 'nb_numeriques_titre': len(numeriques_titres), 'nb_numeriques_sujet': len(numeriques_sujets), 'nb_numeriques_total': len(documents_numeriques), 'nb_documents_physiques': len(documents), 'nb_isbn_uniques': len(isbn_uniques), 'repartition_documents': repartition_documents}
    return (documents, erreurs_marc, stats)

def extraire_idn_dnb(document):
    if not document:
        return None
    match = DNB_ID_RE.search(str(document))
    if not match:
        return None
    return match.group(1).strip() or None

def construire_requete_sru_idn(liste_idn):
    return ' OR '.join((f'dnb.idn="{idn}"' for idn in liste_idn))

def parser_numerique_marcxml(xml_bytes, idn_attendus):
    """
    Retourne {idn: bool}.

    True uniquement si au moins un champ 338 contient
    exactement un sous-champ $b = cr.
    """
    root = ET.fromstring(xml_bytes)
    resultats = {}
    for record in root.findall(f'.//{{{MARC_NS}}}record'):
        idn = None
        for controlfield in record.findall(f'{{{MARC_NS}}}controlfield'):
            if controlfield.get('tag') == '001':
                idn = (controlfield.text or '').strip()
                break
        if not idn:
            continue
        numerique = False
        for datafield in record.findall(f'{{{MARC_NS}}}datafield'):
            if datafield.get('tag') != '338':
                continue
            for subfield in datafield.findall(f'{{{MARC_NS}}}subfield'):
                if subfield.get('code') != 'b':
                    continue
                valeur_338b = (subfield.text or '').strip().lower()
                if valeur_338b == 'cr':
                    numerique = True
                    break
            if numerique:
                break
        resultats[idn] = numerique
    return {idn: resultats[idn] for idn in idn_attendus if idn in resultats}

def executer_requete_marc_dnb(liste_idn):
    session = get_session()
    response = session.get(DNB_SRU_URL, params={'version': '1.1', 'operation': 'searchRetrieve', 'query': construire_requete_sru_idn(liste_idn), 'recordSchema': 'MARC21-xml', 'maximumRecords': len(liste_idn)}, headers={'Accept': 'application/xml, text/xml;q=0.9, */*;q=0.1'}, timeout=TIMEOUT)
    response.raise_for_status()
    return parser_numerique_marcxml(response.content, liste_idn)

def verifier_lot_marc_robuste(liste_idn):
    """
    Si un lot échoue ou si certaines notices ne sont pas renvoyées,
    le lot est divisé récursivement jusqu'à isoler l'IDN concerné.
    """
    try:
        resultats = executer_requete_marc_dnb(liste_idn)
        manquants = [idn for idn in liste_idn if idn not in resultats]
        if not manquants:
            return (resultats, [])
        if len(liste_idn) <= 1:
            return (resultats, [{'idn_dnb': liste_idn[0], 'erreur': 'Notice MARC absente de la réponse SRU'}])
    except Exception as erreur:
        if len(liste_idn) <= 1:
            return ({}, [{'idn_dnb': liste_idn[0], 'erreur': f'{type(erreur).__name__}: {erreur}'}])
    milieu = len(liste_idn) // 2
    gauche, erreurs_gauche = verifier_lot_marc_robuste(liste_idn[:milieu])
    droite, erreurs_droite = verifier_lot_marc_robuste(liste_idn[milieu:])
    gauche.update(droite)
    return (gauche, erreurs_gauche + erreurs_droite)

def filtrer_documents_numeriques(documents, batch_size=MARC_BATCH_SIZE, max_workers=MAX_WORKERS_MARC, libelle=''):
    """Supprime les notices DNB dont 338 $b = cr."""
    debut = time.perf_counter()
    if not documents:
        return (documents, [], 0, 0.0)
    afficher_section('DNB - FILTRE NUMERIQUE 338 $b = cr' + (f' - {libelle}' if libelle else ''))
    document_par_idn = {}
    for document in documents.keys():
        idn = extraire_idn_dnb(document)
        if idn:
            document_par_idn[idn] = document
    liste_idn = list(document_par_idn.keys())
    lots = list(creer_lots(liste_idn, batch_size))
    print(f'Documents à contrôler : {len(liste_idn):,}')
    print(f'Taille lot SRU : {batch_size}')
    print(f'Nombre lots : {len(lots):,}')
    print(f'Workers : {max_workers}\n')
    statut_numerique = {}
    erreurs = []
    termines = 0
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(verifier_lot_marc_robuste, lot): numero for numero, lot in enumerate(lots, start=1)}
        for future in as_completed(futures):
            numero = futures[future]
            try:
                resultats_lot, erreurs_lot = future.result()
                statut_numerique.update(resultats_lot)
                erreurs.extend(erreurs_lot)
            except Exception as erreur:
                erreurs.append({'lot': numero, 'erreur': f'{type(erreur).__name__}: {erreur}'})
            termines += 1
            if termines == len(lots) or termines % 20 == 0:
                print(f'Lots terminés : {termines:,}/{len(lots):,} | erreurs : {len(erreurs):,}')
    idn_numeriques = {idn for idn, numerique in statut_numerique.items() if numerique}
    documents_numeriques = {document_par_idn[idn] for idn in idn_numeriques if idn in document_par_idn}
    documents_filtres = {document: infos for document, infos in documents.items() if document not in documents_numeriques}
    duree = time.perf_counter() - debut
    print(f'Notices numériques exclues : {len(documents_numeriques):,}')
    print(f'Documents conservés : {len(documents_filtres):,}')
    print(f'Erreurs MARC définitives : {len(erreurs):,}')
    print(f'Temps filtre MARC : {duree:.2f}s')
    return (documents_filtres, erreurs, len(documents_numeriques), duree)

def recuperer_metadata_lot(documents):
    values = '\n'.join((f'<{document}>' for document in documents))
    query = f'\nPREFIX dc: <http://purl.org/dc/elements/1.1/>\nPREFIX dcterms: <http://purl.org/dc/terms/>\nPREFIX rdau: <http://rdaregistry.info/Elements/u/>\n\nSELECT\n    ?document\n    ?type\n    ?valeur\n\nWHERE {{\n\n    VALUES ?document {{\n        {values}\n    }}\n\n    {{\n        ?document\n            dc:title\n            ?valeur .\n\n        BIND(\n            "titre"\n            AS ?type\n        )\n    }}\n\n    UNION\n\n    {{\n        ?document\n            dcterms:issued\n            ?valeur .\n\n        BIND(\n            "annee"\n            AS ?type\n        )\n    }}\n\n    UNION\n\n    {{\n        ?document\n            rdau:P60163\n            ?valeur .\n\n        BIND(\n            "lieuPublication"\n            AS ?type\n        )\n    }}\n\n    UNION\n\n    {{\n        ?document\n            dc:publisher\n            ?valeur .\n\n        BIND(\n            "editeur"\n            AS ?type\n        )\n    }}\n}}\n'
    bindings = requete_sparql(query, method='POST')
    resultats = {}
    for binding in bindings:
        document = valeur(binding, 'document')
        type_metadata = valeur(binding, 'type')
        valeur_metadata = valeur(binding, 'valeur')
        if not document:
            continue
        if document not in resultats:
            resultats[document] = {'titre': set(), 'annee': set(), 'nomAuteur': set(), 'gndAuteur': set(), 'lieuPublication': set(), 'editeur': set(), 'sujet': set()}
        if type_metadata in resultats[document] and valeur_metadata:
            resultats[document][type_metadata].add(valeur_metadata.strip())
    return resultats

def recuperer_auteurs_lot(documents):
    """
    Récupère les auteurs reliés aux documents DNB.

    Le GND est la clé d'identité utilisée pour la résolution Wikidata -> IdRef.
    Le nom n'est qu'une métadonnée facultative d'affichage et n'intervient
    jamais dans la correspondance d'autorité.
    """
    values = '\n'.join((f'<{document}>' for document in documents))
    query = f'\nPREFIX dcterms: <http://purl.org/dc/terms/>\nPREFIX rel: <http://id.loc.gov/vocabulary/relators/>\nPREFIX gndo: <https://d-nb.info/standards/elementset/gnd#>\n\nSELECT DISTINCT\n    ?document\n    ?agent\n    ?nomAuteur\n\nWHERE {{\n    VALUES ?document {{\n        {values}\n    }}\n\n    VALUES ?relation {{\n        dcterms:creator\n        rel:aut\n    }}\n\n    ?document\n        ?relation\n        ?agent .\n\n    FILTER(isIRI(?agent))\n    FILTER(STRSTARTS(STR(?agent), "https://d-nb.info/gnd/"))\n\n    OPTIONAL {{\n        VALUES ?predicatNom {{\n            gndo:preferredNameForThePerson\n            gndo:preferredName\n        }}\n\n        ?agent\n            ?predicatNom\n            ?nomAuteur .\n\n        FILTER(isLiteral(?nomAuteur))\n    }}\n}}\n'
    bindings = requete_sparql(query, method='POST')
    resultats = {}
    for binding in bindings:
        document = valeur(binding, 'document')
        agent = valeur(binding, 'agent')
        nom_auteur = valeur(binding, 'nomAuteur')
        if not document or not agent:
            continue
        infos = resultats.setdefault(document, {'noms': set(), 'gnd_ids': set()})
        if nom_auteur:
            infos['noms'].add(nom_auteur.strip())
        if '/gnd/' in agent:
            gnd_id = agent.rsplit('/gnd/', 1)[-1].strip().strip('/')
            if gnd_id:
                infos['gnd_ids'].add(gnd_id)
    return resultats

def recuperer_sujets_lot(documents):
    values = '\n'.join((f'<{document}>' for document in documents))
    query = f'\nPREFIX dcterms: <http://purl.org/dc/terms/>\nPREFIX gndo: <https://d-nb.info/standards/elementset/gnd#>\n\nSELECT\n    ?document\n    ?sujet\n\nWHERE {{\n\n    VALUES ?document {{\n        {values}\n    }}\n\n    ?document\n        dcterms:subject\n        ?sujetURI .\n\n    FILTER(\n        STRSTARTS(\n            STR(?sujetURI),\n            "https://d-nb.info/gnd/"\n        )\n    )\n\n    VALUES ?predicatNom {{\n\n        gndo:preferredNameForTheSubjectHeading\n        gndo:preferredNameForThePlaceOrGeographicName\n        gndo:preferredNameForTheCorporateBody\n        gndo:preferredNameForThePerson\n        gndo:preferredNameForTheConferenceOrEvent\n        gndo:preferredNameForTheWork\n        gndo:preferredName\n    }}\n\n    ?sujetURI\n        ?predicatNom\n        ?sujet .\n\n    FILTER(\n        isLiteral(\n            ?sujet\n        )\n    )\n}}\n'
    bindings = requete_sparql(query, method='POST')
    resultats = {}
    for binding in bindings:
        document = valeur(binding, 'document')
        sujet = valeur(binding, 'sujet')
        if document and sujet:
            resultats.setdefault(document, set()).add(sujet.strip())
    return resultats

def traiter_lot_metadata(documents):
    metadata = recuperer_metadata_lot(documents)
    auteurs = recuperer_auteurs_lot(documents)
    sujets = recuperer_sujets_lot(documents)
    for document in documents:
        if document not in metadata:
            metadata[document] = {'titre': set(), 'annee': set(), 'nomAuteur': set(), 'gndAuteur': set(), 'lieuPublication': set(), 'editeur': set(), 'sujet': set()}
        infos_auteurs = auteurs.get(document, {'noms': set(), 'gnd_ids': set()})
        metadata[document]['nomAuteur'].update(infos_auteurs['noms'])
        metadata[document]['gndAuteur'].update(infos_auteurs['gnd_ids'])
        metadata[document]['sujet'].update(sujets.get(document, set()))
    return metadata

def recuperer_metadonnees(documents):
    liste_documents = list(documents.keys())
    lots = list(creer_lots(liste_documents, METADATA_BATCH_SIZE))
    afficher_section('DNB - METADONNEES')
    print(f'Documents : {len(liste_documents):,}')
    print(f'Taille lot : {METADATA_BATCH_SIZE}')
    print(f'Nombre lots : {len(lots):,}')
    print(f'Workers : {MAX_WORKERS_METADATA}\n')
    debut = time.perf_counter()
    metadata_final = {}
    termines = 0
    erreurs = 0
    with ThreadPoolExecutor(max_workers=MAX_WORKERS_METADATA) as executor:
        futures = {executor.submit(traiter_lot_metadata, lot): numero for numero, lot in enumerate(lots, start=1)}
        for future in as_completed(futures):
            try:
                metadata_final.update(future.result())
            except Exception as erreur:
                erreurs += 1
                print(f'✗ Lot métadonnées en erreur : {type(erreur).__name__}: {erreur}')
            termines += 1
            if termines == len(lots) or termines % 5 == 0:
                print(f'Lots terminés : {termines:,}/{len(lots):,} | erreurs : {erreurs:,}')
    duree = time.perf_counter() - debut
    print(f'Temps métadonnées : {duree:.2f}s')
    return metadata_final

def creer_session_wikidata():
    return creer_session_http(retries=MAX_RETRIES, backoff=0.8, methods=['GET', 'POST'], pool_size=MAX_WORKERS_WIKIDATA + 2, headers={'Accept': 'application/sparql-results+json', 'User-Agent': 'Geneve-Bibliographic-Research/1.0 (authority matching via Wikidata)'}, monter_http=False)

def get_session_wikidata():
    return obtenir_session_thread(thread_local_wikidata, creer_session_wikidata)

def requete_lot_wikidata_gnd(liste_gnd):
    """Retourne {gnd_id: {idref, ...}} pour un lot de GND."""
    values = ' '.join((f'"{echapper_requete(gnd)}"' for gnd in liste_gnd))
    query = f'\nPREFIX wdt: <http://www.wikidata.org/prop/direct/>\n\nSELECT ?gnd ?idref\nWHERE {{\n    VALUES ?gnd {{ {values} }}\n    ?item wdt:P227 ?gnd ;\n          wdt:P269 ?idref .\n}}\n'
    response = get_session_wikidata().post(WIKIDATA_SPARQL_URL, data={'query': query, 'format': 'json'}, timeout=(WIKIDATA_CONNECT_TIMEOUT, WIKIDATA_READ_TIMEOUT))
    response.raise_for_status()
    resultats = {gnd: set() for gnd in liste_gnd}
    for binding in response.json().get('results', {}).get('bindings', []):
        gnd = valeur(binding, 'gnd')
        idref = valeur(binding, 'idref')
        if gnd and idref and (gnd in resultats):
            resultats[gnd].add(idref.strip())
    return resultats

def requete_lot_wikidata_robuste(liste_gnd, stats):
    """Fallback récursif : un lot en échec est divisé jusqu'au GND isolé."""
    stats['requetes_http'] += 1
    try:
        return requete_lot_wikidata_gnd(liste_gnd)
    except Exception as erreur:
        stats['lots_echoues'] += 1
        if len(liste_gnd) == 1:
            gnd = liste_gnd[0]
            for tentative in range(WIKIDATA_FINAL_RETRIES):
                stats['requetes_http'] += 1
                try:
                    if tentative:
                        time.sleep(0.25)
                    return requete_lot_wikidata_gnd(liste_gnd)
                except Exception:
                    pass
            stats['erreurs_finales'].append({'gnd_id': gnd, 'erreur': f'{type(erreur).__name__}: {erreur}'})
            return {gnd: set()}
        stats['divisions'] += 1
        milieu = len(liste_gnd) // 2
        gauche = requete_lot_wikidata_robuste(liste_gnd[:milieu], stats)
        droite = requete_lot_wikidata_robuste(liste_gnd[milieu:], stats)
        gauche.update(droite)
        return gauche

def recuperer_ppn_idref(metadata):
    """Résout les GND DNB en IdRef via Wikidata."""
    gnd_uniques = sorted({gnd for meta in metadata.values() for gnd in meta.get('gndAuteur', set()) if gnd})
    afficher_section('WIKIDATA - GND -> IDREF')
    if not gnd_uniques:
        print('Aucun GND à résoudre.')
        return {}
    lots = list(creer_lots(gnd_uniques, WIKIDATA_BATCH_SIZE))
    print(f'GND uniques : {len(gnd_uniques):,}')
    print(f'Taille lot Wikidata : {WIKIDATA_BATCH_SIZE}')
    print(f'Lots : {len(lots):,}')
    print(f'Workers Wikidata : {MAX_WORKERS_WIKIDATA}\n')
    debut = time.perf_counter()
    idrefs_par_gnd = {}
    stats_globales = {'requetes_http': 0, 'lots_echoues': 0, 'divisions': 0, 'erreurs_finales': []}

    def traiter_lot(lot):
        stats = {'requetes_http': 0, 'lots_echoues': 0, 'divisions': 0, 'erreurs_finales': []}
        return (requete_lot_wikidata_robuste(lot, stats), stats)
    with ThreadPoolExecutor(max_workers=MAX_WORKERS_WIKIDATA) as executor:
        futures = [executor.submit(traiter_lot, lot) for lot in lots]
        for i, future in enumerate(as_completed(futures), 1):
            resultat_lot, stats_lot = future.result()
            idrefs_par_gnd.update(resultat_lot)
            for cle in ('requetes_http', 'lots_echoues', 'divisions'):
                stats_globales[cle] += stats_lot[cle]
            stats_globales['erreurs_finales'].extend(stats_lot['erreurs_finales'])
            if i == len(lots) or i % 5 == 0:
                trouves = sum((bool(v) for v in idrefs_par_gnd.values()))
                print(f'Lots terminés : {i:,}/{len(lots):,} | GND traités : {len(idrefs_par_gnd):,}/{len(gnd_uniques):,} | avec IdRef : {trouves:,}')
    ppn_par_gnd = {}
    ambigus = 0
    for gnd, idrefs in idrefs_par_gnd.items():
        if len(idrefs) == 1:
            ppn_par_gnd[gnd] = next(iter(idrefs))
        elif len(idrefs) > 1:
            ambigus += 1
    duree = time.perf_counter() - debut
    sans_idref = len(gnd_uniques) - len(ppn_par_gnd) - ambigus
    print(f'Temps Wikidata : {duree:.2f}s')
    print(f'GND avec IdRef unique : {len(ppn_par_gnd):,}')
    print(f'GND sans IdRef : {sans_idref:,}')
    print(f'GND ambigus : {ambigus:,}')
    print(f"Requêtes HTTP : {stats_globales['requetes_http']:,}")
    print(f"Lots échoués : {stats_globales['lots_echoues']:,}")
    print(f"Divisions fallback : {stats_globales['divisions']:,}")
    print(f"Erreurs finales : {len(stats_globales['erreurs_finales']):,}")
    if stats_globales['erreurs_finales']:
        for item in stats_globales['erreurs_finales'][:10]:
            print(f"✗ GND {item['gnd_id']} : {item['erreur']}")
    return ppn_par_gnd

def construire_dataframe(documents, metadata, ppn_par_gnd):
    lignes = []
    for document, infos in documents.items():
        meta = metadata.get(document, {})
        auteurs = sorted(meta.get('nomAuteur', set()))
        nom_auteur = concat_unique(auteurs)
        gnd_ids = meta.get('gndAuteur', set())
        ppns = {ppn_par_gnd[gnd] for gnd in gnd_ids if gnd in ppn_par_gnd}
        if not ppns:
            ppns = {''}
        titre = concat_unique(meta.get('titre', set()))
        annee = concat_unique(meta.get('annee', set()))
        lieu = concat_unique(meta.get('lieuPublication', set()))
        editeur = concat_unique(meta.get('editeur', set()))
        sujet = concat_unique(meta.get('sujet', set()))
        raisons = concat_unique(infos.get('raisons', set()))
        isbns = set()
        for isbn in infos['isbn']:
            isbn_normalise = normaliser_isbn(isbn)
            if isbn_normalise:
                isbns.add(isbn_normalise)
        for ppn in sorted(ppns):
            for isbn_normalise in sorted(isbns):
                lignes.append({'ppn': ppn, 'isbn_normalise': isbn_normalise, 'titre': titre, 'annee': annee, 'nomAuteur': nom_auteur, 'lieuPublication': lieu, 'editeur': editeur, 'sujet': sujet, 'raisons': raisons})
    colonnes = ['ppn', 'isbn_normalise', 'titre', 'annee', 'nomAuteur', 'lieuPublication', 'editeur', 'sujet', 'raisons']
    df = pd.DataFrame(lignes, columns=colonnes)
    if df.empty:
        return df
    df = df.drop_duplicates().sort_values(['ppn', 'isbn_normalise', 'titre'], na_position='last').reset_index(drop=True)
    return df

def recherche_DNB():
    """Lance le pipeline DNB avec suivi détaillé dans la console."""
    debut_global = time.perf_counter()
    documents, erreurs_marc, stats_recherche = rechercher_documents_dnb()
    if not documents:
        df_vide = pd.DataFrame(columns=['ppn', 'isbn_normalise', 'titre', 'annee', 'nomAuteur', 'lieuPublication', 'editeur', 'sujet', 'raisons'])
        df_vide.attrs['erreurs_marc_dnb'] = erreurs_marc
        df_vide.attrs['notices_numeriques_dnb_exclues'] = stats_recherche.get('nb_numeriques_total', 0)
        df_vide.attrs['stats_dnb'] = stats_recherche
        return df_vide
    debut = time.perf_counter()
    metadata = recuperer_metadonnees(documents)
    temps_metadata = time.perf_counter() - debut
    debut = time.perf_counter()
    ppn_par_gnd = recuperer_ppn_idref(metadata)
    temps_wikidata = time.perf_counter() - debut
    debut = time.perf_counter()
    df = construire_dataframe(documents, metadata, ppn_par_gnd)
    temps_dataframe = time.perf_counter() - debut
    df.attrs['erreurs_marc_dnb'] = erreurs_marc
    df.attrs['notices_numeriques_dnb_exclues'] = stats_recherche.get('nb_numeriques_total', 0)
    duree = time.perf_counter() - debut_global
    if not df.empty:
        nombre_isbn = df['isbn_normalise'].nunique()
        lignes_ppn = df['ppn'].ne('').sum()
        ppn_uniques = df.loc[df['ppn'].ne(''), 'ppn'].nunique()
        lignes_sujet = df['sujet'].ne('').sum()
        raisons_counts = df['raisons'].value_counts().to_dict()
    else:
        nombre_isbn = 0
        lignes_ppn = 0
        ppn_uniques = 0
        lignes_sujet = 0
        raisons_counts = {}
    df.attrs['stats_dnb'] = {**stats_recherche, 'documents_dnb_physiques_uniques': len(documents), 'lignes_finales': len(df), 'isbn_13_uniques': int(nombre_isbn), 'ppn_idref_uniques': int(ppn_uniques), 'lignes_avec_ppn': int(lignes_ppn), 'lignes_avec_sujet': int(lignes_sujet), 'erreurs_controle_marc': len(erreurs_marc), 'temps_metadata': temps_metadata, 'temps_wikidata': temps_wikidata, 'temps_dataframe': temps_dataframe, 'duree_totale': duree, 'repartition_raisons': raisons_counts}
    afficher_section('RESULTATS DNB')
    print(f'Documents DNB physiques uniques : {len(documents):,}')
    print(f'Lignes finales : {len(df):,}')
    print(f'ISBN-13 uniques : {int(nombre_isbn):,}')
    print(f'PPN IdRef uniques : {int(ppn_uniques):,}')
    print(f'Lignes avec PPN : {int(lignes_ppn):,}')
    print(f'Lignes avec sujet : {int(lignes_sujet):,}')
    print(f"Notices numériques exclues : {stats_recherche.get('nb_numeriques_total', 0):,}")
    print(f'Erreurs contrôle MARC : {len(erreurs_marc):,}')
    print(f"Temps recherche lieu : {stats_recherche.get('temps_lieu', 0):.2f}s")
    print(f"Temps recherche titre : {stats_recherche.get('temps_titres', 0):.2f}s")
    print(f"Temps recherche sujet : {stats_recherche.get('temps_sujets', 0):.2f}s")
    print(f"Temps bloc recherche/filtre : {stats_recherche.get('temps_recherche_filtre', 0):.2f}s")
    print(f'Temps métadonnées : {temps_metadata:.2f}s')
    print(f'Temps Wikidata : {temps_wikidata:.2f}s')
    print(f'Temps DataFrame : {temps_dataframe:.2f}s')
    print(f'Durée totale : {duree:.2f}s')
    print(f'Soit : {duree / 60:.2f} min')
    print(f'Répartition raisons : {raisons_counts}')
    print(SEPARATEUR)
    return df
if __name__ == '__main__':
    df_dnb = recherche_DNB()
    liste_isbn_dnb = df_dnb['isbn_normalise'].dropna().drop_duplicates().tolist()