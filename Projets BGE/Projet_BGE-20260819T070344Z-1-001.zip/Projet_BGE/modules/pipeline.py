"""
Pipeline principal du projet BGE.

Étapes :
1. Recherche des PPN via Wikidata.
2. Construction de la liste globale GEN_AUT.
3. Recherche des sources par auteurs (NETWORK / SUDOC / DNB / BnF).
4. Recherches Genevensia (BnF / SUDOC / DNB / IdRef).
5. Fusion des sources.
6. Comparaison avec VGE et dédoublonnage final PPN + ISBN.
7. Ajout des dates de naissance / décès via IdRef.
8. Nettoyage final et sauvegarde du résultat.

Le pipeline exploite asyncio pour exécuter en parallèle les blocs
indépendants et conserve plusieurs DataFrames intermédiaires dans
le dictionnaire retourné pour faciliter le contrôle et le debug.
"""

import os
import asyncio
import pandas as pd
from ppn_wikidata import chercher_ppn_geneve
from ppn_gen_aut import construire_liste_ppn_complete
from sources import lancer_sources
from bnf import ajouter_isbn_bnf_ultra
from lieupublibnf import recherche_BNF
from lieupublisudoc import recherche_SUDOC
from lieupublidnb import recherche_DNB
from lieupubliidref import recherche_IDREF
from fusion import fusionner_sources
from comparaison_vge import isbn_absents_vge
from naissance_deces import ajouter_dates_auteurs
from nettoyage import nettoyage
DOSSIER_MODULES = os.path.dirname(os.path.abspath(__file__))
DOSSIER_PROJET = os.path.dirname(DOSSIER_MODULES)
DOSSIER_OUTPUT = os.path.join(DOSSIER_PROJET, 'output')
os.makedirs(DOSSIER_OUTPUT, exist_ok=True)

# ============================================================
# SAUVEGARDE
# Sauvegarde un DataFrame dans le dossier output du projet.
# ============================================================
def sauvegarder_dataframe(df, nom_fichier):
    """
    Sauvegarde un DataFrame dans le dossier output.
    """
    if df is None:
        return
    if not isinstance(df, pd.DataFrame):
        return
    chemin = os.path.join(DOSSIER_OUTPUT, nom_fichier)
    df.to_csv(chemin, index=False)

# ============================================================
# DÉDOUBLONNAGE FINAL
# - lignes sans PPN : toutes conservées ;
# - lignes avec PPN : une seule ligne par couple PPN + ISBN ;
# - priorité à la source NZ lorsqu'elle est disponible ;
# - sinon conservation de la première ligne rencontrée.
# ============================================================
def dedoublonner_ppn_isbn(df):
    """
    Déduplique le DataFrame selon les règles suivantes :

    - si le PPN est vide :
        toutes les lignes sont conservées

    - si le PPN est renseigné :
        une seule ligne est conservée pour un même couple
        ppn + isbn_normalise

    - si plusieurs lignes existent pour le même couple
      et qu'une ligne provient de NZ :
        la ligne NZ est prioritaire

    - sinon :
        la première ligne rencontrée est conservée
    """
    if df is None:
        return df
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f'Objet reçu invalide : {type(df)}')
    if df.empty:
        return df.copy()
    df = df.copy()
    colonnes_requises = ['ppn', 'isbn_normalise']
    colonnes_manquantes = [colonne for colonne in colonnes_requises if colonne not in df.columns]
    if colonnes_manquantes:
        raise ValueError(f'Colonnes manquantes pour le dédoublonnage : {colonnes_manquantes}')
    ppn_nettoye = df['ppn'].fillna('').astype(str).str.strip()
    masque_ppn_present = ppn_nettoye.ne('')
    df_sans_ppn = df.loc[~masque_ppn_present].copy()
    df_avec_ppn = df.loc[masque_ppn_present].copy()
    if df_avec_ppn.empty:
        return df_sans_ppn.reset_index(drop=True)
    if 'Source' in df_avec_ppn.columns:
        df_avec_ppn['_priorite_source'] = df_avec_ppn['Source'].fillna('').astype(str).str.strip().str.upper().ne('NZ').astype(int)
    else:
        df_avec_ppn['_priorite_source'] = 1
    df_avec_ppn['_ordre_initial'] = range(len(df_avec_ppn))
    df_avec_ppn = df_avec_ppn.sort_values(by=['ppn', 'isbn_normalise', '_priorite_source', '_ordre_initial'], na_position='last')
    df_avec_ppn = df_avec_ppn.drop_duplicates(subset=['ppn', 'isbn_normalise'], keep='first')
    df_avec_ppn = df_avec_ppn.drop(columns=['_priorite_source', '_ordre_initial'])
    df_final = pd.concat([df_avec_ppn, df_sans_ppn], ignore_index=True, sort=False)
    df_final = df_final.reset_index(drop=True)
    return df_final

# ============================================================
# PIPELINE PRINCIPAL
# Les blocs indépendants sont lancés en parallèle avec asyncio :
# - sources par auteurs ;
# - recherches Genevensia.
# ============================================================
async def lancer_pipeline(limite_sources=None):
    print()
    print('=' * 80)
    print('PIPELINE BGE')
    print('=' * 80)
    print()
    print('ÉTAPE 1/8 — WIKIDATA')
    print()
    df_wikidata = chercher_ppn_geneve()
    print()
    print('ÉTAPE 2/8 — GEN_AUT')
    print()
    df_ppn_global = construire_liste_ppn_complete(df_wikidata)
    # Mode normal : toutes les autorités sont utilisées.
    df_ppn_sources = df_ppn_global
    if limite_sources is not None:
        df_ppn_sources = df_ppn_global.head(limite_sources).copy()
        print()
        print(f'MODE TEST : {len(df_ppn_sources):,} auteurs utilisés pour les recherches par auteurs')
    print()
    print('ÉTAPE 3/8 — SOURCES PAR AUTEURS')
    print()
    print('Lancement parallèle : NETWORK / SUDOC / DNB / BNF')
    tache_autres_sources = asyncio.to_thread(lancer_sources, df_ppn_sources)
    tache_bnf_auteurs = asyncio.to_thread(ajouter_isbn_bnf_ultra, df_ppn_sources, 'bnf_id')
    # NETWORK/SUDOC/DNB et BnF auteurs sont exécutés simultanément.
    resultat_autres_sources, df_bnf_auteurs = await asyncio.gather(tache_autres_sources, tache_bnf_auteurs)
    resultats_sources, erreurs_sources = resultat_autres_sources
    resultats_sources['bnf'] = df_bnf_auteurs
    erreurs_bnf = df_bnf_auteurs.attrs.get('erreurs_bnf', [])
    erreurs_sources['bnf'] = erreurs_bnf
    print()
    print('Sauvegarde des sources par auteurs...')
    for nom, df_source in resultats_sources.items():
        if not isinstance(df_source, pd.DataFrame):
            continue
    if erreurs_bnf:
        df_erreurs_bnf = pd.DataFrame(erreurs_bnf)
    print()
    print('=' * 80)
    print('ÉTAPE 4/8 — RECHERCHES GENEVENSIA')
    print('=' * 80)
    print()
    print('Lancement parallèle : BNF / SUDOC / DNB / IDREF')
    tache_lieu_bnf = asyncio.to_thread(recherche_BNF)
    tache_lieu_sudoc = asyncio.to_thread(recherche_SUDOC)
    tache_lieu_dnb = asyncio.to_thread(recherche_DNB)
    tache_lieu_idref = recherche_IDREF()
    # Les quatre recherches Genevensia sont indépendantes et parallélisées.
    df_lieu_bnf, df_lieu_sudoc, df_lieu_dnb, df_lieu_idref = await asyncio.gather(tache_lieu_bnf, tache_lieu_sudoc, tache_lieu_dnb, tache_lieu_idref)
    resultats_lieu = {'bnf': df_lieu_bnf, 'idref': df_lieu_idref, 'sudoc': df_lieu_sudoc, 'dnb': df_lieu_dnb}
    print()
    print('Sauvegarde des recherches Genevensia...')
    for nom, df_source in resultats_lieu.items():
        if not isinstance(df_source, pd.DataFrame):
            continue
    print()
    print('=' * 70)
    print('RÉSUMÉ GENEVENSIA')
    print('=' * 70)
    for nom in ['bnf', 'idref', 'sudoc', 'dnb']:
        df_source = resultats_lieu.get(nom)
        if isinstance(df_source, pd.DataFrame) and (not df_source.empty):
            print(f'{nom.upper():<10} : {len(df_source):,} lignes')
        elif isinstance(df_source, pd.DataFrame):
            print(f'{nom.upper():<10} : 0 ligne')
        else:
            print(f'{nom.upper():<10} : ABSENT')
    print('=' * 70)
    print()
    print('ÉTAPE 5/8 — FUSION')
    print()
    df_final = fusionner_sources(resultats=resultats_sources, resultats_lieu=resultats_lieu)
    print()
    print('ÉTAPE 6/8 — COMPARAISON VGE')
    print()
    # Comparaison VGE avec les paramètres benchmarkés définis dans comparaison_vge.py.
    df_absents_vge = await isbn_absents_vge(df_final)
    nombre_avant_dedoublonnage = len(df_absents_vge)
    # Déduplication après VGE afin d'éviter les doublons inter-sources.
    df_absents_vge = dedoublonner_ppn_isbn(df_absents_vge)
    nombre_apres_dedoublonnage = len(df_absents_vge)
    print()
    print('=' * 70)
    print('DEDOUBLONNAGE FINAL')
    print('=' * 70)
    print(f'Lignes avant      : {nombre_avant_dedoublonnage:,}')
    print(f'Lignes après      : {nombre_apres_dedoublonnage:,}')
    print(f'Lignes supprimées : {nombre_avant_dedoublonnage - nombre_apres_dedoublonnage:,}')
    print('=' * 70)
    print()
    print('=' * 80)
    print('ÉTAPE 7/8 — DATES DE NAISSANCE / DECES')
    print('=' * 80)
    print()
    if 'ppn' in df_absents_vge.columns:
        nombre_ppn_dates = df_absents_vge['ppn'].dropna().astype(str).str.strip()
        nombre_ppn_dates = nombre_ppn_dates[nombre_ppn_dates.ne('')].nunique()
    else:
        nombre_ppn_dates = 0
    print(f"PPN uniques susceptibles d'être interrogés : {nombre_ppn_dates:,}")
    print()
    # Enrichissement uniquement sur les PPN encore présents après filtrage VGE.
    df_avec_dates = ajouter_dates_auteurs(df_absents_vge, taille_lot=100, timeout=30, afficher_progression=True)
    nombre_naissances = 0
    nombre_deces = 0
    if 'date_naissance' in df_avec_dates.columns:
        nombre_naissances = df_avec_dates['date_naissance'].notna().sum()
    if 'date_deces' in df_avec_dates.columns:
        nombre_deces = df_avec_dates['date_deces'].notna().sum()
    print()
    print('=' * 70)
    print('DATES AUTEURS IDREF')
    print('=' * 70)
    print(f'Naissances renseignées : {nombre_naissances:,}')
    print(f'Décès renseignés       : {nombre_deces:,}')
    print('=' * 70)
    print()
    print('=' * 80)
    print('ÉTAPE 8/8 — NETTOYAGE FINAL')
    print('=' * 80)
    print()
    # Dernière étape : harmonisation des colonnes et sauvegarde du fichier final.
    df_resultat_final = nettoyage(df_avec_dates, DOSSIER_OUTPUT)
    print()
    print('=' * 80)
    print('PIPELINE TERMINÉ')
    print('=' * 80)
    print(f'PPN Wikidata              : {len(df_wikidata):,}')
    print(f'PPN globaux               : {len(df_ppn_global):,}')
    print(f'BNF auteurs — lignes      : {len(df_bnf_auteurs):,}')
    if 'isbn_normalise' in df_bnf_auteurs.columns:
        print(f"BNF auteurs — ISBN uniques: {df_bnf_auteurs['isbn_normalise'].nunique():,}")
    elif 'isbn' in df_bnf_auteurs.columns:
        print(f"BNF auteurs — ISBN uniques: {df_bnf_auteurs['isbn'].nunique():,}")
    print(f'BNF auteurs — erreurs     : {len(erreurs_bnf):,}')
    print()
    print('Genevensia :')
    for nom, df_source in resultats_lieu.items():
        if isinstance(df_source, pd.DataFrame):
            print(f'  {nom.upper():<8} : {len(df_source):,} lignes')
    print()
    print(f'Lignes fusionnées         : {len(df_final):,}')
    if 'isbn_normalise' in df_final.columns:
        print(f"ISBN fusionnés uniques    : {df_final['isbn_normalise'].nunique():,}")
    print(f'Lignes absentes VGE       : {len(df_absents_vge):,}')
    if 'isbn_normalise' in df_absents_vge.columns:
        print(f"ISBN absents uniques      : {df_absents_vge['isbn_normalise'].nunique():,}")
    print(f'Dates naissance trouvées  : {nombre_naissances:,}')
    print(f'Dates décès trouvées      : {nombre_deces:,}')
    print(f'Lignes résultat final     : {len(df_resultat_final):,}')
    if 'isbn_normalise' in df_resultat_final.columns:
        print(f"ISBN finaux uniques       : {df_resultat_final['isbn_normalise'].nunique():,}")
    if 'date_naissance' in df_resultat_final.columns:
        print(f"Naissances résultat final : {df_resultat_final['date_naissance'].notna().sum():,}")
    else:
        print('ATTENTION : colonne date_naissance absente du résultat final.')
    if 'date_deces' in df_resultat_final.columns:
        print(f"Décès résultat final      : {df_resultat_final['date_deces'].notna().sum():,}")
    else:
        print('ATTENTION : colonne date_deces absente du résultat final.')
    print()
    print(f"Fichier final             : {os.path.join(DOSSIER_OUTPUT, 'resultat_final.csv')}")
    print('=' * 80)
    return {'wikidata': df_wikidata, 'ppn_global': df_ppn_global, 'sources': resultats_sources, 'erreurs_sources': erreurs_sources, 'bnf': df_bnf_auteurs, 'erreurs_bnf': erreurs_bnf, 'sources_lieu': resultats_lieu, 'lieu_bnf': df_lieu_bnf, 'lieu_idref': df_lieu_idref, 'lieu_sudoc': df_lieu_sudoc, 'lieu_dnb': df_lieu_dnb, 'final': df_final, 'absents_vge': df_absents_vge, 'absents_vge_avec_dates': df_avec_dates, 'resultat_final': df_resultat_final}