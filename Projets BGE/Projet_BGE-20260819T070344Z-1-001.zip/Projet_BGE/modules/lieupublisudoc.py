from lxml import etree
import pandas as pd
import re
import threading
import time
from pathlib import Path

from concurrent.futures import ThreadPoolExecutor, as_completed
from config import FICHIER_COMMUNES, FICHIER_TITRES
from utils import (
    charger_liste,
    concat_unique,
    normaliser_texte,
    normaliser_ppn,
    creer_session_http,
    obtenir_session_thread,
    afficher_section,
)


# ============================================================
# CONFIGURATION
# ============================================================

SRU_URL = "https://www.sudoc.abes.fr/cbs/sru/"

NS = {
    "srw": "http://www.loc.gov/zing/srw/"
}

HEADERS = {
    "Accept": "application/xml",
    "User-Agent": "Mozilla/5.0"
}

MAX_RECORDS = 1000
MAX_WORKERS = 10
TIMEOUT = 90
MAX_RETRIES = 5

ANNEE_REGEX = re.compile(
    r"(?<!\d)(1[0-9]{3}|20[0-9]{2}|21[0-9]{2})(?!\d)"
)

TAGS_PUBLICATION = ("210", "214")

TAGS_TITRES = (
    "200",
    "423", "424", "425",
    "430", "431", "432", "433", "434", "435", "436", "437",
    "440", "441", "442", "443", "444", "445", "446", "447",
    "451", "452", "453", "454", "455", "456",
    "461", "462", "463", "464", "470", "481", "482", "488",
    "500", "501", "503",
    "510", "511", "512", "513", "514", "515", "516", "517", "518",
    "520", "530", "531", "532", "540", "541", "545",
)

CODES_TITRES = ("a", "e", "h", "i", "t")
CODES_TITRE_PRINCIPAL = ("a", "e", "h", "i")

PARAMS_SRU = {
    "version": "1.1",
    "operation": "searchRetrieve",
    "recordSchema": "unimarc",
    "recordPacking": "xml",
}

COLONNES_FINALES = [
    "ppn",
    "isbn_normalise",
    "titre",
    "annee",
    "nomAuteur",
    "lieuPublication",
    "editeur",
    "sujet",
    "raisons",
]


# ============================================================
# LISTES DE RECHERCHE
# ============================================================

LISTE_COMMUNE = charger_liste(FICHIER_COMMUNES)
LISTE_TITRE = charger_liste(FICHIER_TITRES)


# ============================================================
# SESSION HTTP PAR THREAD
# ============================================================

thread_local = threading.local()


def creer_session():
    return creer_session_http(
        retries=MAX_RETRIES,
        backoff=0.7,
        methods=["GET"],
        pool_size=MAX_WORKERS,
        headers=HEADERS,
    )


def get_session():
    return obtenir_session_thread(thread_local,creer_session)

# ============================================================
# MOTS-CLÉS
# ============================================================

def construire_variantes():
    """
    Recherche SRU large :
    union de LISTE_COMMUNE et LISTE_TITRE,
    sans doublons.
    """

    return sorted(
        set(LISTE_COMMUNE) | set(LISTE_TITRE),
        key=lambda x: normaliser_texte(x)
    )


VARIANTES = construire_variantes()


# ============================================================
# LISTES NORMALISÉES + REGEX PRÉCOMPILÉES
# ============================================================

LISTE_COMMUNE_NORMALISEE = sorted(
    {
        normaliser_texte(x)
        for x in LISTE_COMMUNE
        if x
    },
    key=len,
    reverse=True
)


LISTE_TITRE_NORMALISEE = sorted(
    {
        normaliser_texte(x)
        for x in LISTE_TITRE
        if x
    },
    key=len,
    reverse=True
)


def construire_regex_termes(termes):
    """
    Construit une seule regex précompilée pour toute une liste.

    Les bornes empêchent par exemple un terme court
    de correspondre à l'intérieur d'un autre mot.
    """

    if not termes:
        return None

    return re.compile(
        "|".join(
            rf"(?<![a-z]){re.escape(terme)}(?![a-z])"
            for terme in termes
        ),
        re.IGNORECASE
    )


REGEX_COMMUNES = construire_regex_termes(
    LISTE_COMMUNE_NORMALISEE
)

REGEX_TITRES = construire_regex_termes(
    LISTE_TITRE_NORMALISEE
)


def contient_commune(texte):
    """
    Détection réservée au lieu de publication.
    """

    if not texte or REGEX_COMMUNES is None:
        return False

    return bool(
        REGEX_COMMUNES.search(
            normaliser_texte(texte)
        )
    )


def contient_terme_titre(texte):
    """
    Détection utilisée pour les titres et les sujets.
    """

    if not texte or REGEX_TITRES is None:
        return False

    return bool(
        REGEX_TITRES.search(
            normaliser_texte(texte)
        )
    )


# ============================================================
# ISBN
# ============================================================

def normaliser_isbn(isbn):

    if isbn is None:
        return None

    isbn = re.sub(
        r"[^0-9X]",
        "",
        str(isbn).upper().strip()
    )

    # ISBN-13 déjà valide en longueur
    if len(isbn) == 13 and isbn.isdigit():
        return isbn

    # ISBN-10 -> conversion ISBN-13
    if len(isbn) == 10:

        if not isbn[:9].isdigit():
            return None

        if not (
            isbn[-1].isdigit()
            or isbn[-1] == "X"
        ):
            return None

        base = "978" + isbn[:9]

        somme = sum(
            int(chiffre) * (
                1 if position % 2 == 0 else 3
            )
            for position, chiffre in enumerate(base)
        )

        cle = (10 - (somme % 10)) % 10

        return base + str(cle)

    return None


# ============================================================
# OUTILS
# ============================================================


def datafields(record):
    return record.xpath("./*[local-name()='datafield']")


def controlfield(record, tag):
    valeurs = record.xpath(
        f"./*[local-name()='controlfield'][@tag='{tag}']/text()"
    )
    return valeurs[0].strip() if valeurs else None


def sous_champs(record, tags, codes):
    tags, codes = {str(x) for x in tags}, set(codes)

    return [
        valeur
        for champ in datafields(record)
        if champ.get("tag") in tags
        for sous in champ.xpath("./*[local-name()='subfield']")
        if sous.get("code") in codes and sous.text
        if (valeur := sous.text.strip())
    ]


# ============================================================
# PPN NOTICE SUDOC
# ============================================================

def extraire_ppn_notice_sudoc(record):
    return controlfield(record, "001")


# ============================================================
# EXTRACTION DES AUTEURS
# ============================================================

def extraire_auteurs_structures(record):
    auteurs = []

    for champ in datafields(record):
        if champ.get("tag") not in {"700", "701", "702"}:
            continue

        sous_champs_dict = {}

        for sous in champ.xpath("./*[local-name()='subfield']"):
            if sous.text and (valeur := sous.text.strip()):
                sous_champs_dict.setdefault(
                    sous.get("code"),
                    []
                ).append(valeur)

        ppn = next(
            (
                ppn
                for valeur in sous_champs_dict.get("3", [])
                if (ppn := normaliser_ppn(valeur))
            ),
            None
        )

        def joindre(code):
            return " ".join(
                sous_champs_dict.get(code, [])
            ).strip()

        nom = joindre("a")
        prenom = joindre("b")
        qualificatif = joindre("c")
        numerotation = joindre("d")
        date = joindre("f")
        developpement = joindre("g")

        nom_complet = (
            f"{nom}, {prenom}"
            if nom and prenom
            else nom or prenom
        )

        for valeur in (developpement, numerotation):
            if valeur:
                nom_complet = f"{nom_complet} {valeur}".strip()

        for valeur in (qualificatif, date):
            if valeur:
                nom_complet = (
                    f"{nom_complet} ({valeur})"
                    if nom_complet
                    else valeur
                )

        nom_complet = re.sub(
            r"\s+",
            " ",
            nom_complet
        ).strip()

        if nom_complet:
            auteurs.append({
                "ppn": ppn,
                "nom": nom_complet
            })

    return list({
        (auteur["ppn"], auteur["nom"]): auteur
        for auteur in auteurs
    }.values())

    # --------------------------------------------------------
    # DOUBLONS
    # --------------------------------------------------------

    resultat = []
    vus = set()

    for auteur in auteurs:

        cle = (
            auteur["ppn"],
            auteur["nom"]
        )

        if cle in vus:
            continue

        vus.add(cle)

        resultat.append(
            auteur
        )

    return resultat


def extraire_ppn_idref_auteurs(record):
    return list(dict.fromkeys(
        auteur["ppn"]
        for auteur in extraire_auteurs_structures(record)
        if auteur["ppn"]
    ))


def extraire_auteurs(record):
    return " | ".join(dict.fromkeys(
        auteur["nom"]
        for auteur in extraire_auteurs_structures(record)
        if auteur["nom"]
    ))


# ============================================================
# ISBN
# ============================================================

def extraire_isbn(record):
    return sorted({
        isbn
        for valeur in sous_champs(record, ["010"], ["a"])
        if (isbn := normaliser_isbn(valeur))
    })


# ============================================================
# TITRE
# ============================================================

def extraire_titre(record):
    return concat_unique(
        sous_champs(record, ["200"], CODES_TITRE_PRINCIPAL),
        trier=False
    )


def extraire_textes_titre(record):
    return sous_champs(record, TAGS_TITRES, CODES_TITRES)


# ============================================================
# PUBLICATION
# ============================================================

def extraire_lieux_publication(record):
    return sous_champs(record, TAGS_PUBLICATION, ["a"])


def extraire_editeurs(record):
    return concat_unique(
        sous_champs(record, TAGS_PUBLICATION, ["c"]),
        trier=False
    )


# ============================================================
# ANNEE
# ============================================================

def extraire_annee(record):
    for tags, codes in (
        (TAGS_PUBLICATION, ["d"]),
        (["100"], ["a"]),
    ):
        for valeur in sous_champs(record, tags, codes):
            if match := ANNEE_REGEX.search(str(valeur)):
                return match.group(1)

    return None


# ============================================================
# SUJETS
# ============================================================

def extraire_textes_sujets(record):
    return [
        valeur
        for champ in datafields(record)
        if (
            (tag := champ.get("tag", "")).isdigit()
            and 600 <= int(tag) <= 609
        )
        for sous in champ.xpath("./*[local-name()='subfield']")
        if sous.get("code") not in {"2", "3"} and sous.text
        if (valeur := sous.text.strip())
    ]


def extraire_sujets(record):
    return concat_unique(
        extraire_textes_sujets(record),
        trier=False
    )


# ============================================================
# RAISONS
# ============================================================

def detecter_raisons(record):
    tests = (
        ("titre", extraire_textes_titre, contient_terme_titre),
        ("lieu_publication", extraire_lieux_publication, contient_commune),
        ("sujet", extraire_textes_sujets, contient_terme_titre),
    )

    return [
        raison
        for raison, extraire, tester in tests
        if any(tester(x) for x in extraire(record))
    ]


# ============================================================
# ANALYSE D'UNE NOTICE
# ============================================================

def analyser_record(record):
    ppn_notice = extraire_ppn_notice_sudoc(record)
    if not ppn_notice:
        return None

    isbn = extraire_isbn(record)
    if not isbn:
        return None

    raisons = detecter_raisons(record)
    if not raisons:
        return None

    auteurs = extraire_auteurs_structures(record)

    return {
        "ppn_notice_sudoc": ppn_notice,
        "ppn": list(dict.fromkeys(
            a["ppn"] for a in auteurs if a["ppn"]
        )),
        "isbn": isbn,
        "titre": extraire_titre(record),
        "annee": extraire_annee(record),
        "nomAuteur": " | ".join(dict.fromkeys(
            a["nom"] for a in auteurs if a["nom"]
        )),
        "lieuPublication": concat_unique(
            extraire_lieux_publication(record),
            trier=False
        ),
        "editeur": extraire_editeurs(record),
        "sujet": extraire_sujets(record),
        "raisons": set(raisons),
    }


# ============================================================
# REQUETE SRU
# ============================================================

def requete_sru(query, start_record=1):
    response = get_session().get(
        SRU_URL,
        params={
            **PARAMS_SRU,
            "query": query,
            "startRecord": start_record,
            "maximumRecords": MAX_RECORDS,
        },
        timeout=TIMEOUT,
    )

    response.raise_for_status()
    return etree.fromstring(response.content)


def nombre_resultats(root):
    try:
        return int(root.xpath(
            "string(.//srw:numberOfRecords)",
            namespaces=NS
        ))
    except Exception:
        return 0


def records_unimarc(root):
    return root.xpath(
        ".//srw:recordData/*[local-name()='record']",
        namespaces=NS
    )


# ============================================================
# CONSTRUCTION REQUETE
# ============================================================

def construire_requete(mot_cle):
    mot = str(mot_cle).strip()

    if " " in mot:
        mot = '"' + mot.replace('"', '\\"') + '"'

    return f"tou={mot}"

# ============================================================
# FUSION NOTICE
# ============================================================

def fusionner_notice(notices, notice):
    if notice is None:
        return

    ppn_notice = notice["ppn_notice_sudoc"]

    if ppn_notice not in notices:
        notices[ppn_notice] = notice
        return

    existante = notices[ppn_notice]

    # Raisons
    existante["raisons"].update(notice["raisons"])

    # Listes : PPN IdRef + ISBN
    for cle in ("ppn", "isbn"):
        existante[cle] = list(dict.fromkeys(
            existante.get(cle, [])
            + notice.get(cle, [])
        ))

    # Auteurs
    auteurs = (
        existante.get("nomAuteur", "").split("|")
        + notice.get("nomAuteur", "").split("|")
    )

    existante["nomAuteur"] = " | ".join(dict.fromkeys(
        auteur.strip()
        for auteur in auteurs
        if auteur.strip()
    ))


# ============================================================
# RECHERCHE SUDOC OPTIMISÉE
# ============================================================

def analyser_page(root, notices):
    for record in records_unimarc(root):
        fusionner_notice(
            notices,
            analyser_record(record))
        

def rechercher_geneve_sudoc():
    debut = time.perf_counter()

    afficher_section("RECHERCHE SUDOC - VERSION OPTIMISEE")

    print(f"Mots-clés totaux : {len(VARIANTES)}")
    print(f"Communes : {len(LISTE_COMMUNE)}")
    print(f"Termes titre/sujet : {len(LISTE_TITRE)}")
    print(f"Workers : {MAX_WORKERS}")
    print(f"Notices par page : {MAX_RECORDS}")
    print("ISBN normalisés : ISBN-13 uniquement")
    print("PPN : identifiants IdRef des auteurs\n")

    requetes = {
        mot_cle: construire_requete(mot_cle)
        for mot_cle in VARIANTES
    }

    totaux = {}
    premieres_pages = {}

    # ========================================================
    # PHASE 1 : PREMIERE PAGE DE CHAQUE REQUETE
    # ========================================================

    print("Phase 1/2 - premières pages...")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(requete_sru, query, 1): mot_cle
            for mot_cle, query in requetes.items()
        }

        for future in as_completed(futures):
            mot_cle = futures[future]

            try:
                root = future.result()
                total = nombre_resultats(root)

                totaux[mot_cle] = total
                premieres_pages[mot_cle] = root

                print(f"✓ {mot_cle:<25} : {total:,}")

            except Exception as erreur:
                totaux[mot_cle] = 0

                print(
                    f"✗ {mot_cle:<25} : "
                    f"{type(erreur).__name__} - {erreur}"
                )

    # ========================================================
    # ANALYSE PREMIERES PAGES
    # ========================================================

    notices = {}

    for root in premieres_pages.values():
        analyser_page(root, notices)

    premieres_pages.clear()

    # ========================================================
    # PHASE 2 : PAGES SUPPLEMENTAIRES
    # ========================================================

    taches = [
        (mot_cle, requetes[mot_cle], start_record)
        for mot_cle, total in totaux.items()
        for start_record in range(
            MAX_RECORDS + 1,
            total + 1,
            MAX_RECORDS
        )
    ]

    total_pages = len(taches)

    print(
        f"\nPhase 2/2 - pages supplémentaires : "
        f"{total_pages:,}"
    )

    if total_pages:
        erreurs = 0

        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = {
                executor.submit(
                    requete_sru,
                    query,
                    start_record
                ): (mot_cle, start_record)
                for mot_cle, query, start_record in taches
            }

            for terminees, future in enumerate(
                as_completed(futures),
                1
            ):
                mot_cle, start_record = futures[future]

                try:
                    analyser_page(
                        future.result(),
                        notices
                    )

                except Exception as erreur:
                    erreurs += 1

                    print(
                        f"\n✗ {mot_cle} "
                        f"startRecord={start_record} : "
                        f"{type(erreur).__name__} - {erreur}"
                    )

                if terminees % 10 == 0 or terminees == total_pages:
                    print(
                        f"\rPages terminées : "
                        f"{terminees:,}/{total_pages:,} "
                        f"({terminees / total_pages * 100:.1f} %) "
                        f"| notices utiles uniques : {len(notices):,} "
                        f"| erreurs : {erreurs}",
                        end=""
                    )

        print()

    duree = time.perf_counter() - debut

    print(
        f"\nRecherche terminée en {duree:.1f}s "
        f"({duree / 60:.1f} min)"
    )
    print(f"Notices utiles uniques : {len(notices):,}")

    return notices

    # ========================================================
    # FIN
    # ========================================================

    duree = (
        time.perf_counter()
        -
        debut
    )

    print()

    print(
        f"Recherche terminée en "
        f"{duree:.1f}s "
        f"({duree / 60:.1f} min)"
    )

    print(
        f"Notices utiles uniques : "
        f"{len(notices):,}"
    )

    return notices


# ============================================================
# DATAFRAME FINAL
#
# IMPORTANT :
# UNE SEULE VALEUR DE PPN PAR LIGNE
# ============================================================

def notices_vers_dataframe(notices):
    lignes = []

    for notice in notices.values():
        raisons = " | ".join(sorted(notice["raisons"]))

        ppns = list(dict.fromkeys(
            str(ppn).strip()
            for ppn in notice.get("ppn", [])
            if ppn is not None and str(ppn).strip()
        ))

        isbns = list(dict.fromkeys(
            str(isbn).strip()
            for isbn in notice.get("isbn", [])
            if isbn is not None and str(isbn).strip()
        ))

        if not isbns:
            continue

        # Une notice sans PPN reste conservée avec ppn=None.
        ppns = ppns or [None]

        metadata = {
            "titre": notice.get("titre"),
            "annee": notice.get("annee"),
            "nomAuteur": notice.get("nomAuteur"),
            "lieuPublication": notice.get("lieuPublication"),
            "editeur": notice.get("editeur"),
            "sujet": notice.get("sujet"),
            "raisons": raisons,
        }

        lignes.extend(
            {
                "ppn": ppn,
                "isbn_normalise": isbn,
                **metadata,
            }
            for ppn in ppns
            for isbn in isbns
        )

    if not lignes:
        return pd.DataFrame(columns=COLONNES_FINALES)

    df = pd.DataFrame(
        lignes,
        columns=COLONNES_FINALES
    ).drop_duplicates()

    df["annee"] = pd.to_numeric(
        df["annee"],
        errors="coerce"
    ).astype("Int64")

    return (
        df.sort_values(
            ["ppn", "isbn_normalise", "titre"],
            na_position="last"
        )
        .reset_index(drop=True)
    )


# ============================================================
# FONCTION PUBLIQUE POUR LE PIPELINE
# ============================================================

def recherche_SUDOC():
    """Recherche Genevensia SUDOC et retourne le DataFrame final."""

    debut = time.perf_counter()

    print(
        f"\n{'=' * 70}\n"
        "RECHERCHE GENEVENSIA — SUDOC\n"
        f"{'=' * 70}"
    )

    df = notices_vers_dataframe(
        rechercher_geneve_sudoc()
    )

    duree = time.perf_counter() - debut

    print(
        f"\n{'=' * 70}\n"
        "RÉSULTATS SUDOC GENEVENSIA\n"
        f"{'=' * 70}"
    )
    print(f"Lignes finales : {len(df):,}")

    if not df.empty:
        print(
            f"ISBN-13 uniques : "
            f"{df['isbn_normalise'].nunique():,}"
        )

        ppn = (
            df["ppn"]
            .dropna()
            .astype(str)
            .str.strip()
        )
        print(
            f"PPN IdRef auteurs uniques : "
            f"{ppn[ppn.ne('')].nunique():,}"
        )

        print("\nRépartition des critères :")

        for raison in (
            "titre",
            "lieu_publication",
            "sujet",
        ):
            nombre = (
                df["raisons"]
                .astype("string")
                .str.contains(
                    raison,
                    regex=False,
                    na=False
                )
                .sum()
            )

            print(f"  {raison:<20} : {nombre:,}")

    print(
        f"\nDurée totale : {duree:.1f} secondes\n"
        f"Soit : {duree / 60:.1f} minutes\n"
        f"{'=' * 70}"
    )

    return df