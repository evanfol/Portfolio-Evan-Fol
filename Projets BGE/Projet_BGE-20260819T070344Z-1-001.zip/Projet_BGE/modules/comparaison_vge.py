"""
Module de comparaison VGE optimisé.

Pipeline principal :
1. Normalisation des ISBN et génération des formes ISBN-13 / ISBN-10.
2. Lecture de table_finale.xlsx et de l'historique Acquisition_non.csv.
3. Mise à jour de l'historique des acquisitions refusées.
4. Double filtrage de sécurité pour empêcher toute réintroduction d'un ISBN interdit.
5. Recherche asynchrone des ISBN dans Swisscovery VGE via SRU.
6. Retour des lignes dont l'ISBN est absent de VGE.

Règles importantes :
- les ISBN-10 valides sont convertis en ISBN-13 ;
- les ISBN 978 peuvent être recherchés sous leur forme 13 et 10 ;
- les ISBN 979 n'ont pas d'équivalent ISBN-10 ;
- Acquisition_non.csv agit comme liste d'exclusion persistante ;
- une sécurité finale vérifie qu'aucun ISBN interdit ne sort de la fonction.
"""

import asyncio
import re
import xml.etree.ElementTree as ET
from pathlib import Path
import aiohttp
import pandas as pd
from tqdm.auto import tqdm
DOSSIER_MODULE = Path(__file__).resolve().parent
DOSSIER_PROJET = DOSSIER_MODULE.parent
DOSSIER_OUTPUT = DOSSIER_PROJET / 'output'
CHEMIN_TABLE_FINALE = DOSSIER_PROJET / 'table_finale.xlsx'
CHEMIN_ACQUISITION_NON = DOSSIER_OUTPUT / 'Acquisition_non.csv'

# ============================================================
# OUTILS DE COLONNES
# Recherche insensible à la casse et aux espaces périphériques.
# ============================================================
def trouver_colonne(df, nom):
    """
    Recherche une colonne sans tenir compte :
    - des majuscules/minuscules
    - des espaces avant/après
    """
    nom_recherche = str(nom).strip().lower()
    for colonne in df.columns:
        nom_colonne = str(colonne).strip().lower()
        if nom_colonne == nom_recherche:
            return colonne
    return None

# ============================================================
# ISBN
# Validation ISBN-10 / ISBN-13 et conversions dans les deux sens.
# Le format de travail interne reste l'ISBN-13 normalisé.
# ============================================================
def isbn10_valide(isbn10):
    if isbn10 is None:
        return False
    isbn10 = str(isbn10).upper().strip()
    if len(isbn10) != 10:
        return False
    if not re.fullmatch('\\d{9}[\\dX]', isbn10):
        return False
    total = 0
    for i, caractere in enumerate(isbn10):
        if caractere == 'X':
            valeur = 10
        else:
            valeur = int(caractere)
        poids = 10 - i
        total += valeur * poids
    return total % 11 == 0

def isbn13_valide(isbn13):
    if isbn13 is None:
        return False
    isbn13 = str(isbn13).strip()
    if len(isbn13) != 13:
        return False
    if not isbn13.isdigit():
        return False
    total = 0
    for i, caractere in enumerate(isbn13[:12]):
        chiffre = int(caractere)
        if i % 2 == 0:
            total += chiffre
        else:
            total += chiffre * 3
    check = (10 - total % 10) % 10
    return check == int(isbn13[-1])

def isbn10_vers_13(isbn10):
    if not isbn10_valide(isbn10):
        return None
    isbn10 = str(isbn10).upper().strip()
    base = '978' + isbn10[:9]
    total = 0
    for i, caractere in enumerate(base):
        chiffre = int(caractere)
        if i % 2 == 0:
            total += chiffre
        else:
            total += chiffre * 3
    check = (10 - total % 10) % 10
    return base + str(check)

# Normalise toute valeur vers un ISBN-13 valide.
# Les caractères de ponctuation sont supprimés et les ISBN-10 valides
# sont automatiquement convertis.
def normaliser_isbn(value):
    """
    Retourne systématiquement :

        ISBN-13 valide

    ou :

        None

    Les ISBN-10 valides sont convertis en ISBN-13.
    """
    if pd.isna(value):
        return None
    texte = str(value).upper().strip()
    if not texte:
        return None
    isbn = re.sub('[^0-9X]', '', texte)
    if len(isbn) == 10:
        return isbn10_vers_13(isbn)
    if len(isbn) == 13:
        if isbn13_valide(isbn):
            return isbn
        return None
    return None

# Conversion ISBN-13 -> ISBN-10 uniquement pour les préfixes 978.
# Les ISBN 979 ne possèdent pas d'équivalent ISBN-10.
def isbn13_vers_10(isbn13):
    """
    Convertit un ISBN-13 commençant par 978
    en ISBN-10.

    ISBN 979 :
        aucun ISBN-10 équivalent.
    """
    isbn13 = normaliser_isbn(isbn13)
    if isbn13 is None:
        return None
    if not isbn13.startswith('978'):
        return None
    base = isbn13[3:12]
    total = 0
    for i, caractere in enumerate(base):
        chiffre = int(caractere)
        poids = 10 - i
        total += chiffre * poids
    cle = (11 - total % 11) % 11
    if cle == 10:
        caractere_cle = 'X'
    else:
        caractere_cle = str(cle)
    isbn10 = base + caractere_cle
    if not isbn10_valide(isbn10):
        return None
    return isbn10

# Formes utilisées pour interroger VGE :
# - ISBN 978 : ISBN-13 + ISBN-10 ;
# - ISBN 979 : ISBN-13 uniquement.
def formes_recherche_isbn(value):
    """
    ISBN 978 :
        ISBN-13 + ISBN-10

    ISBN 979 :
        ISBN-13 uniquement
    """
    isbn13 = normaliser_isbn(value)
    if isbn13 is None:
        return set()
    formes = {isbn13}
    isbn10 = isbn13_vers_10(isbn13)
    if isbn10:
        formes.add(isbn10)
    return formes

def normaliser_colonne_isbn(df, colonne):
    return df[colonne].map(normaliser_isbn).astype('string')

# ============================================================
# ACQUISITION_NON — SOURCES
# Lecture des lignes Acquisition='Non' depuis table_finale.xlsx.
# Seuls les ISBN valides et uniques sont conservés.
# ============================================================
def charger_acquisitions_non_table_finale():
    """
    Charge table_finale.xlsx et retourne uniquement
    les lignes Acquisition = Non avec ISBN valide.
    """
    if not CHEMIN_TABLE_FINALE.exists():
        raise FileNotFoundError(f'\nFichier introuvable :\n{CHEMIN_TABLE_FINALE}')
    df = pd.read_excel(CHEMIN_TABLE_FINALE, dtype='string')
    df.columns = df.columns.astype(str).str.strip()
    colonne_acquisition = trouver_colonne(df, 'Acquisition')
    colonne_isbn = trouver_colonne(df, 'isbn_normalise')
    if colonne_acquisition is None:
        raise ValueError(f"La colonne 'Acquisition' est absente de table_finale.xlsx.\nColonnes disponibles : {df.columns.tolist()}")
    if colonne_isbn is None:
        raise ValueError("La colonne 'isbn_normalise' est absente de table_finale.xlsx.")
    acquisition = df[colonne_acquisition].astype('string').str.strip().str.lower()
    masque_non = acquisition.eq('non').fillna(False)
    df_non = df.loc[masque_non].copy().reset_index(drop=True)
    if df_non.empty:
        return df_non
    if colonne_isbn != 'isbn_normalise':
        df_non = df_non.rename(columns={colonne_isbn: 'isbn_normalise'})
    df_non['isbn_normalise'] = normaliser_colonne_isbn(df_non, 'isbn_normalise')
    df_non = df_non.dropna(subset=['isbn_normalise']).drop_duplicates(subset=['isbn_normalise'], keep='first').reset_index(drop=True)
    return df_non

# Lecture de l'historique persistant output/Acquisition_non.csv.
# Un fichier absent équivaut simplement à un historique vide.
def charger_historique_acquisition_non():
    if not CHEMIN_ACQUISITION_NON.exists():
        return pd.DataFrame()
    df = pd.read_csv(CHEMIN_ACQUISITION_NON, dtype='string')
    if df.empty:
        return df
    colonne_isbn = trouver_colonne(df, 'isbn_normalise')
    if colonne_isbn is None:
        raise ValueError('Acquisition_non.csv existe mais ne contient pas la colonne isbn_normalise.')
    if colonne_isbn != 'isbn_normalise':
        df = df.rename(columns={colonne_isbn: 'isbn_normalise'})
    df['isbn_normalise'] = normaliser_colonne_isbn(df, 'isbn_normalise')
    df = df.dropna(subset=['isbn_normalise']).drop_duplicates(subset=['isbn_normalise'], keep='first').reset_index(drop=True)
    return df

# Retourne l'ensemble des ISBN actuellement interdits à partir
# de l'historique Acquisition_non.csv.
def recuperer_isbn_interdits():
    """
    Retourne un set contenant tous les ISBN normalisés
    présents dans Acquisition_non.csv.
    """
    df_non = charger_historique_acquisition_non()
    if df_non.empty:
        return set()
    return set(df_non['isbn_normalise'].map(normaliser_isbn).dropna())

# ============================================================
# PREMIER FILTRE ACQUISITION_NON
# Fusionne l'historique existant, les refus de table_finale.xlsx et
# les éventuels refus présents dans le DataFrame courant.
# L'historique est sauvegardé puis les correspondances directes sur
# isbn_normalise sont retirées avant toute requête VGE.
# ============================================================
def filtrer_et_mettre_a_jour_acquisition_non(df):
    """
    1. Lit table_finale.xlsx
    2. récupère Acquisition = Non
    3. complète Acquisition_non.csv
    4. évite les doublons ISBN
    5. supprime les correspondances directes sur
       isbn_normalise

    IMPORTANT :
    un deuxième contrôle sera effectué ensuite sur
    l'ISBN EFFECTIF utilisé par VGE afin d'empêcher
    le fallback "isbn" de réintroduire ces ISBN.
    """
    if df is None:
        raise ValueError('Le DataFrame fourni est None.')
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f'Objet reçu invalide : {type(df)}')
    df = df.copy()
    colonne_isbn_df = trouver_colonne(df, 'isbn_normalise')
    if colonne_isbn_df is None:
        raise ValueError('La colonne isbn_normalise est absente du DataFrame à comparer à VGE.')
    df_non_excel = charger_acquisitions_non_table_finale()
    df_historique = charger_historique_acquisition_non()
    nb_historique_avant = len(df_historique)
    colonne_acquisition_df = trouver_colonne(df, 'Acquisition')
    if colonne_acquisition_df is not None:
        acquisition_df = df[colonne_acquisition_df].astype('string').str.strip().str.lower()
        masque_non_df = acquisition_df.eq('non').fillna(False)
        df_non_courant = df.loc[masque_non_df].copy().reset_index(drop=True)
        df = df.loc[~masque_non_df].copy().reset_index(drop=True)
        if not df_non_courant.empty:
            df_non_courant['isbn_normalise'] = df_non_courant[colonne_isbn_df].map(normaliser_isbn).astype('string')
            df_non_courant = df_non_courant.dropna(subset=['isbn_normalise']).drop_duplicates(subset=['isbn_normalise'], keep='first').reset_index(drop=True)
    else:
        df_non_courant = pd.DataFrame()
    morceaux = []
    if not df_historique.empty:
        morceaux.append(df_historique)
    if not df_non_excel.empty:
        morceaux.append(df_non_excel)
    if not df_non_courant.empty:
        morceaux.append(df_non_courant)
    if morceaux:
        df_historique_final = pd.concat(morceaux, ignore_index=True, sort=False)
        df_historique_final['isbn_normalise'] = df_historique_final['isbn_normalise'].map(normaliser_isbn).astype('string')
        df_historique_final = df_historique_final.dropna(subset=['isbn_normalise']).drop_duplicates(subset=['isbn_normalise'], keep='first').reset_index(drop=True)
    else:
        df_historique_final = pd.DataFrame(columns=['isbn_normalise'])
    isbn_avant = set()
    if not df_historique.empty and 'isbn_normalise' in df_historique.columns:
        isbn_avant = set(df_historique['isbn_normalise'].dropna().tolist())
    isbn_apres = set(df_historique_final['isbn_normalise'].dropna().tolist())
    nouveaux_isbn = isbn_apres - isbn_avant
    DOSSIER_OUTPUT.mkdir(parents=True, exist_ok=True)
    df_historique_final.to_csv(CHEMIN_ACQUISITION_NON, index=False, encoding='utf-8-sig')
    isbn_courants = df[colonne_isbn_df].map(normaliser_isbn)
    masque_interdit = isbn_courants.isin(isbn_apres)
    nb_avant_filtre = len(df)
    nb_lignes_supprimees = int(masque_interdit.sum())
    nb_isbn_supprimes = isbn_courants.loc[masque_interdit].nunique()
    df = df.loc[~masque_interdit].copy().reset_index(drop=True)
    print()
    print('=' * 70)
    print('FILTRE ACQUISITIONS AVANT VGE')
    print('=' * 70)
    print(f'Acquisition = Non dans table_finale : {len(df_non_excel):,}')
    print(f'Acquisition = Non dans DF courant   : {len(df_non_courant):,}')
    print(f'ISBN historiques avant              : {nb_historique_avant:,}')
    print(f'Nouveaux ISBN ajoutés               : {len(nouveaux_isbn):,}')
    print(f'ISBN total Acquisition_non.csv      : {len(isbn_apres):,}')
    print(f'Lignes avant filtre ISBN            : {nb_avant_filtre:,}')
    print(f'Lignes supprimées par historique    : {nb_lignes_supprimees:,}')
    print(f'ISBN uniques supprimés              : {nb_isbn_supprimes:,}')
    print(f'Lignes après premier filtre         : {len(df):,}')
    print(f'Historique                          : {CHEMIN_ACQUISITION_NON}')
    print('=' * 70)
    return df

# ISBN effectif utilisé par VGE :
# priorité à isbn_normalise puis fallback sur isbn.
def construire_isbn_par_ligne(df):
    """
    Priorité :

    1. isbn_normalise
    2. isbn

    Retourne une Series d'ISBN-13 normalisés.
    """
    isbn_par_ligne = pd.Series(None, index=df.index, dtype='object')
    if 'isbn_normalise' in df.columns:
        isbn_par_ligne = df['isbn_normalise'].map(normaliser_isbn)
    if 'isbn' in df.columns:
        isbn_depuis_isbn = df['isbn'].map(normaliser_isbn)
        isbn_par_ligne = isbn_par_ligne.fillna(isbn_depuis_isbn)
    return isbn_par_ligne

# ============================================================
# FILTRE DE SÉCURITÉ SUR L'ISBN EFFECTIF
# Empêche le fallback vers la colonne 'isbn' de réintroduire un ISBN
# déjà présent dans Acquisition_non.csv.
# Une intersection résiduelle déclenche une erreur explicite.
# ============================================================
def filtrer_isbn_effectif_interdit(df):
    """
    Corrige le bug identifié :

    après suppression sur isbn_normalise,
    une ligne pouvait être réintroduite parce que VGE
    utilisait ensuite la colonne "isbn" en fallback.

    Cette fonction travaille donc sur l'ISBN EFFECTIF
    réellement utilisé par VGE.
    """
    df = df.copy()
    isbn_interdits = recuperer_isbn_interdits()
    isbn_par_ligne = construire_isbn_par_ligne(df)
    masque_interdit = isbn_par_ligne.isin(isbn_interdits)
    nb_avant = len(df)
    nb_lignes = int(masque_interdit.sum())
    nb_isbn = isbn_par_ligne.loc[masque_interdit].nunique()
    print()
    print('=' * 70)
    print('FILTRE ISBN EFFECTIF — SÉCURITÉ FALLBACK')
    print('=' * 70)
    print(f'ISBN interdits                       : {len(isbn_interdits):,}')
    print(f'Lignes avant filtre effectif         : {nb_avant:,}')
    print(f'Lignes interdites détectées          : {nb_lignes:,}')
    print(f'ISBN interdits détectés              : {nb_isbn:,}')
    if nb_lignes and 'TypeRecherche' in df.columns:
        print()
        print('Lignes retirées par TypeRecherche :')
        print(df.loc[masque_interdit, 'TypeRecherche'].value_counts(dropna=False).to_string())
    df = df.loc[~masque_interdit].copy().reset_index(drop=True)
    isbn_par_ligne = construire_isbn_par_ligne(df)
    intersection = set(isbn_par_ligne.dropna()) & isbn_interdits
    print()
    print(f'Lignes réellement envoyables VGE     : {len(df):,}')
    print(f'Intersection après filtre             : {len(intersection):,}')
    print('=' * 70)
    if intersection:
        raise RuntimeError(f'ERREUR : {len(intersection):,} ISBN Acquisition_non seraient encore envoyés à VGE.')
    return (df, isbn_par_ligne)

# ============================================================
# COMPARAISON ASYNCHRONE AVEC SWISSCOVERY VGE
# Les ISBN sont envoyés par lots via SRU avec pagination, retries et
# limitation de concurrence. Seuls les ISBN réellement absents sont
# retournés.
# ============================================================
async def isbn_absents_vge(df, batch_size=175, max_concurrent=12, timeout=30, retries=3, page_size=50):
    BASE_URL = 'https://swisscovery.slsp.ch/view/sru/41SLSP_VGE'
    NS = {'srw': 'http://www.loc.gov/zing/srw/', 'marc': 'http://www.loc.gov/MARC21/slim'}
    if df is None:
        raise ValueError('Le DataFrame fourni est None.')
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f'Objet reçu invalide : {type(df)}')
    if df.empty:
        print('DataFrame vide : aucun ISBN à comparer.')
        return df.copy()
    # Premier filtre : exclusion directe sur isbn_normalise.
    df = filtrer_et_mettre_a_jour_acquisition_non(df)
    if df.empty:
        print('Toutes les lignes ont été exclues par Acquisition_non.')
        return df.copy()
    if 'isbn_normalise' not in df.columns and 'isbn' not in df.columns:
        raise ValueError('Aucune colonne ISBN utilisable.\nIl faut au moins isbn_normalise ou isbn.')
    # Deuxième filtre : contrôle de l'ISBN réellement utilisé par VGE.
    df, isbn_par_ligne = filtrer_isbn_effectif_interdit(df)
    if df.empty:
        print()
        print('=' * 70)
        print('COMPARAISON VGE')
        print('=' * 70)
        print('Aucune ligne restante après filtrage Acquisition_non.')
        print('Aucune requête VGE effectuée.')
        print('=' * 70)
        return df.copy()
    isbn_uniques = isbn_par_ligne.dropna().drop_duplicates().tolist()
    isbn_recherches = set(isbn_uniques)
    if not isbn_uniques:
        print()
        print('=' * 70)
        print('COMPARAISON VGE')
        print('=' * 70)
        print('Aucun ISBN valide à rechercher.')
        print('=' * 70)
        return df.iloc[0:0].copy()
    batches = [isbn_uniques[i:i + batch_size] for i in range(0, len(isbn_uniques), batch_size)]
    print()
    print('=' * 70)
    print('COMPARAISON AVEC VGE')
    print('=' * 70)
    print(f'Lignes reçues VGE    : {len(df):,}')
    print(f'ISBN uniques         : {len(isbn_uniques):,}')
    print(f'Taille des lots      : {batch_size}')
    print(f'Nombre de lots       : {len(batches):,}')
    print(f'Concurrence          : {max_concurrent}')
    print(f'Taille page SRU      : {page_size}')
    print()
    semaphore = asyncio.Semaphore(max_concurrent)
    connector = aiohttp.TCPConnector(limit=max_concurrent, limit_per_host=max_concurrent, ttl_dns_cache=600, enable_cleanup_closed=True)
    timeout_config = aiohttp.ClientTimeout(total=timeout, connect=10, sock_connect=10, sock_read=timeout)
    compteur_http = 0

    async def requete_sru(session, query, start_record):
        nonlocal compteur_http
        params = {'version': '1.2', 'operation': 'searchRetrieve', 'recordSchema': 'marcxml', 'query': query, 'startRecord': start_record, 'maximumRecords': page_size}
        for tentative in range(retries):
            try:
                async with semaphore:
                    compteur_http += 1
                    async with session.get(BASE_URL, params=params) as response:
                        if response.status == 200:
                            contenu = await response.read()
                            return ET.fromstring(contenu)
                        if response.status in {429, 500, 502, 503, 504}:
                            retry_after = response.headers.get('Retry-After')
                            if retry_after:
                                try:
                                    attente = float(retry_after)
                                except ValueError:
                                    attente = 0.5 * 2 ** tentative
                            else:
                                attente = 0.5 * 2 ** tentative
                            await asyncio.sleep(attente)
                            continue
                        return None
            except (aiohttp.ClientError, asyncio.TimeoutError, ET.ParseError):
                if tentative < retries - 1:
                    await asyncio.sleep(0.5 * 2 ** tentative)
        return None

    def extraire_isbn(root):
        presents = set()
        for subfield in root.findall(".//marc:datafield[@tag='020']/marc:subfield[@code='a']", NS):
            if not subfield.text:
                continue
            isbn = normaliser_isbn(subfield.text)
            if isbn:
                presents.add(isbn)
        return presents

    def lire_nombre_resultats(root):
        element = root.find('.//srw:numberOfRecords', NS)
        if element is None:
            return 0
        try:
            return int(element.text)
        except (TypeError, ValueError):
            return 0

    async def tester_batch(session, batch):
        termes_recherche = set()
        for isbn in batch:
            termes_recherche.update(formes_recherche_isbn(isbn))
        termes_recherche = sorted(termes_recherche)
        query = ' OR '.join((f'alma.isbn={isbn}' for isbn in termes_recherche))
        start_record = 1
        presents_batch = set()
        root = await requete_sru(session, query, start_record)
        if root is None:
            return (batch, None)
        nombre_total = lire_nombre_resultats(root)
        presents_batch.update(extraire_isbn(root))
        start_record += page_size
        while start_record <= nombre_total:
            root = await requete_sru(session, query, start_record)
            if root is None:
                return (batch, None)
            presents_batch.update(extraire_isbn(root))
            start_record += page_size
        presents_recherches_batch = set(batch) & presents_batch
        return (batch, presents_recherches_batch)
    presents_recherches = set()
    batches_erreur = []
    async with aiohttp.ClientSession(connector=connector, timeout=timeout_config) as session:
        tasks = [asyncio.create_task(tester_batch(session, batch)) for batch in batches]
        for task in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc='Vérification VGE', unit='lot'):
            batch, resultat = await task
            if resultat is None:
                batches_erreur.extend(batch)
            else:
                presents_recherches.update(resultat)
    erreur_set = set(batches_erreur)
    absents = isbn_recherches - presents_recherches - erreur_set
    masque_absent = isbn_par_ligne.isin(absents)
    df_absents = df.loc[masque_absent].copy().reset_index(drop=True)
    isbn_absents_normalises = isbn_par_ligne.loc[masque_absent].reset_index(drop=True)
    df_absents['isbn_normalise'] = isbn_absents_normalises.astype('string')
    # Sécurité finale absolue avant retour du DataFrame.
    isbn_interdits_final = recuperer_isbn_interdits()
    isbn_absents_final = df_absents['isbn_normalise'].map(normaliser_isbn)
    masque_interdit_final = isbn_absents_final.isin(isbn_interdits_final)
    nb_securite_finale = int(masque_interdit_final.sum())
    if nb_securite_finale:
        print()
        print(f'⚠ Sécurité finale : {nb_securite_finale:,} lignes Acquisition_non retirées.')
        df_absents = df_absents.loc[~masque_interdit_final].copy().reset_index(drop=True)
    intersection_finale = set(df_absents['isbn_normalise'].map(normaliser_isbn).dropna()) & isbn_interdits_final
    if intersection_finale:
        raise RuntimeError(f'ERREUR : {len(intersection_finale):,} ISBN Acquisition_non sont encore présents dans df_absents.')
    print()
    print('=' * 70)
    print('RÉSULTATS VGE')
    print('=' * 70)
    print(f'ISBN recherchés      : {len(isbn_recherches):,}')
    print(f'✓ ISBN présents      : {len(presents_recherches):,}')
    print(f'✗ ISBN absents       : {len(absents):,}')
    print(f'⚠ ISBN en erreur     : {len(erreur_set):,}')
    print(f'HTTP effectuées      : {compteur_http:,}')
    print(f'Lignes retournées    : {len(df_absents):,}')
    if 'isbn_normalise' in df_absents.columns:
        print(f"ISBN absents uniques : {df_absents['isbn_normalise'].nunique():,}")
    if 'Source' in df_absents.columns:
        print()
        print('Absents par source :')
        print(df_absents['Source'].value_counts(dropna=False).to_string())
    if 'TypeRecherche' in df_absents.columns:
        print()
        print('Absents par type de recherche :')
        print(df_absents['TypeRecherche'].value_counts(dropna=False).to_string())
    if 'Source' in df_absents.columns and 'TypeRecherche' in df_absents.columns:
        print()
        print('Absents par Source / Type :')
        print(df_absents.groupby(['Source', 'TypeRecherche'], dropna=False).size().sort_values(ascending=False).to_string())
    total_classe = len(presents_recherches) + len(absents) + len(erreur_set)
    print()
    print(f'Contrôle              : {total_classe:,} / {len(isbn_recherches):,} ISBN classés')
    print(f'Intersection Acquisition_non / absents_vge : {len(intersection_finale):,}')
    print('=' * 70)
    return df_absents