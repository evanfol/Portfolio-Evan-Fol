"""
Module Swisscovery NETWORK optimisé.

Pipeline principal :
1. Normalisation des PPN et des ISBN.
2. Interrogation SRU NETWORK des premières pages.
3. Construction de la liste des pages supplémentaires.
4. Récupération parallèle des pages suivantes.
5. Réparation ciblée des pages/PPN en erreur avec une session plus robuste.
6. Exclusion des ressources électroniques lorsque MARC21 338$b = "cr".
7. Dédoublonnage PPN + ISBN puis fusion avec le DataFrame source.

Principes de performance :
- maximumRecords=50, valeur validée par benchmark ;
- 55 workers sur les phases rapides ;
- 1 retry avec backoff court en fonctionnement normal ;
- faible concurrence et retries élevés uniquement pour la réparation ;
- sessions HTTP distinctes par thread et par mode fast/repair.
"""

import requests
import pandas as pd
import xml.etree.ElementTree as ET
import re
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
URL_NETWORK = 'https://swisscovery.slsp.ch/view/sru/41SLSP_NETWORK'
TAILLE_LOT = 50
WORKERS_PHASE1 = 55
WORKERS_PHASE2 = 55
FAST_RETRIES = 1
FAST_BACKOFF = 0.1
REPAIR_RETRIES = 5
REPAIR_BACKOFF = 0.5
REPAIR_WORKERS = 6
REPAIR_PASSES = 2
CONNECT_TIMEOUT = 10
READ_TIMEOUT = 45
NS = {'srw': 'http://www.loc.gov/zing/srw/', 'marc': 'http://www.loc.gov/MARC21/slim'}
PPN_NETTOYAGE_RE = re.compile('[^0-9X]')
EXCEL_DECIMAL_RE = re.compile('\\.0$')
PONCTUATION_RE = re.compile('\\s*[/:;,]\\s*$')
ISBN10_RE = re.compile('\\d{9}[\\dX]')
ISBN13_RE = re.compile('\\d{13}')
ISBN_DEBUT_RE = re.compile('^\\s*([0-9X][0-9X\\-\\s]{8,30})')
ISBN_NETTOYAGE_RE = re.compile('[^0-9X]')
ANNEE_RE = re.compile('\\b(1[0-9]{3}|20[0-9]{2}|21[0-9]{2})\\b')
thread_local = threading.local()

# ============================================================
# SESSIONS HTTP PAR THREAD
# Deux profils sont utilisés :
# - fast   : forte concurrence, peu de retries ;
# - repair : faible concurrence, retries plus élevés.
# ============================================================
def creer_session(retries, backoff, pool_size):
    session = requests.Session()
    retry = Retry(total=retries, connect=retries, read=retries, status=retries, backoff_factor=backoff, status_forcelist=[429, 500, 502, 503, 504], allowed_methods=['GET'], raise_on_status=False)
    adapter = HTTPAdapter(max_retries=retry, pool_connections=pool_size + 5, pool_maxsize=pool_size + 5, pool_block=False)
    session.mount('https://', adapter)
    session.headers.update({'User-Agent': 'Geneve-Bibliographic-Research-Swisscovery/6.0', 'Accept-Encoding': 'gzip, deflate'})
    return session

def obtenir_session_fast():
    if not hasattr(thread_local, 'session_fast'):
        thread_local.session_fast = creer_session(retries=FAST_RETRIES, backoff=FAST_BACKOFF, pool_size=max(WORKERS_PHASE1, WORKERS_PHASE2))
    return thread_local.session_fast

def obtenir_session_repair():
    if not hasattr(thread_local, 'session_repair'):
        thread_local.session_repair = creer_session(retries=REPAIR_RETRIES, backoff=REPAIR_BACKOFF, pool_size=REPAIR_WORKERS)
    return thread_local.session_repair

# ============================================================
# NORMALISATION PPN
# Nettoie les valeurs Excel, retire les caractères parasites et
# complète les PPN numériques courts avec des zéros à gauche.
# ============================================================
def normaliser_ppn(ppn):
    if pd.isna(ppn):
        return None
    ppn = str(ppn).strip().upper()
    ppn = EXCEL_DECIMAL_RE.sub('', ppn)
    ppn = PPN_NETTOYAGE_RE.sub('', ppn)
    if not ppn:
        return None
    if ppn.isdigit() and len(ppn) < 9:
        ppn = ppn.zfill(9)
    return ppn

# ============================================================
# OUTILS XML MARC21
# Accès simple aux sous-champs via les namespaces SRU/MARC.
# ============================================================
def sous_champ(champ, code):
    if champ is None:
        return None
    element = champ.find(f"marc:subfield[@code='{code}']", NS)
    if element is not None and element.text:
        return element.text.strip()
    return None

def sous_champs(champ, code):
    if champ is None:
        return []
    return [element.text.strip() for element in champ.findall(f"marc:subfield[@code='{code}']", NS) if element.text]

# ============================================================
# NETTOYAGE TEXTE
# Retire notamment la ponctuation terminale bibliographique.
# ============================================================
def nettoyer_texte(texte):
    if texte is None:
        return None
    texte = str(texte).strip()
    texte = PONCTUATION_RE.sub('', texte)
    texte = texte.strip()
    return texte or None

# ============================================================
# ISBN
# Validation ISBN-10 / ISBN-13 et conversion systématique des ISBN-10
# valides vers ISBN-13 pour harmoniser les comparaisons.
# ============================================================
def isbn10_valide(isbn):
    if not ISBN10_RE.fullmatch(isbn):
        return False
    total = 0
    for i, caractere in enumerate(isbn):
        valeur = 10 if caractere == 'X' else int(caractere)
        total += (10 - i) * valeur
    return total % 11 == 0

def isbn13_valide(isbn):
    if not ISBN13_RE.fullmatch(isbn):
        return False
    somme = 0
    for i, chiffre in enumerate(isbn[:12]):
        n = int(chiffre)
        somme += n if i % 2 == 0 else n * 3
    cle = (10 - somme % 10) % 10
    return cle == int(isbn[-1])

def isbn10_vers_13(isbn10):
    base = '978' + isbn10[:9]
    somme = 0
    for i, chiffre in enumerate(base):
        n = int(chiffre)
        somme += n if i % 2 == 0 else n * 3
    cle = (10 - somme % 10) % 10
    return base + str(cle)

def normaliser_isbn(valeur):
    if valeur is None:
        return None
    texte = str(valeur).upper().strip()
    match = ISBN_DEBUT_RE.match(texte)
    if match:
        texte = match.group(1)
    isbn = ISBN_NETTOYAGE_RE.sub('', texte)
    if len(isbn) == 13:
        if isbn13_valide(isbn):
            return isbn
        return None
    if len(isbn) == 10:
        if not isbn10_valide(isbn):
            return None
        isbn13 = isbn10_vers_13(isbn)
        if isbn13_valide(isbn13):
            return isbn13
    return None

def extraire_annee(valeurs):
    for valeur in valeurs:
        if not valeur:
            continue
        match = ANNEE_RE.search(str(valeur))
        if match:
            return int(match.group(1))
    return None

# ============================================================
# EXTRACTION D'UNE NOTICE MARC
# Une notice 338$b='cr' est exclue entièrement.
# Sans ISBN valide, le reste de la notice n'est pas parsé.
# Une ligne est ensuite produite par ISBN normalisé.
# ============================================================
def extraire_notice(record, ppn):
    for champ338 in record.findall("marc:datafield[@tag='338']", NS):
        for code_support in sous_champs(champ338, 'b'):
            if code_support.strip().lower() == 'cr':
                return []
    isbn_valides = []
    for champ in record.findall("marc:datafield[@tag='020']", NS):
        for valeur in sous_champs(champ, 'a'):
            isbn = normaliser_isbn(valeur)
            if isbn:
                isbn_valides.append(isbn)
    if not isbn_valides:
        return []
    isbn_valides = list(dict.fromkeys(isbn_valides))
    champ100 = record.find("marc:datafield[@tag='100']", NS)
    auteur = nettoyer_texte(sous_champ(champ100, 'a'))
    if not auteur:
        champ700 = record.find("marc:datafield[@tag='700']", NS)
        auteur = nettoyer_texte(sous_champ(champ700, 'a'))
    champ245 = record.find("marc:datafield[@tag='245']", NS)
    titre = nettoyer_texte(sous_champ(champ245, 'a'))
    sous_titre = nettoyer_texte(sous_champ(champ245, 'b'))
    if titre and sous_titre:
        titre_complet = f'{titre} : {sous_titre}'
    else:
        titre_complet = titre or sous_titre
    champs_publication = record.findall("marc:datafield[@tag='264']", NS)
    if not champs_publication:
        champs_publication = record.findall("marc:datafield[@tag='260']", NS)
    lieux = []
    editeurs = []
    annees = []
    for champ in champs_publication:
        lieux.extend(sous_champs(champ, 'a'))
        editeurs.extend(sous_champs(champ, 'b'))
        annees.extend(sous_champs(champ, 'c'))
    lieux_nettoyes = [valeur_nettoyee for valeur in lieux if (valeur_nettoyee := nettoyer_texte(valeur))]
    editeurs_nettoyes = [valeur_nettoyee for valeur in editeurs if (valeur_nettoyee := nettoyer_texte(valeur))]
    lieux_nettoyes = list(dict.fromkeys(lieux_nettoyes))
    editeurs_nettoyes = list(dict.fromkeys(editeurs_nettoyes))
    lieu_publication = ' - '.join(lieux_nettoyes) if lieux_nettoyes else None
    editeur = ' - '.join(editeurs_nettoyes) if editeurs_nettoyes else None
    annee = extraire_annee(annees)
    return [{'_ppn_requete': ppn, 'isbn_normalise': isbn, 'titre': titre_complet, 'annee': annee, 'nomAuteur': auteur, 'lieuPublication': lieu_publication, 'editeur': editeur} for isbn in isbn_valides]

# ============================================================
# REQUÊTE SRU NETWORK
# mode='fast' utilise la session rapide ; mode='repair' la session
# robuste réservée aux erreurs résiduelles.
# ============================================================
def recuperer_page_network(ppn, start_record, mode='fast'):
    if mode == 'repair':
        session = obtenir_session_repair()
    else:
        session = obtenir_session_fast()
    response = session.get(URL_NETWORK, params={'version': '1.2', 'operation': 'searchRetrieve', 'recordSchema': 'marcxml', 'query': f'alma.authority_id={ppn}', 'startRecord': start_record, 'maximumRecords': TAILLE_LOT}, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
    response.raise_for_status()
    return response.content

# Parse une page SRU et extrait toutes les notices MARC exploitables.
def parser_page(xml_bytes, ppn):
    root = ET.fromstring(xml_bytes)
    records = root.findall('.//srw:recordData/marc:record', NS)
    lignes = []
    extend = lignes.extend
    for record in records:
        extend(extraire_notice(record, ppn))
    return (root, lignes, len(records))

# Première page d'un PPN : récupère également numberOfRecords afin
# de déterminer s'il faut programmer des pages supplémentaires.
def traiter_premiere_page(ppn, mode='fast'):
    xml_bytes = recuperer_page_network(ppn, 1, mode=mode)
    root, lignes, nb_records = parser_page(xml_bytes, ppn)
    total_element = root.find('.//srw:numberOfRecords', NS)
    if total_element is None or not total_element.text:
        total = 0
    else:
        total = int(total_element.text)
    return {'ppn': ppn, 'total': total, 'records': nb_records, 'lignes': lignes}

# Récupération d'une page supplémentaire d'un PPN.
def traiter_page_suivante(ppn, start_record, mode='fast'):
    xml_bytes = recuperer_page_network(ppn, start_record, mode=mode)
    _, lignes, nb_records = parser_page(xml_bytes, ppn)
    return {'ppn': ppn, 'start': start_record, 'records': nb_records, 'lignes': lignes}

# ============================================================
# RÉPARATION DES PAGES EN ÉCHEC
# Plusieurs passes sont effectuées avec faible concurrence et retries
# élevés. Seules les pages encore en erreur sont retentées.
# ============================================================
def reparer_pages(pages_erreur, resultats):
    erreurs_restantes = list(pages_erreur)
    for passage in range(1, REPAIR_PASSES + 1):
        if not erreurs_restantes:
            break
        print()
        print(f'Réparation pages {passage}/{REPAIR_PASSES} : {len(erreurs_restantes):,}')
        nouvelles_erreurs = []
        with ThreadPoolExecutor(max_workers=REPAIR_WORKERS) as executor:
            futures = {executor.submit(traiter_page_suivante, ppn, start, 'repair'): (ppn, start) for ppn, start in erreurs_restantes}
            for future in as_completed(futures):
                ppn, start = futures[future]
                try:
                    resultat = future.result()
                    if resultat['lignes']:
                        resultats.extend(resultat['lignes'])
                except Exception:
                    nouvelles_erreurs.append((ppn, start))
        erreurs_restantes = nouvelles_erreurs
    return erreurs_restantes

# ============================================================
# FONCTION PRINCIPALE DE PRODUCTION
# Phase 1 : premières pages de tous les PPN.
# Phase 2 : pages supplémentaires.
# Phase 3 : réparation ciblée puis construction du DataFrame final.
# ============================================================
def ajouter_isbn_network_ultra(df, colonne_ppn='ppn', workers_phase1=WORKERS_PHASE1, workers_phase2=WORKERS_PHASE2):
    debut_total = time.perf_counter()
    if colonne_ppn not in df.columns:
        raise ValueError(f"La colonne '{colonne_ppn}' n'existe pas.")
    # Travail sur une copie afin de préserver le DataFrame d'entrée.
    source = df.copy()
    colonnes_swisscovery = ['isbn_normalise', 'titre', 'annee', 'nomAuteur', 'lieuPublication', 'editeur']
    source.drop(columns=[col for col in colonnes_swisscovery if col in source.columns], errors='ignore', inplace=True)
    colonnes_originales = list(source.columns)
    # Colonne technique normalisée utilisée pour les requêtes et le merge.
    source['_ppn_requete'] = source[colonne_ppn].map(normaliser_ppn)
    liste_ppn = source['_ppn_requete'].dropna().drop_duplicates().tolist()
    total_ppn = len(liste_ppn)
    print()
    print('#' * 80)
    print('SWISSCOVERY NETWORK — VERSION FINALE OPTIMISÉE')
    print('#' * 80)
    print()
    print(f'PPN uniques         : {total_ppn:,}')
    print(f'Workers phase 1     : {workers_phase1}')
    print(f'Workers phase 2     : {workers_phase2}')
    print(f'maximumRecords      : {TAILLE_LOT}')
    print(f'Retries rapides     : {FAST_RETRIES}')
    print(f'Backoff rapide      : {FAST_BACKOFF}')
    print()
    resultats = []
    erreurs_ppn = []
    pages_suivantes = []
    pages_erreur = []
    total_notices_annoncees = 0
    total_records_recus = 0
    print('=' * 80)
    print('1/3 — PREMIÈRES PAGES')
    print('=' * 80)
    debut_phase1 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=workers_phase1) as executor:
        futures = {executor.submit(traiter_premiere_page, ppn, 'fast'): ppn for ppn in liste_ppn}
        termines = 0
        for future in as_completed(futures):
            termines += 1
            ppn = futures[future]
            try:
                resultat = future.result()
                total = resultat['total']
                total_notices_annoncees += total
                total_records_recus += resultat['records']
                if resultat['lignes']:
                    resultats.extend(resultat['lignes'])
                if total > TAILLE_LOT:
                    pages_suivantes.extend(((ppn, start) for start in range(TAILLE_LOT + 1, total + 1, TAILLE_LOT)))
            except Exception:
                erreurs_ppn.append(ppn)
            if termines % 250 == 0 or termines == total_ppn:
                print(f'{termines:>6}/{total_ppn} PPN | notices annoncées : {total_notices_annoncees:,} | pages suivantes : {len(pages_suivantes):,} | erreurs : {len(erreurs_ppn):,}')
    duree_phase1 = time.perf_counter() - debut_phase1
    print()
    print('=' * 80)
    print('2/3 — PAGES SUIVANTES')
    print('=' * 80)
    print(f'Pages à récupérer : {len(pages_suivantes):,}')
    debut_phase2 = time.perf_counter()
    nb_pages = len(pages_suivantes)
    if pages_suivantes:
        with ThreadPoolExecutor(max_workers=workers_phase2) as executor:
            futures = {executor.submit(traiter_page_suivante, ppn, start, 'fast'): (ppn, start) for ppn, start in pages_suivantes}
            termines = 0
            for future in as_completed(futures):
                termines += 1
                ppn, start = futures[future]
                try:
                    resultat = future.result()
                    total_records_recus += resultat['records']
                    if resultat['lignes']:
                        resultats.extend(resultat['lignes'])
                except Exception:
                    pages_erreur.append((ppn, start))
                if termines % 250 == 0 or termines == nb_pages:
                    print(f'{termines:>6}/{nb_pages} pages | résultats ISBN : {len(resultats):,} | erreurs pages : {len(pages_erreur):,}')
    duree_phase2 = time.perf_counter() - debut_phase2
    debut_reparation = time.perf_counter()
    # Réparation ciblée uniquement si des pages ont réellement échoué.
    if pages_erreur:
        pages_erreur = reparer_pages(pages_erreur, resultats)
    if erreurs_ppn:
        print()
        print(f'Réparation de {len(erreurs_ppn):,} premières pages...')
        erreurs_finales_ppn = []
        with ThreadPoolExecutor(max_workers=REPAIR_WORKERS) as executor:
            futures = {executor.submit(traiter_premiere_page, ppn, 'repair'): ppn for ppn in erreurs_ppn}
            for future in as_completed(futures):
                ppn = futures[future]
                try:
                    resultat = future.result()
                    if resultat['lignes']:
                        resultats.extend(resultat['lignes'])
                    total = resultat['total']
                    if total > TAILLE_LOT:
                        pages_reparation = [(ppn, start) for start in range(TAILLE_LOT + 1, total + 1, TAILLE_LOT)]
                        pages_restantes = reparer_pages(pages_reparation, resultats)
                        if pages_restantes:
                            erreurs_finales_ppn.append(ppn)
                except Exception:
                    erreurs_finales_ppn.append(ppn)
        erreurs_ppn = list(dict.fromkeys(erreurs_finales_ppn))
    duree_reparation = time.perf_counter() - debut_reparation
    print()
    print('=' * 80)
    print('3/3 — DATAFRAME')
    print('=' * 80)
    debut_dataframe = time.perf_counter()
    if not resultats:
        resultat_final = pd.DataFrame(columns=colonnes_originales + colonnes_swisscovery)
        resultat_final.attrs['ppn_erreurs'] = erreurs_ppn
        resultat_final.attrs['pages_erreurs'] = pages_erreur
        resultat_final.attrs['duree_phase1'] = duree_phase1
        resultat_final.attrs['duree_phase2'] = duree_phase2
        resultat_final.attrs['duree_reparation'] = duree_reparation
        resultat_final.attrs['duree_totale'] = time.perf_counter() - debut_total
        return resultat_final
    df_isbn = pd.DataFrame.from_records(resultats)
    df_isbn.drop_duplicates(subset=['_ppn_requete', 'isbn_normalise'], keep='first', inplace=True)
    resultat_final = source.merge(df_isbn, on='_ppn_requete', how='inner', sort=False, copy=False)
    resultat_final.drop(columns=['_ppn_requete'], inplace=True)
    resultat_final = resultat_final[colonnes_originales + colonnes_swisscovery]
    resultat_final[colonne_ppn] = resultat_final[colonne_ppn].astype('string')
    resultat_final['isbn_normalise'] = resultat_final['isbn_normalise'].astype('string')
    resultat_final['annee'] = pd.to_numeric(resultat_final['annee'], errors='coerce').astype('Int64')
    resultat_final.reset_index(drop=True, inplace=True)
    duree_dataframe = time.perf_counter() - debut_dataframe
    duree_totale = time.perf_counter() - debut_total
    resultat_final.attrs['ppn_erreurs'] = erreurs_ppn
    resultat_final.attrs['pages_erreurs'] = pages_erreur
    resultat_final.attrs['duree_phase1'] = duree_phase1
    resultat_final.attrs['duree_phase2'] = duree_phase2
    resultat_final.attrs['duree_reparation'] = duree_reparation
    resultat_final.attrs['duree_totale'] = duree_totale
    print()
    print('#' * 80)
    print('TERMINÉ')
    print('#' * 80)
    print()
    print(f'Premières pages      : {duree_phase1:.1f} s')
    print(f'Pages suivantes      : {duree_phase2:.1f} s')
    print(f'Réparation           : {duree_reparation:.1f} s')
    print(f'DataFrame            : {duree_dataframe:.1f} s')
    print()
    print(f'DURÉE TOTALE         : {duree_totale:.1f} s ({duree_totale / 60:.2f} min)')
    print()
    print(f'PPN interrogés       : {total_ppn:,}')
    print(f'Notices annoncées    : {total_notices_annoncees:,}')
    print(f'Records reçus        : {total_records_recus:,}')
    print(f'Pages supplémentaires: {len(pages_suivantes):,}')
    print()
    print(f'PPN avec ISBN        : {resultat_final[colonne_ppn].nunique():,}')
    print(f"ISBN uniques         : {resultat_final['isbn_normalise'].nunique():,}")
    print(f'Lignes finales       : {len(resultat_final):,}')
    print()
    print(f'PPN en erreur        : {len(erreurs_ppn):,}')
    print(f'Pages en erreur      : {len(pages_erreur):,}')
    print('#' * 80)
    return resultat_final