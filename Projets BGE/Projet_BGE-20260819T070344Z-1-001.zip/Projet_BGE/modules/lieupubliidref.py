import asyncio
import aiohttp
import pandas as pd
import re
import time
import json
from pathlib import Path
from lxml import etree
from config import FICHIER_COMMUNES, FICHIER_TITRES
from utils import charger_liste, concat_unique, creer_lots, normaliser_texte, normaliser_isbn, nom_local_xml
IDREF_SOLR_URL = 'https://www.idref.fr/Sru/Solr'
SPARQL_URL = 'https://data.idref.fr/sparql'
SUDOC_URL = 'https://www.sudoc.fr'
LISTE_COMMUNE = charger_liste(FICHIER_COMMUNES)
LISTE_TITRE = charger_liste(FICHIER_TITRES)
MAX_CONCURRENT_IDREF = 10
SOLR_ROWS = 1000
SPARQL_BATCH_SIZE = 200
MAX_CONCURRENT_SPARQL = 4
MAX_CONCURRENT_SUDOC = 40
TIMEOUT_TOTAL = 60
TIMEOUT_CONNECT = 15
MAX_RETRIES = 5
BACKOFF_BASE = 0.5
HEADERS = {'User-Agent': 'Mozilla/5.0 (compatible; bibliographic-data-analysis/2.0)', 'Accept': '*/*'}

def construire_variantes():
    return sorted(set(LISTE_COMMUNE) | set(LISTE_TITRE), key=lambda x: normaliser_texte(x))
VARIANTES = construire_variantes()
LISTE_COMMUNE_NORMALISEE = sorted({normaliser_texte(x) for x in LISTE_COMMUNE if x}, key=len, reverse=True)
LISTE_TITRE_NORMALISEE = sorted({normaliser_texte(x) for x in LISTE_TITRE if x}, key=len, reverse=True)
REGEX_COMMUNES = re.compile('|'.join((f'(?<![a-z]){re.escape(terme)}(?![a-z])' for terme in LISTE_COMMUNE_NORMALISEE)), re.IGNORECASE)
REGEX_TITRES = re.compile('|'.join((f'(?<![a-z]){re.escape(terme)}(?![a-z])' for terme in LISTE_TITRE_NORMALISEE)), re.IGNORECASE)

def contient_commune(texte):
    if not texte:
        return False
    return bool(REGEX_COMMUNES.search(normaliser_texte(texte)))

def contient_terme_titre(texte):
    if not texte:
        return False
    return bool(REGEX_TITRES.search(normaliser_texte(texte)))
PPN_REGEX = re.compile('(?<![0-9A-Z])([0-9]{8}[0-9X])(?![0-9A-Z])', re.IGNORECASE)
ANNEE_REGEX = re.compile('(?<!\\d)(1[0-9]{3}|20[0-9]{2})(?!\\d)')

def extraire_ppn_uri(uri):
    if not uri:
        return None
    match = re.search('(?:idref|sudoc)\\.fr/([0-9]{8}[0-9X])', str(uri), flags=re.IGNORECASE)
    return match.group(1).upper() if match else None

def extraire_annee(texte):
    if not texte:
        return None
    match = ANNEE_REGEX.search(str(texte))
    if not match:
        return None
    return int(match.group(1))

async def requete_http(session, url, *, params=None, data=None, semaphore=None, accepter_404=False):
    if semaphore is None:
        semaphore = asyncio.Semaphore(100)
    async with semaphore:
        for tentative in range(1, MAX_RETRIES + 1):
            try:
                if data is None:
                    contexte = session.get(url, params=params)
                else:
                    contexte = session.post(url, data=data)
                async with contexte as response:
                    if accepter_404 and response.status == 404:
                        return None
                    if response.status in {429, 500, 502, 503, 504}:
                        if tentative == MAX_RETRIES:
                            response.raise_for_status()
                        retry_after = response.headers.get('Retry-After')
                        try:
                            attente = float(retry_after) if retry_after else BACKOFF_BASE * 2 ** (tentative - 1)
                        except ValueError:
                            attente = BACKOFF_BASE * 2 ** (tentative - 1)
                        await asyncio.sleep(attente)
                        continue
                    response.raise_for_status()
                    return await response.read()
            except (aiohttp.ClientError, asyncio.TimeoutError):
                if tentative == MAX_RETRIES:
                    raise
                await asyncio.sleep(BACKOFF_BASE * 2 ** (tentative - 1))
    return None

async def rechercher_idref_mot(session, semaphore, mot_cle):
    mot = str(mot_cle).strip()
    start = 0
    lignes = []
    while True:
        params = {'q': f'all:"{mot}"', 'wt': 'json', 'fl': 'ppn_z,recordtype_z,affcourt_z', 'start': start, 'rows': SOLR_ROWS, 'version': '2.2'}
        contenu = await requete_http(session, IDREF_SOLR_URL, params=params, semaphore=semaphore)
        if not contenu:
            break
        data = json.loads(contenu)
        bloc = data.get('response', {})
        docs = bloc.get('docs', [])
        total = bloc.get('numFound', 0)
        if not docs:
            break
        for doc in docs:
            ppn = doc.get('ppn_z')
            if not ppn:
                continue
            lignes.append({'mot_cle': mot_cle, 'ppn': str(ppn), 'recordtype': doc.get('recordtype_z'), 'libelle': doc.get('affcourt_z')})
        start += len(docs)
        if start >= total:
            break
    return (mot_cle, lignes)

async def rechercher_idref_large(session):
    debut = time.perf_counter()
    print()
    print('=' * 70)
    print('1/4 - RECHERCHE LARGE IDREF')
    print('=' * 70)
    semaphore = asyncio.Semaphore(MAX_CONCURRENT_IDREF)
    taches = [rechercher_idref_mot(session, semaphore, mot) for mot in VARIANTES]
    toutes_lignes = []
    for future in asyncio.as_completed(taches):
        try:
            mot, lignes = await future
            toutes_lignes.extend(lignes)
            print(f'✓ {mot:<15} : {len(lignes):,}')
        except Exception as erreur:
            print(f'✗ Erreur IdRef : {erreur}')
    if not toutes_lignes:
        return pd.DataFrame(columns=['mot_cle', 'ppn', 'recordtype', 'libelle'])
    df = pd.DataFrame(toutes_lignes).drop_duplicates(subset=['ppn', 'mot_cle']).reset_index(drop=True)
    print()
    print(f"PPN IdRef uniques : {df['ppn'].nunique():,}")
    print(f'Durée IdRef : {time.perf_counter() - debut:.1f}s')
    return df

async def sparql_lot_auteurs(session, semaphore, lot_ppn):
    values = '\n'.join((f'<http://www.idref.fr/{ppn}/id>' for ppn in lot_ppn))
    query = f'\nPREFIX dc: <http://purl.org/dc/elements/1.1/>\nPREFIX dcterms: <http://purl.org/dc/terms/>\n\nSELECT DISTINCT\n    ?auteur\n    ?doc\n    ?relation\n    ?citation\n    ?date\nWHERE\n{{\n    VALUES ?auteur {{\n        {values}\n    }}\n\n    ?doc ?relation ?auteur .\n\n    FILTER(\n        STRSTARTS(\n            STR(?doc),\n            "http://www.sudoc.fr/"\n        )\n    )\n\n    OPTIONAL {{\n        ?doc dcterms:bibliographicCitation ?citation .\n    }}\n\n    OPTIONAL {{\n        ?doc dc:date ?date .\n    }}\n}}\n'
    contenu = await requete_http(session, SPARQL_URL, data={'query': query, 'format': 'application/sparql-results+json'}, semaphore=semaphore)
    if not contenu:
        return []
    data = json.loads(contenu)
    bindings = data.get('results', {}).get('bindings', [])
    lignes = []
    for ligne in bindings:
        auteur_uri = ligne.get('auteur', {}).get('value')
        doc_uri = ligne.get('doc', {}).get('value')
        relation = ligne.get('relation', {}).get('value')
        citation = ligne.get('citation', {}).get('value')
        date_rdf = ligne.get('date', {}).get('value')
        ppn_auteur_source = extraire_ppn_uri(auteur_uri)
        ppn_document = extraire_ppn_uri(doc_uri)
        if not ppn_document:
            continue
        lignes.append({'ppn_auteur_source': ppn_auteur_source, 'ppn_document': ppn_document, 'relation': relation, 'citation': citation, 'date_rdf': date_rdf, 'annee_rdf': extraire_annee(date_rdf)})
    return lignes

async def recuperer_documents_sparql(session, df_idref):
    debut = time.perf_counter()
    print()
    print('=' * 70)
    print('2/4 - DOCUMENTS SUDOC VIA SPARQL')
    print('=' * 70)
    auteurs = df_idref['ppn'].dropna().astype(str).drop_duplicates().tolist()
    if not auteurs:
        return pd.DataFrame(columns=['ppn_auteur_source', 'ppn_document', 'relation', 'citation', 'date_rdf', 'annee_rdf'])
    lots = list(creer_lots(auteurs, SPARQL_BATCH_SIZE))
    print(f'Autorités : {len(auteurs):,}')
    print(f'Lots SPARQL : {len(lots):,} (taille={SPARQL_BATCH_SIZE})')
    semaphore = asyncio.Semaphore(MAX_CONCURRENT_SPARQL)
    taches = [sparql_lot_auteurs(session, semaphore, lot) for lot in lots]
    toutes_lignes = []
    termines = 0
    for future in asyncio.as_completed(taches):
        try:
            lignes = await future
            toutes_lignes.extend(lignes)
        except Exception as erreur:
            print(f'\n✗ Erreur SPARQL : {erreur}')
        termines += 1
        print(f'\rLots : {termines:,}/{len(lots):,} | liens : {len(toutes_lignes):,}', end='')
    print()
    if not toutes_lignes:
        return pd.DataFrame(columns=['ppn_auteur_source', 'ppn_document', 'relation', 'citation', 'date_rdf', 'annee_rdf'])
    df = pd.DataFrame(toutes_lignes).drop_duplicates().reset_index(drop=True)
    print(f"Documents Sudoc uniques : {df['ppn_document'].nunique():,}")
    print(f"Documents avec année RDF : {df.drop_duplicates('ppn_document')['annee_rdf'].notna().sum():,}")
    print(f'Durée SPARQL : {time.perf_counter() - debut:.1f}s')
    return df

def parser_unimarc(contenu_xml):
    try:
        root = etree.fromstring(contenu_xml)
    except Exception:
        return (None, None)
    index = {}
    champs_complets = []
    for element in root.iter():
        if nom_local_xml(element) != 'datafield':
            continue
        tag = element.get('tag')
        if not tag:
            continue
        sous_champs = {}
        for subfield in element:
            if nom_local_xml(subfield) != 'subfield':
                continue
            code = subfield.get('code')
            texte = subfield.text
            if not code or texte is None:
                continue
            texte = texte.strip()
            if not texte:
                continue
            sous_champs.setdefault(code, []).append(texte)
            index.setdefault(tag, {}).setdefault(code, []).append(texte)
        if sous_champs:
            champs_complets.append((tag, sous_champs))
    return (index, champs_complets)

def valeurs_champs(index, tags, codes):
    if not index:
        return []
    return [valeur for tag in tags for code in codes for valeur in index.get(tag, {}).get(code, [])]
TAGS_TITRES = ['200', '500', '501', '503', '510', '512', '513', '514', '515', '516', '517', '518', '520', '530', '531', '532', '540', '541', '545']
CODES_TITRES = ['a', 'e', 'h', 'i']
TAGS_SUJETS = [str(tag) for tag in range(600, 700)]
CODES_SUJETS = ['a', 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'x', 'y', 'z']

def extraire_auteurs_et_ppn(champs_complets):
    noms = []
    ppn_auteurs = []
    tags_personnes = {'700', '701', '702'}
    tags_collectivites = {'710', '711', '712'}
    for tag, sous_champs in champs_complets:
        if tag in tags_personnes:
            parties = []
            parties.extend(sous_champs.get('a', []))
            parties.extend(sous_champs.get('b', []))
            if parties:
                nom = ' '.join((partie.strip() for partie in parties if partie.strip()))
                if nom:
                    noms.append(nom)
            for valeur_ppn in sous_champs.get('3', []):
                match = PPN_REGEX.search(str(valeur_ppn))
                if match:
                    ppn_auteurs.append(match.group(1).upper())
        elif tag in tags_collectivites:
            parties = []
            for code in ['a', 'b', 'c']:
                parties.extend(sous_champs.get(code, []))
            if parties:
                nom = ' '.join((partie.strip() for partie in parties if partie.strip()))
                if nom:
                    noms.append(nom)
            for valeur_ppn in sous_champs.get('3', []):
                match = PPN_REGEX.search(str(valeur_ppn))
                if match:
                    ppn_auteurs.append(match.group(1).upper())
    return (concat_unique(noms), concat_unique(ppn_auteurs))

def analyser_xml_sudoc(ppn_document, contenu_xml, annee_rdf=None):
    if not contenu_xml:
        return []
    index, champs_complets = parser_unimarc(contenu_xml)
    if not index:
        return []
    isbn_bruts = valeurs_champs(index, ['010'], ['a'])
    if not isbn_bruts:
        return []
    isbn = {normaliser_isbn(x) for x in isbn_bruts}
    isbn.discard(None)
    if not isbn:
        return []
    titres_detection = valeurs_champs(index, TAGS_TITRES, CODES_TITRES)
    titre_ok = any((contient_terme_titre(x) for x in titres_detection))
    sujets = valeurs_champs(index, TAGS_SUJETS, CODES_SUJETS)
    sujet_ok = any((contient_terme_titre(x) for x in sujets))
    lieux = valeurs_champs(index, ['210', '214'], ['a'])
    lieu_ok = any((contient_commune(x) for x in lieux))
    if not (titre_ok or sujet_ok or lieu_ok):
        return []
    titre = concat_unique(valeurs_champs(index, ['200'], ['a', 'e', 'h', 'i']))
    nom_auteur, ppn_auteurs = extraire_auteurs_et_ppn(champs_complets)
    editeur = concat_unique(valeurs_champs(index, ['210', '214'], ['c']))
    annee = int(annee_rdf) if annee_rdf is not None and (not pd.isna(annee_rdf)) else None
    if annee is None:
        dates_xml = valeurs_champs(index, ['210', '214'], ['d'])
        for valeur_date in dates_xml:
            annee = extraire_annee(valeur_date)
            if annee is not None:
                break
    raisons = []
    if titre_ok:
        raisons.append('titre')
    if sujet_ok:
        raisons.append('sujet')
    if lieu_ok:
        raisons.append('lieu_publication')
    sujet_final = concat_unique(sujets)
    lieu_final = concat_unique(lieux)
    raisons_final = ' | '.join(raisons)
    return [{'ppn': ppn_auteurs, 'isbn_normalise': numero, 'titre': titre, 'nomAuteur': nom_auteur, 'editeur': editeur, 'annee': annee, 'sujet': sujet_final, 'lieuPublication': lieu_final, 'raisons': raisons_final, '_ppn_document': ppn_document} for numero in sorted(isbn)]

async def analyser_notice_sudoc(session, semaphore, ppn_document, annee_rdf=None):
    url = f'{SUDOC_URL}/{ppn_document}.xml'
    contenu = await requete_http(session, url, semaphore=semaphore, accepter_404=True)
    if contenu is None:
        return (ppn_document, [])
    lignes = analyser_xml_sudoc(ppn_document, contenu, annee_rdf=annee_rdf)
    return (ppn_document, lignes)

async def analyser_documents_sudoc(session, df_liens_sparql):
    debut = time.perf_counter()
    print()
    print('=' * 70)
    print('3/4 - XML SUDOC')
    print('=' * 70)
    if df_liens_sparql.empty:
        return pd.DataFrame()
    meta_documents = df_liens_sparql[['ppn_document', 'annee_rdf']].sort_values(by='annee_rdf', na_position='last').drop_duplicates(subset=['ppn_document'], keep='first').reset_index(drop=True)
    total = len(meta_documents)
    print(f'Documents XML à télécharger : {total:,}')
    semaphore = asyncio.Semaphore(MAX_CONCURRENT_SUDOC)
    taches = [analyser_notice_sudoc(session, semaphore, ligne.ppn_document, ligne.annee_rdf) for ligne in meta_documents.itertuples(index=False)]
    toutes_lignes = []
    termines = 0
    erreurs = 0
    for future in asyncio.as_completed(taches):
        try:
            _, lignes = await future
            if lignes:
                toutes_lignes.extend(lignes)
        except Exception as erreur:
            erreurs += 1
        termines += 1
        if termines % 100 == 0 or termines == total:
            print(f'\rNotices : {termines:,}/{total:,} ({termines / total * 100:.1f}%) | lignes : {len(toutes_lignes):,} | erreurs : {erreurs:,}', end='')
    print()
    print(f'Durée XML Sudoc : {time.perf_counter() - debut:.1f}s')
    if not toutes_lignes:
        return pd.DataFrame()
    return pd.DataFrame(toutes_lignes)

def fusionner_resultats(df):
    if df.empty:
        return df
    df = df.drop_duplicates(subset=['_ppn_document', 'isbn_normalise']).reset_index(drop=True)
    df['ppn'] = df['ppn'].fillna('').astype(str).str.split('\\s*\\|\\s*', regex=True)
    df = df.explode('ppn', ignore_index=True)
    df['ppn'] = df['ppn'].fillna('').astype(str).str.strip()
    df = df.drop_duplicates(subset=['_ppn_document', 'isbn_normalise', 'ppn']).reset_index(drop=True)
    colonnes = ['ppn', 'isbn_normalise', 'titre', 'nomAuteur', 'editeur', 'annee', 'sujet', 'lieuPublication', 'raisons']
    df = df[colonnes]
    df['annee'] = pd.to_numeric(df['annee'], errors='coerce').astype('Int64')
    df = df.sort_values(by=['isbn_normalise', 'titre', 'ppn'], na_position='last').reset_index(drop=True)
    return df

async def executer_pipeline_hybride():
    debut_global = time.perf_counter()
    timeout = aiohttp.ClientTimeout(total=TIMEOUT_TOTAL, connect=TIMEOUT_CONNECT)
    connector = aiohttp.TCPConnector(limit=80, limit_per_host=45, ttl_dns_cache=600, enable_cleanup_closed=True)
    async with aiohttp.ClientSession(headers=HEADERS, timeout=timeout, connector=connector) as session:
        df_idref_brut = await rechercher_idref_large(session)
        if df_idref_brut.empty:
            print('Aucun résultat IdRef.')
            return (pd.DataFrame(), [], df_idref_brut, pd.DataFrame())
        df_liens_sparql = await recuperer_documents_sparql(session, df_idref_brut)
        if df_liens_sparql.empty:
            print('Aucun document Sudoc trouvé via SPARQL.')
            return (pd.DataFrame(), [], df_idref_brut, df_liens_sparql)
        df_sudoc_brut = await analyser_documents_sudoc(session, df_liens_sparql)
    df_final = fusionner_resultats(df_sudoc_brut)
    if not df_final.empty:
        liste_isbn = df_final['isbn_normalise'].dropna().drop_duplicates().tolist()
    else:
        liste_isbn = []
    duree = time.perf_counter() - debut_global
    print()
    print('=' * 70)
    print('4/4 - RESULTATS')
    print('=' * 70)
    print(f"Autorités IdRef : {df_idref_brut['ppn'].nunique():,}")
    print(f"Documents Sudoc candidats : {df_liens_sparql['ppn_document'].nunique():,}")
    print(f'Lignes finales : {len(df_final):,}')
    print(f'ISBN uniques : {len(liste_isbn):,}')
    print(f'Durée totale : {duree:.1f}s ({duree / 60:.1f} min)')
    return (df_final, liste_isbn, df_idref_brut, df_liens_sparql)

async def recherche_IDREF():
    """
    Lance la recherche Genevensia IdRef/Sudoc et retourne
    uniquement le DataFrame final attendu par pipeline.py.
    """
    df_final, _liste_isbn, _df_idref_brut, _df_liens_sparql = await executer_pipeline_hybride()
    return df_final