import re
import pandas as pd
import unicodedata
import requests

from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from pathlib import Path

# ============================================================
# FICHIERS
# ============================================================

def charger_liste(fichier, dedoublonner=False, afficher=False):
    fichier = Path(fichier)

    if not fichier.is_file():
        raise FileNotFoundError(f"Fichier introuvable : {fichier}")

    valeurs = [
        ligne.strip().rstrip(",").strip().strip('"').strip("'").strip()
        for ligne in fichier.read_text(encoding="utf-8-sig").splitlines()
        if ligne.strip()
    ]

    if dedoublonner:
        valeurs = list(dict.fromkeys(valeurs))

    if not valeurs:
        raise ValueError(f"Le fichier est vide : {fichier}")

    if afficher:
        print(f"✓ {len(valeurs):,} valeurs chargées depuis {fichier.name}")

    return valeurs


# ============================================================
# LOTS
# ============================================================

def creer_lots(valeurs, taille):
    valeurs = list(valeurs)

    yield from (
        valeurs[i:i + taille]
        for i in range(0, len(valeurs), taille)
    )


# ============================================================
# VALEURS
# ============================================================

def concat_unique(valeurs, trier=True):
    valeurs = [
        str(v).strip()
        for v in valeurs
        if pd.notna(v) and str(v).strip()
    ]

    valeurs = list(dict.fromkeys(valeurs))

    if trier:
        valeurs.sort()

    return " | ".join(valeurs)


def valeur(binding, nom):
    return binding.get(nom, {}).get("value")


# ============================================================
# ISBN STRICT
# ============================================================

def normaliser_isbn(isbn):
    """Valide un ISBN-10/13 et retourne toujours un ISBN-13."""

    if isbn is None:
        return None

    isbn = re.sub(r"[^0-9Xx]", "", str(isbn)).upper()

    if len(isbn) == 13:
        if not isbn.isdigit():
            return None

        total = sum(
            int(chiffre) * (1 if i % 2 == 0 else 3)
            for i, chiffre in enumerate(isbn[:12])
        )

        if (10 - total % 10) % 10 != int(isbn[-1]):
            return None

        return isbn

    if len(isbn) == 10:
        if not isbn[:9].isdigit() or not (
            isbn[-1].isdigit() or isbn[-1] == "X"
        ):
            return None

        total = sum(
            (10 - i) * (10 if c == "X" else int(c))
            for i, c in enumerate(isbn)
        )

        if total % 11:
            return None

        base = "978" + isbn[:9]

        cle = (
            10
            - sum(
                int(c) * (1 if i % 2 == 0 else 3)
                for i, c in enumerate(base)
            ) % 10
        ) % 10

        return base + str(cle)

    return None


# ============================================================
# AFFICHAGE
# ============================================================

SEPARATEUR = "=" * 42


def afficher_section(titre):
    print(f"\n{SEPARATEUR}\n{titre}\n{SEPARATEUR}")
    
    
# ============================================================
# TEXTE
# ============================================================

def normaliser_texte(texte):
    if texte is None:
        return ""

    texte = (
        str(texte)
        .lower()
        .strip()
        .replace("œ", "oe")
        .replace("æ", "ae")
        .replace("’", "'")
    )

    return "".join(
        c
        for c in unicodedata.normalize("NFD", texte)
        if unicodedata.category(c) != "Mn"
    )


# ============================================================
# PPN
# ============================================================

def normaliser_ppn(valeur):
    if valeur is None:
        return None

    texte = str(valeur).strip().upper()

    match = re.search(
        r"(?<![0-9A-Z])([0-9]{8}[0-9X])(?![0-9A-Z])",
        texte
    )

    if match:
        return match.group(1)

    texte = re.sub(r"[^0-9X]", "", texte)

    if (
        len(texte) == 9
        and texte[:8].isdigit()
        and (texte[-1].isdigit() or texte[-1] == "X")
    ):
        return texte

    return None
    
    
# ============================================================
# HTTP
# ============================================================

def creer_session_http(
    retries,
    backoff,
    methods,
    pool_size,
    headers=None,
    monter_http=True,
    respect_retry_after=True,
    connect=None,
    read=None,
    status=None,
):
    session = requests.Session()

    retry = Retry(
        total=retries,
        connect=retries if connect is None else connect,
        read=retries if read is None else read,
        status=retries if status is None else status,
        backoff_factor=backoff,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=methods,
        respect_retry_after_header=respect_retry_after,
    )

    adapter = HTTPAdapter(
        max_retries=retry,
        pool_connections=pool_size,
        pool_maxsize=pool_size,
    )

    session.mount("https://", adapter)

    if monter_http:
        session.mount("http://", adapter)

    if headers:
        session.headers.update(headers)

    return session
    
    
def obtenir_session_thread(thread_local, factory, nom="session"):
    if not hasattr(thread_local, nom):
        setattr(thread_local, nom, factory())

    return getattr(thread_local, nom)
    
    
# ============================================================
# ECHAPPEMENT
# ============================================================

def echapper_requete(texte):
    return (
        str(texte)
        .replace("\\", "\\\\")
        .replace('"', '\\"')
    )
    
    
# ============================================================
# XML
# ============================================================

def nom_local_xml(element):
    """Retourne le nom local d'un tag XML avec ou sans namespace."""
    if element is None:
        return ""

    tag = getattr(element, "tag", element)

    if not tag:
        return ""

    return str(tag).split("}")[-1]