from pathlib import Path


# ============================================================
# CHEMINS DU PROJET
# ============================================================

DOSSIER_MODULES = Path(__file__).resolve().parent
DOSSIER_PROJET = DOSSIER_MODULES.parent

DOSSIER_LISTES = DOSSIER_PROJET / "Liste"
DOSSIER_OUTPUT = DOSSIER_PROJET / "output"

FICHIER_COMMUNES = DOSSIER_LISTES / "liste commune geneve.txt"
FICHIER_TITRES = DOSSIER_LISTES / "liste titre.txt"

CHEMIN_TABLE_FINALE = DOSSIER_PROJET / "table_finale.xlsx"


# ============================================================
# CREATION DES DOSSIERS
# ============================================================

DOSSIER_OUTPUT.mkdir(parents=True, exist_ok=True)