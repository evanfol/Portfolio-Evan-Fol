import pandas as pd
import pytest
import bnf
pytestmark=pytest.mark.network
def test_bnf_un_auteur(identifiants_wikidata):
    bnf_id=identifiants_wikidata.get("bnf_id")
    if bnf_id is None or str(bnf_id).strip()=="": pytest.skip("Aucun identifiant BnF via Wikidata")
    df=pd.DataFrame({"ppn":[identifiants_wikidata["ppn"]],"bnf_id":[bnf_id],"NomComplet":[identifiants_wikidata.get("nom")]})
    out=bnf.ajouter_isbn_bnf_ultra(df,colonne_bnf="bnf_id",batch_size=1,max_workers=1)
    assert isinstance(out,pd.DataFrame)
    assert "bnf_id" in out.columns
