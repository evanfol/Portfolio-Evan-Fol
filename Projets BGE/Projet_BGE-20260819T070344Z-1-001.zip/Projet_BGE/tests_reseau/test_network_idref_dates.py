import pandas as pd
import pytest
import naissance_deces as nd
pytestmark=pytest.mark.network
def test_dates_idref_reelles(identifiants_wikidata):
    df=pd.DataFrame({"ppn":[identifiants_wikidata["ppn"]]})
    out=nd.ajouter_dates_auteurs(df,taille_lot=1,timeout=30,afficher_progression=False)
    assert isinstance(out,pd.DataFrame)
    assert {"ppn","date_naissance","date_deces"}.issubset(out.columns)
    assert len(out)==1
