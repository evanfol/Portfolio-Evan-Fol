import pandas as pd
import pytest
import sudoc
pytestmark=pytest.mark.network
def test_sudoc_un_ppn(identifiants_wikidata):
    df=pd.DataFrame({"ppn":[identifiants_wikidata["ppn"]],"NomComplet":[identifiants_wikidata.get("nom")]})
    out=sudoc.ajouter_isbn_sudoc_ultra(df,colonne_ppn="ppn")
    assert isinstance(out,pd.DataFrame)
    assert "ppn" in out.columns
    if not out.empty and "isbn_normalise" in out.columns:
        assert out["isbn_normalise"].dropna().astype(str).str.strip().ne("").all()
