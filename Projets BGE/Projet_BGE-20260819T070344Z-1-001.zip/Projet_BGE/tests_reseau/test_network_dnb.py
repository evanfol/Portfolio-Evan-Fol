import pandas as pd
import pytest
import dnb
pytestmark=pytest.mark.network
def test_dnb_un_auteur(identifiants_wikidata):
    gnd_id=identifiants_wikidata.get("gnd_id")
    if gnd_id is None or str(gnd_id).strip()=="": pytest.skip("Aucun identifiant GND via Wikidata")
    df=pd.DataFrame({"ppn":[identifiants_wikidata["ppn"]],"gnd_id":[gnd_id],"NomComplet":[identifiants_wikidata.get("nom")]})
    out=dnb.ajouter_isbn_dnb_ultra(df,colonne_gnd="gnd_id",dnb_batch_size=1,dnb_workers=1)
    assert isinstance(out,pd.DataFrame)
    assert "gnd_id" in out.columns
