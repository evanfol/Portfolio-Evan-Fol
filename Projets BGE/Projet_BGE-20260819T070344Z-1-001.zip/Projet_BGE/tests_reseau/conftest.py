import sys
from pathlib import Path

import pandas as pd
import pytest


# ============================================================
# CHEMINS DU PROJET
# ============================================================

DOSSIER_TESTS = Path(__file__).resolve().parent
PROJET = DOSSIER_TESTS.parent
MODULES = PROJET / "modules"

for chemin in (MODULES, PROJET):
    chemin = str(chemin)

    if chemin not in sys.path:
        sys.path.insert(0, chemin)


# PPN de test : Charles Ferdinand Ramuz
PPN_TEST = "027089215"


@pytest.fixture(scope="session")
def identifiants_wikidata():

    import ppn_gen_aut as pga

    session = pga.creer_session()

    resultat = pga.requete_wikidata_ppn(
        [PPN_TEST],
        session
    )

    if isinstance(resultat, list):
        df = pd.DataFrame(resultat)

    elif isinstance(resultat, pd.DataFrame):
        df = resultat.copy()

    else:
        pytest.fail(
            "requete_wikidata_ppn() a retourné un type inattendu : "
            f"{type(resultat)}"
        )

    if df.empty:
        pytest.skip(
            f"Wikidata ne retourne rien pour le PPN {PPN_TEST}"
        )

    ligne = df.iloc[0]

    return {
        "ppn": PPN_TEST,
        "bnf_id": ligne.get("bnf_id_wikidata"),
        "gnd_id": ligne.get("gnd_id_wikidata"),
        "nom": ligne.get("NomComplet_wikidata"),
    }