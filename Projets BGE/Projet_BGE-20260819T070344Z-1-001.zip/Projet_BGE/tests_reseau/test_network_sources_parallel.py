import pandas as pd
import pytest
import sources
pytestmark=pytest.mark.network
def test_sources_paralleles_reelles(identifiants_wikidata):
    df=pd.DataFrame({"ppn":[identifiants_wikidata["ppn"]],"gnd_id":[identifiants_wikidata.get("gnd_id")],"NomComplet":[identifiants_wikidata.get("nom")]})
    resultats,erreurs=sources.lancer_sources(df)
    assert isinstance(resultats,dict) and isinstance(erreurs,dict)
    assert set(resultats)|set(erreurs)=={"network","sudoc","dnb"}
    for nom,v in resultats.items(): assert isinstance(v,pd.DataFrame)
