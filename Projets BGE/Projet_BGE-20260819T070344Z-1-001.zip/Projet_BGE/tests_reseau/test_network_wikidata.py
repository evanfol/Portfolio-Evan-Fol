import pytest
pytestmark=pytest.mark.network
def test_wikidata_resolution_ppn(identifiants_wikidata):
    assert identifiants_wikidata["ppn"]=="027089215"
    assert "bnf_id" in identifiants_wikidata and "gnd_id" in identifiants_wikidata
