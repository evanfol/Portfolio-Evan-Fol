import asyncio
import pandas as pd
import pytest
import comparaison_vge as vge
pytestmark=pytest.mark.network
def test_vge_requete_reelle_sans_fichiers_production(monkeypatch,tmp_path):
    table=tmp_path/"table_finale.xlsx"; hist=tmp_path/"Acquisition_non.csv"
    pd.DataFrame({"isbn_normalise":pd.Series(dtype="string"),"Acquisition":pd.Series(dtype="string")}).to_excel(table,index=False)
    monkeypatch.setattr(vge,"CHEMIN_TABLE_FINALE",table); monkeypatch.setattr(vge,"CHEMIN_ACQUISITION_NON",hist); monkeypatch.setattr(vge,"DOSSIER_OUTPUT",tmp_path)
    df=pd.DataFrame({"ppn":["TEST"],"isbn_normalise":["9782070360024"],"Source":["TEST_RESEAU"],"TypeRecherche":["Auteur"]})
    out=asyncio.run(vge.isbn_absents_vge(df,batch_size=1,max_concurrent=1,timeout=30,retries=2,page_size=10))
    assert isinstance(out,pd.DataFrame) and "isbn_normalise" in out.columns
    assert len(out) in (0,1)
