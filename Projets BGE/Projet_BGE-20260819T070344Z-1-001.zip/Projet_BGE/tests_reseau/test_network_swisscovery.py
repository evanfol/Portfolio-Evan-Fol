import pandas as pd
import pytest
import idref
pytestmark=pytest.mark.network
def test_swisscovery_network_un_ppn(identifiants_wikidata):
    df=pd.DataFrame({"ppn":[identifiants_wikidata["ppn"]],"NomComplet":[identifiants_wikidata.get("nom")]})
    out=idref.ajouter_isbn_network_ultra(df,colonne_ppn="ppn",workers_phase1=2,workers_phase2=2)
    assert isinstance(out,pd.DataFrame)
    assert "ppn" in out.columns
    if not out.empty and "isbn_normalise" in out.columns:
        assert out["isbn_normalise"].dropna().astype(str).str.strip().ne("").all()
