import asyncio
import pandas as pd
import pytest
pytestmark=[pytest.mark.network,pytest.mark.slow_network]
def contrat(df):
    assert isinstance(df,pd.DataFrame)
    attendu={"ppn","isbn_normalise","titre","annee","nomAuteur","lieuPublication","editeur","sujet","raisons"}
    assert attendu.issubset(df.columns)
def test_genevensia_bnf_complet():
    from lieupublibnf import recherche_BNF
    contrat(recherche_BNF())
def test_genevensia_sudoc_complet():
    from lieupublisudoc import recherche_SUDOC
    contrat(recherche_SUDOC())
def test_genevensia_dnb_complet():
    from lieupublidnb import recherche_DNB
    contrat(recherche_DNB())
def test_genevensia_idref_complet():
    from lieupubliidref import recherche_IDREF
    contrat(asyncio.run(recherche_IDREF()))
