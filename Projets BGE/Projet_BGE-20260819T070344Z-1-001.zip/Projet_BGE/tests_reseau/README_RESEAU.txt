TESTS D'INTEGRATION RESEAU — PROJET BGE V2


============================================================
EMPLACEMENT
============================================================

Placer le dossier tests_reseau dans le projet :

Projet_BGE/
│
├── modules/
├── Liste/
├── output/
├── tests/
├── tests_reseau/
│   ├── pytest_network.ini
│   ├── test_network_sudoc.py
│   ├── test_network_genevensia_slow.py
│   └── ...
│
└── table_finale.xlsx


============================================================
LANCEMENT
============================================================

Ouvrir un terminal dans le dossier Projet_BGE.


------------------------------------------------------------
RESEAU RAPIDE (RECOMMANDE)
------------------------------------------------------------

python -m pytest -c tests_reseau/pytest_network.ini tests_reseau -m "network and not slow_network" -v -s


------------------------------------------------------------
UN SEUL SERVICE
Exemple : SUDOC
------------------------------------------------------------

python -m pytest -c tests_reseau/pytest_network.ini tests_reseau/test_network_sudoc.py -v -s


------------------------------------------------------------
GENEVENSIA COMPLET
Lent — beaucoup de requetes reseau
------------------------------------------------------------

python -m pytest -c tests_reseau/pytest_network.ini tests_reseau/test_network_genevensia_slow.py -m slow_network -v -s


============================================================
INTERPRETATION DES RESULTATS
============================================================

PASSED
= La chaine reseau et le parsing fonctionnent correctement.

SKIPPED
= Un identifiant necessaire (BnF/GND, par exemple) est absent
  pour le PPN utilise par le test.

FAILED
= Une regression est possible.

  L'echec peut egalement provenir :
  - d'une modification d'une API externe ;
  - d'un timeout ;
  - d'une erreur HTTP 429 ;
  - d'une erreur serveur 5xx ;
  - d'une indisponibilite temporaire d'un service.


============================================================
REMARQUE VGE
============================================================

Le test VGE utilise des fichiers temporaires.

Il ne modifie pas les fichiers de production du projet.


============================================================
IMPORTANT
============================================================

Ces tests effectuent de vrais appels reseau vers les services
bibliographiques externes.

Une connexion Internet est donc necessaire.

Contrairement aux tests locaux, leur resultat peut dependre
temporairement de la disponibilite des services externes.
